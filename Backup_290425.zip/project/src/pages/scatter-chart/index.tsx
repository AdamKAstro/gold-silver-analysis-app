//src/pages/scatter-chart/index.tsx
import React, { useState, useCallback, useMemo, useEffect, useRef } from 'react';
// Icons
import { Download, Settings, ZoomIn, ZoomOut, RotateCcw, FilterX, Lock } from 'lucide-react';
// Charting Libraries
import { Chart as ChartJS, LinearScale, PointElement, LogarithmicScale, Tooltip, Legend, ChartOptions, ScatterDataPoint, ScriptableContext } from 'chart.js';
import { Scatter } from 'react-chartjs-2';
import zoomPlugin from 'chartjs-plugin-zoom';
import gradient from 'chartjs-plugin-gradient';
import ChartDataLabels, { Context as DataLabelsContext } from 'chartjs-plugin-datalabels';

// Context Hooks (Still needed for Filters, Currency, Tier)
import { useFilters } from '../../contexts/filter-context';
import { useCurrency } from '../../contexts/currency-context';

// Lib Utilities and Types
import { cn, getNestedValue, isValidNumber } from '../../lib/utils';
import { supabase } from '../../lib/supabaseClient'; // Import supabase client for RPC call
import { convertRpcRowsToCompanies } from '../../lib/converters'; // Import converter
import { getMetricByKey, getAccessibleMetrics, MetricConfig } from '../../lib/metric-types';
import { normalizeValues, formatValueWrapper, exportChartCode, downloadJson } from './chartUtils'; // Utilities for this chart
import type { Company, ColumnTier, Currency, MetricFormat, RpcResponseRow } from '../../lib/types';

// UI Components
import { Button } from '../../components/ui/button';
import { MetricSelector } from '../../components/metric-selector';
import { LoadingIndicator } from '../../components/ui/loading-indicator';
import { PageContainer } from '../../components/ui/page-container';
import { FeatureAccess } from '../../components/ui/feature-access';

// Register Chart.js plugins
ChartJS.register( LinearScale, LogarithmicScale, PointElement, Tooltip, Legend, zoomPlugin, gradient, ChartDataLabels );

// --- Constants ---
const MAX_FETCH_LIMIT_FOR_CHART = 5000; // Set a high limit to fetch all relevant companies
const DEFAULT_CHART_SORT_KEY = 'company_name'; // Default sort for fetching chart data (doesn't really affect scatter plot appearance)
const DEFAULT_CHART_SORT_DIR = 'asc';

// --- ScaleToggle Component ---
function ScaleToggle({ scale, onChange, label }: { scale: 'linear' | 'log', onChange: (scale: 'linear' | 'log') => void, label: string }) {
    return ( <div className="flex items-center gap-2 text-xs"> <span className="text-surface-white/70">{label}:</span> <div className="flex bg-navy-400/20 rounded-lg overflow-hidden p-0.5 gap-0.5"> <button className={cn("px-3 py-1.5 text-xs font-medium rounded-md transition-all duration-200", scale === 'linear' ? "bg-navy-400 text-surface-white shadow-lg shadow-navy-300/30 ring-1 ring-navy-300/30" : "text-surface-white/70 hover:bg-navy-400/30")} onClick={() => onChange('linear')} aria-pressed={scale === 'linear'}>Linear</button> <button className={cn("px-3 py-1.5 text-xs font-medium rounded-md transition-all duration-200", scale === 'log' ? "bg-navy-400 text-surface-white shadow-lg shadow-navy-300/30 ring-1 ring-navy-300/30" : "text-surface-white/70 hover:bg-navy-400/30")} onClick={() => onChange('log')} aria-pressed={scale === 'log'}>Log</button> </div> </div> );
}

// --- Chart Settings Constants ---
const chartSettingsFunctions = { pointRadius: (n: number): number => 6+(Math.max(0, Math.min(1, n||0))*35), pointHoverRadius: (n: number): number => 8+(Math.max(0, Math.min(1, n||0))*48) };
const statusColors: Record<string, { background: string; border: string }> = { producer:{background:'rgba(34,197,94,0.7)',border:'rgb(12,163,74)'}, developer:{background:'rgba(59,130,246,0.7)',border:'rgb(37,99,195)'}, explorer:{background:'rgba(168,85,247,0.7)',border:'rgb(147,51,194)'}, royalty:{background:'rgba(244,162,97,0.7)',border:'rgb(217,119,6)'}, other:{background:'rgba(107,114,128,0.7)',border:'rgb(75,85,99)'}, default:{background:'rgba(107,114,128,0.7)',border:'rgb(75,85,99)'} };

// --- ScatterChartPage Component ---
export function ScatterChartPage() {
    // Hooks for Context (Filters, Currency, Tier)
    const { filterSettings, resetFilters, currentUserTier } = useFilters();
    const { currency } = useCurrency();

    // --- Local State for Chart Data, Loading, Error ---
    const [chartData, setChartData] = useState<Company[]>([]); // Holds ALL filtered companies for chart
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [chartError, setChartError] = useState<string | null>(null);
    // --------------------------------------------------

    // Local state for chart axis/scale settings
    const [xMetric, setXMetric] = useState('financials.market_cap_value');
    const [yMetric, setYMetric] = useState('valuation_metrics.ev_per_resource_oz_all');
    const [zMetric, setZMetric] = useState('production.current_production_total_aueq_koz');
    const [xScale, setXScale] = useState<'linear' | 'log'>('log');
    const [yScale, setYScale] = useState<'linear' | 'log'>('log');
    const [zScale, setZScale] = useState<'linear' | 'log'>('linear');

    // Refs
    const chartRef = useRef<ChartJS<'scatter', (number | ScatterDataPoint | null)[], unknown> | null>(null);
    const containerRef = useRef<HTMLDivElement>(null);

    // Effect to destroy chart on unmount
    useEffect(() => { const chart = chartRef.current; return () => { chart?.destroy(); chartRef.current = null; }; }, []);

    // --- Effect to fetch ALL filtered data for Chart ---
    useEffect(() => {
        let isMounted = true;
        const fetchDataForChart = async () => {
            if (!isMounted) return;
            setIsLoading(true);
            setChartError(null);
            console.log("[ScatterChart] Fetching ALL data with filters:", filterSettings, "Currency:", currency);

            // Build filters JSON
            const filtersJson: Record<string, any> = {};
            if (filterSettings.developmentStatus?.length > 0) filtersJson.status = filterSettings.developmentStatus;
            if (filterSettings.searchTerm?.trim()) filtersJson.searchTerm = filterSettings.searchTerm.trim();
            Object.entries(filterSettings.metricRanges ?? {}).forEach(([db_column, range]) => { const [minVal, maxVal] = range; if (minVal !== null && isValidNumber(minVal)) filtersJson[`min_${db_column}`] = minVal; if (maxVal !== null && isValidNumber(maxVal)) filtersJson[`max_${db_column}`] = maxVal; });

            try {
                // Call backend function requesting ALL results (large page size)
                const { data, error: rpcError } = await supabase.rpc('get_companies_paginated', {
                    page_num: 1,
                    page_size: MAX_FETCH_LIMIT_FOR_CHART, // Use large limit
                    sort_column: DEFAULT_CHART_SORT_KEY, // Default sort
                    sort_direction: DEFAULT_CHART_SORT_DIR,
                    target_currency: currency,
                    filters: filtersJson
                });

                if (!isMounted) return;
                if (rpcError) throw rpcError;

                const companies = convertRpcRowsToCompanies((data ?? []) as RpcResponseRow[]);
                console.log(`[ScatterChart] Received ${companies.length} total companies for chart.`);
                setChartData(companies); // Update local state

            } catch (err: any) {
                if (!isMounted) return;
                console.error("[ScatterChart] Error fetching data:", err);
                setChartError(err.message || 'Failed to load chart data.');
                setChartData([]);
            } finally {
                if (isMounted) setIsLoading(false);
            }
        };

        fetchDataForChart();
        return () => { isMounted = false; }; // Cleanup flag on unmount/re-run

    }, [filterSettings, currency]); // Trigger fetch only when filters or currency change

    // Memos for configs and datasets
    const accessibleMetrics = useMemo(() => getAccessibleMetrics(currentUserTier), [currentUserTier]);
    const xMetricConfig = useMemo(() => getMetricByKey(xMetric), [xMetric]);
    const yMetricConfig = useMemo(() => getMetricByKey(yMetric), [yMetric]);
    const zMetricConfig = useMemo(() => getMetricByKey(zMetric), [zMetric]);

    // Chart Datasets memoization (uses local chartData)
    const chartDatasets = useMemo(() => {
        // Use local chartData
        if (!Array.isArray(chartData) || !chartData.length || !xMetricConfig?.nested_path || !yMetricConfig?.nested_path || !zMetricConfig?.nested_path) { return []; }
        // Point mapping, filtering, normalization, grouping logic (uses chartData)
        const points = chartData.map(c => ({x:getNestedValue(c,xMetricConfig.nested_path),y:getNestedValue(c,yMetricConfig.nested_path),z:getNestedValue(c,zMetricConfig.nested_path),company:c})).filter(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)&&Number.isFinite(p.z)&&(xScale!=='log'||(typeof p.x==='number'&&p.x>0))&&(yScale!=='log'||(typeof p.y==='number'&&p.y>0))&&(zScale!=='log'||(typeof p.z==='number'&&p.z>0)));
        const zValues = points.map(p => p.z as number); const normalizedZ = normalizeValues(zValues, zScale);
        const groupedPoints = points.reduce((acc, point, i) => {
            const status = point.company.status?.toLowerCase() || 'default';
            if (!acc[status]) { acc[status] = { label: status.charAt(0).toUpperCase()+status.slice(1), data:[], backgroundColor:statusColors[status]?.background||statusColors.default.background, borderColor:statusColors[status]?.border||statusColors.default.border, borderWidth:1, hoverBorderWidth:2, datalabels:{ backgroundColor:'rgba(30,41,59,0.75)', borderRadius:3, padding:{top:2,bottom:1,left:4,right:4}, color:'#F8FAFC', font:{size:9,weight:'500',family:"'Inter', sans-serif"}, textAlign:'center', anchor:'center', align:'center', offset:0, clamp:true, display:(ctx:DataLabelsContext)=>(ctx.dataset?.data?.[ctx.dataIndex]as any)?.r_normalized > 0.1, formatter:(v,ctx:DataLabelsContext)=>{ const ds=ctx.chart.data.datasets[ctx.datasetIndex]; const dp=ds?.data?.[ctx.dataIndex]as any; return dp?.company?.tsx_code||null; } } }; }
            acc[status].data.push({ x: point.x as number, y: point.y as number, r_normalized: normalizedZ[i] ?? 0, company: point.company }); return acc;
        }, {} as Record<string, any>);
        return Object.values(groupedPoints);
    }, [chartData, xMetricConfig, yMetricConfig, zMetricConfig, xScale, yScale, zScale]); // Depends on local chartData

    // Chart Options memoization (Remains the same)
    const chartOptions = useMemo(() => { /* ... Full options object ... */ const options: ChartOptions<'scatter'> = { responsive:true, maintainAspectRatio:false, animation:false, elements:{point:{ radius:(c:ScriptableContext<'scatter'>)=>{const d=c.raw as any;if(!d||typeof d.r_normalized!=='number')return 5;return chartSettingsFunctions.pointRadius(d.r_normalized);}, hoverRadius:(c:ScriptableContext<'scatter'>)=>{const d=c.raw as any;if(!d||typeof d.r_normalized!=='number')return 7;return chartSettingsFunctions.pointHoverRadius(d.r_normalized);}, }}, scales:{ x:{ type:xScale==='log'?'logarithmic':'linear', position:'bottom', title:{display:true,text:xMetricConfig?.label?`${xMetricConfig.label}${xScale==='log'?' (Log)':''}`:'X Axis',color:'#94A3B8',font:{size:12}}, ticks:{color:'#64748B',font:{size:9},callback:(v:number|string)=>formatValueWrapper(typeof v==='number'?v:NaN,xMetricConfig?.format,currency as Currency),maxTicksLimit:8}, grid:{color:'rgba(51,65,85,0.2)',borderColor:'rgba(51,65,85,0.5)'} }, y:{ type:yScale==='log'?'logarithmic':'linear', position:'left', title:{display:true,text:yMetricConfig?.label?`${yMetricConfig.label}${yScale==='log'?' (Log)':''}`:'Y Axis',color:'#94A3B8',font:{size:12}}, ticks:{color:'#64748B',font:{size:9},callback:(v:number|string)=>formatValueWrapper(typeof v==='number'?v:NaN,yMetricConfig?.format,currency as Currency),maxTicksLimit:8}, grid:{color:'rgba(51,65,85,0.2)',borderColor:'rgba(51,65,85,0.5)'} } }, plugins:{ legend:{position:'bottom',labels:{color:'#CBD5E1',usePointStyle:true,pointStyle:'circle',padding:20,font:{size:11}}}, tooltip:{ enabled:true,backgroundColor:'rgba(15,23,42,0.9)',titleColor:'#5EEAD4',bodyColor:'#E2E8F0',borderColor:'rgba(51,65,85,0.7)',borderWidth:1,padding:10,cornerRadius:4,boxPadding:4,usePointStyle:true, callbacks:{ label:(ctx:any)=>{ const dp=ctx.raw as any; if(!dp||!dp.company)return ''; const l=[]; l.push(` ${dp.company.company_name} (${dp.company.tsx_code||'N/A'})`); if(xMetricConfig)l.push(` ${xMetricConfig.label}: ${formatValueWrapper(dp.x,xMetricConfig.format,currency as Currency)}`); if(yMetricConfig)l.push(` ${yMetricConfig.label}: ${formatValueWrapper(dp.y,yMetricConfig.format,currency as Currency)}`); if(zMetricConfig){const rz=getNestedValue(dp.company,zMetricConfig.nested_path);const pr=chartSettingsFunctions.pointRadius(dp.r_normalized);l.push(` ${zMetricConfig.label}: ${formatValueWrapper(rz,zMetricConfig.format,currency as Currency)} (Size: ${pr.toFixed(1)}px)`);} return l; }} }, zoom:{zoom:{wheel:{enabled:true,speed:0.1},pinch:{enabled:true},mode:'xy'},pan:{enabled:true,mode:'xy',threshold:5}}, datalabels:{display:false} } }; return options; }, [xScale, yScale, xMetricConfig, yMetricConfig, zMetricConfig, currency]);

    // Handlers
    const handleZoomIn = useCallback(() => { chartRef.current?.zoom(1.2); }, []);
    const handleZoomOut = useCallback(() => { chartRef.current?.zoom(0.8); }, []);
    const handleResetZoom = useCallback(() => { chartRef.current?.resetZoom(); }, []);
    const handleExportCode = useCallback(() => { try { const code = exportChartCode(); downloadJson(code, 'scatter-chart-code.json'); } catch (e) { console.error("Failed export:", e); } }, []);
    const handleResetFilters = useCallback(() => { resetFilters(); handleResetZoom(); }, [resetFilters, handleResetZoom]);

    // Page Actions
    const pageActions = ( <> <Button variant="outline" size="sm" onClick={handleResetFilters} title="Reset Filters"> <FilterX className="h-4 w-4 mr-1" /> Reset Filters </Button> <Button variant="ghost" size="sm" onClick={handleExportCode} title="Download Code Snippets"> <Download className="h-4 w-4 mr-1" /> Code </Button> </> );

    // Render Logic uses local isLoading/chartError/chartData
    const descriptionText = isLoading ? "Loading chart data..." : chartError ? "Error loading chart data" : `Comparing ${chartData?.length ?? 0} companies based on filters`;

    return (
        <PageContainer title="Scatter Analysis" description={descriptionText} actions={pageActions} className="relative isolate">
            <div className="absolute inset-0 bg-cover bg-center bg-no-repeat bg-fixed -z-10 opacity-[0.03]" style={{ backgroundImage: "url('/Background2.jpg')" }} aria-hidden="true" />
            <div className="space-y-6 relative z-0">
                {/* Controls Section */}
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start bg-navy-400/10 p-4 rounded-lg">
                     <FeatureAccess requiredTier={xMetricConfig?.tier ?? 'free'} currentTier={currentUserTier}> <div className="space-y-2"><MetricSelector label="X Axis" selectedMetric={xMetric} onMetricChange={setXMetric} metrics={accessibleMetrics} currentTier={currentUserTier}/><ScaleToggle scale={xScale} onChange={setXScale} label="X Scale"/></div> </FeatureAccess>
                      <FeatureAccess requiredTier={yMetricConfig?.tier ?? 'free'} currentTier={currentUserTier}> <div className="space-y-2"><MetricSelector label="Y Axis" selectedMetric={yMetric} onMetricChange={setYMetric} metrics={accessibleMetrics} currentTier={currentUserTier}/><ScaleToggle scale={yScale} onChange={setYScale} label="Y Scale"/></div> </FeatureAccess>
                      <FeatureAccess requiredTier={zMetricConfig?.tier ?? 'free'} currentTier={currentUserTier}> <div className="space-y-2"><MetricSelector label="Bubble Size" selectedMetric={zMetric} onMetricChange={setZMetric} metrics={accessibleMetrics} currentTier={currentUserTier}/><ScaleToggle scale={zScale} onChange={setZScale} label="Size Scale"/></div> </FeatureAccess>
                 </div>
                {/* Chart Section */}
                <div className="relative bg-navy-800/70 backdrop-blur-sm rounded-lg p-4 shadow-lg border border-navy-700/50">
                    <div className="absolute top-3 right-3 flex items-center gap-1.5 z-10"> <Button variant="outline" size="icon-sm" onClick={handleZoomIn} title="Zoom In" className="bg-navy-700/50 border-navy-600 hover:bg-navy-600"> <ZoomIn className="h-4 w-4" /> </Button> <Button variant="outline" size="icon-sm" onClick={handleZoomOut} title="Zoom Out" className="bg-navy-700/50 border-navy-600 hover:bg-navy-600"> <ZoomOut className="h-4 w-4" /> </Button> <Button variant="outline" size="icon-sm" onClick={handleResetZoom} title="Reset Zoom" className="bg-navy-700/50 border-navy-600 hover:bg-navy-600"> <RotateCcw className="h-4 w-4" /> </Button> </div>
                    <div className="h-[65vh] min-h-[500px]" ref={containerRef}>
                         {isLoading ? ( <div className="h-full flex items-center justify-center text-gray-400"> <LoadingIndicator message="Loading chart data..." /> </div>
                        ) : chartError ? ( <div className="h-full flex flex-col items-center justify-center text-red-400"> <p className="font-semibold mb-2">Error Loading Chart Data</p> <p className="text-sm">{chartError}</p> </div>
                        ) : !chartData || chartData.length === 0 ? ( <div className="h-full flex flex-col items-center justify-center text-gray-500"> <p>No companies match the current filters for chart display.</p> </div>
                        ) : chartDatasets.length === 0 && !isLoading ? ( <div className="h-full flex flex-col items-center justify-center text-gray-500"> <p>No valid data points for the selected metrics/scales.</p><p className="text-xs">(Try different axes or linear scale)</p></div>
                        ) : containerRef.current ? (
                             <Scatter ref={chartRef} data={{ datasets: chartDatasets }} options={chartOptions} />
                        ) : ( <div className="h-full flex items-center justify-center text-gray-600"> Initializing chart... </div> )}
                    </div>
                </div>
            </div>
        </PageContainer>
    );
}