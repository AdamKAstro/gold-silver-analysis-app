import React, { useMemo, useCallback } from 'react';
import { Info, Lock } from 'lucide-react'; // Added Lock import
import { AnimatePresence, motion } from 'framer-motion';
import { useFilters } from '../../contexts/filter-context';
import { Button } from '../../components/ui/button';
import { Card } from '../../components/ui/card';
import { LoadingIndicator } from '../../components/ui/loading-indicator';
import { PageContainer } from '../../components/ui/page-container';
import { StatusBadge } from '../../components/status-badge';
import { PercentageRangeSlider } from '../../components/ui/percentage-range-slider';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../../components/ui/tooltip';
import { TierBadge } from '../../components/ui/tier-badge';
import { metricCategories, getMetricsByCategory, getAccessibleMetrics } from '../../lib/metric-types';
import type { MetricConfig, CompanyStatus, ColumnTier, MetricFormat } from '../../lib/types';
import { formatNumber, formatCurrency, formatPercent, formatMoz, formatKoz, isValidNumber } from '../../lib/utils';

const FILTERABLE_STATUSES: CompanyStatus[] = ['producer', 'developer', 'explorer', 'royalty', 'other'];

function StatusFilter({ selectedStatuses, onStatusChange }: { selectedStatuses: CompanyStatus[]; onStatusChange: (statuses: CompanyStatus[]) => void; }) {
   const statusesToDisplay = FILTERABLE_STATUSES;
   return (
     <div className="space-y-2">
       <h3 className="text-sm font-medium text-card-foreground">Development Status</h3>
       <div className="flex flex-wrap gap-2">
         {statusesToDisplay.map(status => ( <button key={status} onClick={() => { const newStatuses = selectedStatuses.includes(status) ? selectedStatuses.filter(s => s !== status) : [...selectedStatuses, status]; onStatusChange(newStatuses); }} className="transition-transform active:scale-95" aria-pressed={selectedStatuses.includes(status)}> <StatusBadge status={status} className={`transition-opacity ${!selectedStatuses.includes(status) ? 'opacity-50 hover:opacity-75' : 'opacity-100 ring-2 ring-offset-2 ring-offset-card ring-primary/50'}`} /> </button> ))}
       </div>
        <Button variant="link" size="sm" onClick={() => onStatusChange([])} className="text-xs h-auto p-0 text-primary/80 hover:text-primary disabled:text-muted-foreground/50 disabled:no-underline" disabled={selectedStatuses.length === 0}> Clear Statuses </Button>
     </div>
   );
}

export function FilterPage() {
  const {
    filterSettings, metricFullRanges, displayData, totalCount, loading, error,
    currentUserTier, setDevelopmentStatusFilter, setMetricRange, resetFilters,
    getMetricConfigByDbColumn
  } = useFilters();

  const effectiveTier = currentUserTier;
  const accessibleMetricKeys = useMemo(() => new Set(getAccessibleMetrics(effectiveTier).map(m => m.key)), [effectiveTier]);

  const formatDisplayValue = useCallback((value: number | null | undefined, format: MetricFormat | undefined, absoluteDefault: number) => {
     if (!isValidNumber(value)) return "-";
     const numValue = value as number;
     try {
         switch (format) {
             case 'currency_precise': return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 3 }).format(numValue);
             case 'currency': return formatCurrency ? formatCurrency(numValue, { compact: true, decimals: 1 }) : `$${numValue}`;
             case 'percent': return formatPercent ? formatPercent(numValue, 1) : `${numValue}%`;
             case 'moz': return formatMoz ? formatMoz(numValue, 2) : `${numValue} Moz`;
             case 'koz': return formatKoz ? formatKoz(numValue, 0) : `${numValue} koz`;
             case 'years': return formatNumber ? `${formatNumber(numValue, { decimals: 1 })} yrs` : `${numValue} yrs`;
             case 'ratio': return formatNumber ? formatNumber(numValue, { decimals: 2 }) : `${numValue}`;
             case 'number': default:
                  if (Math.abs(numValue) >= 1e6 && Intl?.NumberFormat) { return new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 1 }).format(numValue); }
                  return formatNumber ? formatNumber(numValue, { decimals: 0 }) : `${numValue}`;
         }
     } catch (e) { console.error("Formatting error:", value, format, e); return String(numValue); }
  }, []);

  return (
    <PageContainer
        title="Advanced Filters"
        description={loading ? "Loading companies..." : `${displayData.length} companies shown${!loading && !error && totalCount > 0 ? ` (of estimated ${totalCount} total matches)` : ''}`}
    >
        <div className="space-y-4">
          <Card className="bg-card border p-4 md:col-span-2">
            <StatusFilter
              selectedStatuses={filterSettings.developmentStatus}
              onStatusChange={setDevelopmentStatusFilter}
            />
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.entries(metricCategories).map(([categoryKey, categoryLabel]) => {
              const allNumericMetricsInCategory = getMetricsByCategory(categoryKey as MetricConfig['category'])
                .filter(m => ['number', 'currency', 'percent', 'moz', 'koz', 'ratio', 'years'].includes(m.format));

              if (allNumericMetricsInCategory.length === 0) return null;

              return (
                <Card key={categoryKey} className="bg-card border p-4 space-y-4">
                  <div className="flex items-center justify-between">
                      <h2 className="text-lg font-semibold text-card-foreground">{categoryLabel}</h2>
                      <Info className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div className="space-y-6">
                    {allNumericMetricsInCategory.map(metric => {
                      const isAccessible = accessibleMetricKeys.has(metric.key);
                      const fullRange = metricFullRanges?.[metric.db_column];
                      const currentRange = filterSettings.metricRanges[metric.db_column] || [null, null];
                      const [absoluteMin, absoluteMax] = fullRange ?? [0, 0];
                      const [currentMin, currentMax] = currentRange;

                      return (
                        <div key={metric.key} className="relative space-y-2">
                          <div className="flex justify-between items-center gap-2 flex-wrap">
                             <div className="flex items-center gap-1.5">
                                  <TooltipProvider><Tooltip><TooltipTrigger asChild>
                                      <span className={`text-sm font-medium cursor-help ${!isAccessible ? 'text-muted-foreground line-through' : 'text-card-foreground'}`}>
                                          {metric.label} {metric.higherIsBetter === true ? (<span className="text-primary">↑</span>) : metric.higherIsBetter === false ? (<span className="text-destructive">↓</span>) : null}
                                      </span>
                                  </TooltipTrigger><TooltipContent>{metric.description}</TooltipContent></Tooltip></TooltipProvider>
                                  {!isAccessible && <TierBadge tier={metric.tier} className="scale-90" />}
                             </div>
                             <div className={`text-xs ${fullRange === undefined ? 'text-muted-foreground italic' : 'text-muted-foreground'}`}>
                                  {fullRange !== undefined
                                      ? `${formatDisplayValue(currentMin, metric.format, absoluteMin)} - ${formatDisplayValue(currentMax, metric.format, absoluteMax)}`
                                      : "(Range N/A)"
                                  }
                             </div>
                          </div>
                          {fullRange !== undefined ? (
                              <div className="relative pt-1">
                                   {!isAccessible && (
                                     <div className="absolute inset-0 bg-background/70 backdrop-blur-sm rounded-lg flex flex-col items-center justify-center z-10 p-2 text-center cursor-not-allowed"> <Lock className="h-6 w-6 text-primary/80 mb-2 flex-shrink-0" /> <TierBadge tier={metric.tier} /> </div>
                                   )}
                                   <PercentageRangeSlider
                                     fullRange={fullRange} currentRange={currentRange}
                                     onRangeChange={(min, max) => setMetricRange(metric.db_column, min, max)}
                                     disabled={!isAccessible}
                                     className={!isAccessible ? 'opacity-40' : ''}
                                   />
                              </div>
                          ) : (
                              <div className="h-10 bg-muted/50 rounded mt-1 flex items-center justify-center"><span className="text-xs text-muted-foreground italic">Range filter not available</span></div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        <AnimatePresence>{loading && (<motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center z-50"> <LoadingIndicator /> </motion.div>)}</AnimatePresence>
        {error && ( <div className="fixed bottom-4 right-4 bg-destructive text-destructive-foreground px-4 py-2 rounded-lg shadow-lg z-50" role="alert"> <p className="text-sm font-medium">Error:</p> <p className="text-xs">{error}</p> </div> )}
    </PageContainer>
  );
}