//src/App.tsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { SubscriptionProvider } from './contexts/subscription-context';
import { CurrencyProvider } from './contexts/currency-context';
import { ThemeProvider } from './contexts/theme-context';
import { FilterProvider } from './contexts/filter-context';
import { Header } from './components/ui/header'; // Global Header
import { Sidebar } from './components/ui/sidebar'; // Import the Sidebar
// Page Components
import { CompaniesPage } from './pages/companies';
import { SubscribePage } from './pages/subscribe';
import { ScatterChartPage } from './pages/scatter-chart';
import { FilterPage } from './pages/filter';
import ScoringPage from './pages/scoring'; // Default import
import { Hero } from './components/ui/hero'; // Or your HomePage component
// Help Page Components
import { HelpLandingPage } from './pages/help/index';
import { HelpMetricsPage } from './pages/help/metrics';
import { HelpFiltersPage } from './pages/help/filters-guide';
import { HelpScoringPage } from './pages/help/scoring-guide';
import { HelpScatterPage } from './pages/help/scatter-guide';
import { HelpTiersPage } from './pages/help/tiers';
import { HelpGeneralPage } from './pages/help/general';
import ErrorBoundary from './components/ErrorBoundary'; 

function App() {
  return (
    <Router>
      <ThemeProvider>
        <SubscriptionProvider>
          <CurrencyProvider>
            <FilterProvider>
              {/* Main App Container */}
              <div className="flex flex-col min-h-screen bg-navy-900"> {/* Changed background here */}
                {/* Global Header - Renders at the top */}
                <Header />
                {/* Flex container for Sidebar and Main Content */}
                <div className="flex flex-1 overflow-hidden"> {/* Added flex-1 and overflow-hidden */}
                  {/* Sidebar - Renders on the left */}
                  <Sidebar />
                  {/* Main Content Area - Takes remaining space and scrolls */}
                  <main className="flex-1 overflow-y-auto"> {/* Added overflow-y-auto */}
                    {/* PageContainer will be rendered inside here by each page component */}
                    <Routes>
                      <Route path="/" element={<Hero />} />
                      <Route path="/companies" element={<CompaniesPage />} />
                      <Route path="/scatter-chart" element={<ScatterChartPage />} />
                      <Route path="/subscribe" element={<SubscribePage />} />
                      <Route path="/filter" element={<FilterPage />} />
                      <Route path="/scoring" element={<ScoringPage />} />
                      {/* Help Routes */}
                      <Route path="/help" element={<HelpLandingPage />} />
                      <Route path="/help/metrics" element={<HelpMetricsPage />} />
                      <Route path="/help/filters" element={<HelpFiltersPage />} />
                      <Route path="/help/scoring" element={<HelpScoringPage />} />
                      <Route path="/help/scatter-chart" element={<HelpScatterPage />} />
                      <Route path="/help/tiers" element={<HelpTiersPage />} />
                      <Route path="/help/general" element={<HelpGeneralPage />} />
                       {/* Optional: Add a 404 Not Found Route */}
                       {/* <Route path="*" element={<NotFoundPage />} /> */}
                    </Routes>
                  </main>
                </div>
              </div>
            </FilterProvider>
          </CurrencyProvider>
        </SubscriptionProvider>
      </ThemeProvider>
    </Router>
  );
}

export default App;