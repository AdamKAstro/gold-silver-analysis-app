// src/contexts/filter-context.tsx (Added Unpaginated Fetch)
import React, { createContext, useState, useContext, useEffect, useCallback, ReactNode, useMemo } from 'react';
import debounce from 'debounce';
import type { Company, RpcResponseRow, CompanyStatus, ColumnTier, Currency, SortState } from '../lib/types';
import { supabase } from '../lib/supabaseClient';
import { convertRpcRowsToCompanies } from '../lib/converters';
import { metrics as allMetricConfigs, MetricConfig } from '../lib/metric-types';
import { isValidNumber } from '../lib/utils';

// --- State Types ---
interface MetricRanges { [db_column: string]: [number | null, number | null]; }
interface FilterSettings { developmentStatus: CompanyStatus[]; metricRanges: MetricRanges; searchTerm?: string; }
interface MetricFullRanges { [db_column: string]: [number, number]; }

// --- Context Type (Includes unpaginated state/function) ---
interface FilterContextType {
    currentUserTier: ColumnTier; currentCurrency: Currency; filterSettings: FilterSettings;
    metricFullRanges: MetricFullRanges; displayData: Company[]; totalCount: number;
    loading: boolean; dataLoading: boolean; rangeLoading: boolean; error: string | null; // Combined error or specific? Let's use paginatedError for now
    setCurrentUserTier: (tier: ColumnTier) => void; setCurrentCurrency: (currency: Currency) => void;
    setDevelopmentStatusFilter: (statuses: CompanyStatus[]) => void; setMetricRange: (db_column: string, min: number | null, max: number | null) => void;
    setSearchTerm: (term: string) => void; resetFilters: () => void;
    getMetricConfigByDbColumn: (db_column: string) => MetricConfig | undefined;
    sortState: SortState; currentPage: number; pageSize: number;
    setSort: (newSortState: SortState) => void; setPage: (page: number) => void; setPageSize: (size: number) => void;
    // Unpaginated state/function
    unpaginatedData: Company[];
    isUnpaginatedLoading: boolean;
    unpaginatedError: string | null;
    fetchUnpaginatedData: () => Promise<void>; // Function to trigger the fetch
}

const FilterContext = createContext<FilterContextType | undefined>(undefined);

const DEFAULT_FILTER_SETTINGS: FilterSettings = { developmentStatus: [], metricRanges: {}, searchTerm: '' };
const DEFAULT_SORT_STATE: SortState = { key: 'company_name', direction: 'asc' };
const DEFAULT_PAGE = 1;
const DEFAULT_PAGE_SIZE = 25;
const MAX_FETCH_LIMIT_PAGINATED = 100;
const MAX_FETCH_LIMIT_UNPAGINATED = 5000;
const DEBOUNCE_MS = 400;
const pageSizeOptions = [10, 25, 50, 100]; // Keep options here or move to config

export const FilterProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    // State
    const [currentUserTier, setCurrentUserTier] = useState<ColumnTier>('free');
    const [currentCurrency, setCurrentCurrency] = useState<Currency>('USD');
    const [filterSettings, setFilterSettings] = useState<FilterSettings>(DEFAULT_FILTER_SETTINGS);
    const [metricFullRanges, setMetricFullRanges] = useState<MetricFullRanges>({});
    // Paginated State
    const [displayData, setDisplayData] = useState<Company[]>([]);
    const [totalCount, setTotalCount] = useState<number>(0);
    const [dataLoading, setDataLoading] = useState<boolean>(false); // Paginated loading
    const [paginatedError, setPaginatedError] = useState<string | null>(null);
    // Unpaginated State
    const [unpaginatedData, setUnpaginatedData] = useState<Company[]>([]);
    const [isUnpaginatedLoading, setIsUnpaginatedLoading] = useState<boolean>(false);
    const [unpaginatedError, setUnpaginatedError] = useState<string | null>(null);
    // Other State
    const [rangeLoading, setRangeLoading] = useState<boolean>(true);
    const [sortState, setSortState] = useState<SortState>(DEFAULT_SORT_STATE);
    const [currentPage, setCurrentPage] = useState<number>(DEFAULT_PAGE);
    const [pageSize, setPageSizeState] = useState<number>(DEFAULT_PAGE_SIZE);

    // Combined loading / error states exposed to consumers
    const loading = rangeLoading || dataLoading; // Primarily reflects paginated load status
    const error = paginatedError; // Primarily reflects paginated error status

    // Fetch Full Metric Ranges
    useEffect(() => {
        let mounted = true;
        const fetchFullRanges = async () => { setRangeLoading(true);setPaginatedError(null);setUnpaginatedError(null);try {const { data, error: rpcError } = await supabase.rpc('get_metrics_ranges');if (rpcError) throw rpcError;if (mounted) setMetricFullRanges((data as MetricFullRanges) ?? {});} catch (err: any) {console.error("Error fetching ranges:", err);if (mounted) setPaginatedError(err.message);} finally {if (mounted) setRangeLoading(false);} };
        fetchFullRanges();
        return () => { mounted = false; };
    }, []);

    // --- Fetch PAGINATED Data Function ---
    const fetchPaginatedData = useCallback(async () => {
        const settings = filterSettings; const currency = currentCurrency;
        const sort = sortState; const page = currentPage;
        const size = Math.max(1, Math.min(pageSize, MAX_FETCH_LIMIT_PAGINATED));

        setDataLoading(true); setPaginatedError(null);
        console.log(`[FilterContext] Fetching Paginated: Page=${page}, Size=${size}, Sort=${sort.key} ${sort.direction}`, 'Filters:', settings);

        const filtersJson: Record<string, any> = {}; /* ... build filtersJson ... */ if (settings.developmentStatus?.length > 0) filtersJson.status = settings.developmentStatus; if (settings.searchTerm?.trim()) filtersJson.searchTerm = settings.searchTerm.trim(); Object.entries(settings.metricRanges ?? {}).forEach(([db_column, range]) => { const [minVal, maxVal] = range; if (minVal !== null && isValidNumber(minVal)) filtersJson[`min_${db_column}`] = minVal; if (maxVal !== null && isValidNumber(maxVal)) filtersJson[`max_${db_column}`] = maxVal; });

        try {
            const { data, error: rpcError } = await supabase.rpc('get_companies_paginated', { page_num: page, page_size: size, sort_column: sort.key, sort_direction: sort.direction, target_currency: currency, filters: filtersJson });
            if (rpcError) throw rpcError;
            if (!data || data.length === 0) { setDisplayData([]); const estTotal = data?.[0]?.total_rows; setTotalCount( (typeof estTotal === 'number' && isFinite(estTotal)) ? estTotal : 0 ); }
            else { const companies = convertRpcRowsToCompanies(data as RpcResponseRow[]); setDisplayData(companies); const estTotal = data[0]?.total_rows; setTotalCount( (typeof estTotal === 'number' && isFinite(estTotal)) ? estTotal : 0 ); }
        } catch (err: any) { console.error('[FilterContext] Error fetching paginated:', err); setPaginatedError(`Data fetch failed: ${err.message}`); setDisplayData([]); setTotalCount(0); }
        finally { setDataLoading(false); console.log("[FilterContext] Paginated fetch complete."); }
    }, [filterSettings, currentCurrency, sortState, currentPage, pageSize]); // Correct dependencies for useCallback

    // Debounced Fetch for Paginated Data
    const debouncedFetchPaginatedData = useMemo(() => debounce(fetchPaginatedData, DEBOUNCE_MS), [fetchPaginatedData]);

    // Effect to trigger Paginated Fetch
    useEffect(() => { debouncedFetchPaginatedData(); return () => { debouncedFetchPaginatedData.clear(); }; }, [debouncedFetchPaginatedData]);


    // --- Fetch UNPAGINATED Data Function ---
    const fetchUnpaginatedData = useCallback(async () => {
        const settings = filterSettings; const currency = currentCurrency;

        setIsUnpaginatedLoading(true); setUnpaginatedError(null);
        console.log("[FilterContext] Fetching Unpaginated Data. Filters:", settings);

        const filtersJson: Record<string, any> = {}; /* ... build filtersJson ... */ if (settings.developmentStatus?.length > 0) filtersJson.status = settings.developmentStatus; if (settings.searchTerm?.trim()) filtersJson.searchTerm = settings.searchTerm.trim(); Object.entries(settings.metricRanges ?? {}).forEach(([db_column, range]) => { const [minVal, maxVal] = range; if (minVal !== null && isValidNumber(minVal)) filtersJson[`min_${db_column}`] = minVal; if (maxVal !== null && isValidNumber(maxVal)) filtersJson[`max_${db_column}`] = maxVal; });

        try {
            console.log('[FilterContext] Calling RPC "get_companies_paginated" (for all)');
            const { data, error: rpcError } = await supabase.rpc('get_companies_paginated', {
                page_num: 1, page_size: MAX_FETCH_LIMIT_UNPAGINATED, // Large limit
                sort_column: DEFAULT_CHART_SORT_KEY, sort_direction: DEFAULT_CHART_SORT_DIR, // Default sort
                target_currency: currency, filters: filtersJson
            });
            if (rpcError) throw rpcError;
            if (!data || data.length === 0) { setUnpaginatedData([]); }
            else { const companies = convertRpcRowsToCompanies(data as RpcResponseRow[]); setUnpaginatedData(companies); }
        } catch (err: any) { console.error('[FilterContext] Error fetching unpaginated:', err); setUnpaginatedError(`Chart data fetch failed: ${err.message}`); setUnpaginatedData([]); }
        finally { setIsUnpaginatedLoading(false); console.log("[FilterContext] Unpaginated fetch complete."); }
    }, [filterSettings, currentCurrency]); // Dependencies for useCallback

    // --- State Setters ---
    const handleSetDevelopmentStatus = useCallback((statuses: CompanyStatus[]) => { setFilterSettings(prev => ({ ...prev, developmentStatus: statuses })); setCurrentPage(1); }, []);
    const handleSetMetricRange = useCallback((db_column: string, min: number | null, max: number | null) => { setFilterSettings(prev => ({ ...prev, metricRanges: { ...prev.metricRanges, [db_column]: [min, max] } })); setCurrentPage(1); }, []);
    const handleSetSearchTerm = useCallback((term: string) => { setFilterSettings(prev => ({ ...prev, searchTerm: term })); setCurrentPage(1); }, []);
    const handleResetFilters = useCallback(() => { setFilterSettings(DEFAULT_FILTER_SETTINGS); setSortState(DEFAULT_SORT_STATE); setCurrentPage(DEFAULT_PAGE); setPageSizeState(DEFAULT_PAGE_SIZE); }, []);
    const handleSetSort = useCallback((newSortState: SortState) => { setSortState(newSortState); setCurrentPage(1); }, []);
    const handleSetPage = useCallback((page: number) => { if (page > 0) setCurrentPage(page); }, []);
    const handleSetPageSize = useCallback((size: number) => { if (pageSizeOptions.includes(size)) { setPageSizeState(size); setCurrentPage(1); } }, []); // Used constant defined here
    const getMetricConfigByDbColumn = useCallback((db_column: string): MetricConfig | undefined => { return allMetricConfigs.find(m => m.db_column === db_column || m.key === db_column || m.sortKey === db_column); }, []);

    // --- Context Value (Corrected) ---
    const value = useMemo(() => ({
        currentUserTier, currentCurrency, filterSettings, metricFullRanges,
        displayData, totalCount, loading, dataLoading, rangeLoading, error: paginatedError, // Expose paginatedError as main 'error'
        setCurrentUserTier, setCurrentCurrency,
        setDevelopmentStatusFilter: handleSetDevelopmentStatus,
        setMetricRange: handleSetMetricRange,
        setSearchTerm: handleSetSearchTerm,
        resetFilters: handleResetFilters,
        getMetricConfigByDbColumn,
        sortState, currentPage, pageSize,
        setSort: handleSetSort, setPage: handleSetPage, setPageSize: handleSetPageSize,
        // New Unpaginated State/Function
        unpaginatedData,
        isUnpaginatedLoading,
        unpaginatedError,
        // *** FIX: Export the correct function ***
        fetchUnpaginatedData: fetchUnpaginatedData,
    }), [ /* List ALL exported values */
        currentUserTier, currentCurrency, filterSettings, metricFullRanges, displayData,
        totalCount, loading, dataLoading, rangeLoading, paginatedError, // Use paginatedError
        handleSetDevelopmentStatus, handleSetMetricRange, handleSetSearchTerm,
        handleResetFilters, getMetricConfigByDbColumn,
        sortState, currentPage, pageSize, handleSetSort, handleSetPage, handleSetPageSize,
        unpaginatedData, isUnpaginatedLoading, unpaginatedError,
        // *** FIX: Add correct function to dependency array ***
        fetchUnpaginatedData
    ]);

    return <FilterContext.Provider value={value}>{children}</FilterContext.Provider>;
};

// --- Custom Hook ---
export const useFilters = (): FilterContextType => { const c=useContext(FilterContext); if(c===undefined){throw new Error('useFilters must be used within a FilterProvider');} return c; };