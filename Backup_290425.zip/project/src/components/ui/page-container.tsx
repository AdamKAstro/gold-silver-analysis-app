// src/components/ui/page-container.tsx
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
// Icons for Nav items - Ensure HelpCircle is imported
import { Home, Table2, LineChart, Filter, Calculator, Crown, RotateCcw, HelpCircle } from 'lucide-react';
import { Button } from './button';
import { cn } from '../../lib/utils';
import { useFilters } from '../../contexts/filter-context'; // Needed for resetFilters

interface PageContainerProps {
    title: string;
    description?: string;
    children: React.ReactNode;
    actions?: React.ReactNode; // For page-specific actions like CurrencySelector
    className?: string; // Allow passing additional classes to the outer container
    contentClassName?: string; // Allow passing classes to the content wrapper
    showNav?: boolean; // Prop to control visibility of nav icons/reset button
}

// Navigation items definition - Includes HELP
const navItems = [
    { path: "/companies", label: "Companies", icon: Table2 },
    { path: "/scatter-chart", label: "Analysis", icon: LineChart },
    { path: "/filter", label: "Filters", icon: Filter },
    { path: "/scoring", label: "Scoring", icon: Calculator },
    { path: "/subscribe", label: "Subscribe", icon: Crown },
    { path: "/help", label: "Help", icon: HelpCircle }, // Help Link
];

export function PageContainer({
    title,
    description,
    children,
    actions,
    className,
    contentClassName, // Added contentClassName prop
    showNav = true // Default to showing navigation/reset
}: PageContainerProps) {
    const { resetFilters } = useFilters();
    const location = useLocation();
    // Removed logo from here - it's now in the global Header from App.tsx

    return (
        // This container provides padding and holds the header + content
        // Removed min-h-screen and background color - handled by App.tsx now
        <div className={cn("container mx-auto px-4 py-4 space-y-4", className)}>

            {/* Top Bar: Title/Description on Left, Nav/Actions on Right */}
            {/* This acts as the header *within* the main content area */}
            <div className="flex items-center justify-between flex-wrap gap-4 border-b border-navy-700 pb-3 mb-4">
                {/* Left Side: Title and Description */}
                <div>
                    <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                        {title}
                    </h1>
                    {description && (
                        <p className="text-xs sm:text-sm text-gray-400">
                            {description}
                        </p>
                    )}
                </div>

                {/* Right Side: Nav Icons, Reset Button, Page Actions */}
                <div className="flex items-center gap-2 flex-wrap">
                    {/* Conditional Navigation Icons */}
                    {showNav && navItems
                        .filter(item => item.path !== location.pathname) // Filter out current page
                        .map((item) => (
                            <Link
                                key={item.path}
                                to={item.path}
                                className="hidden sm:block" // Hide icons on very small screens
                            >
                                <Button
                                    variant="ghost"
                                    size="icon-sm"
                                    className="text-gray-400 hover:text-white hover:bg-navy-700/50"
                                    title={item.label} // Tooltip text
                                >
                                    <item.icon className="h-4 w-4" />
                                </Button>
                            </Link>
                        ))}

                     {/* Conditional Reset Button */}
                    {showNav && location.pathname !== '/' && ( // Show reset everywhere except home
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={resetFilters}
                            className="text-xs border-navy-600 text-gray-300 hover:bg-navy-700 hover:text-white flex items-center gap-1.5"
                            title="Reset all filters"
                        >
                            <RotateCcw className="h-3.5 w-3.5" />
                            <span className="hidden md:inline">Reset Filters</span>
                            <span className="md:hidden">Reset</span>
                        </Button>
                    )}

                    {/* Page Specific Actions */}
                    {actions && (
                        <div className="flex items-center gap-2 border-l border-navy-700 pl-2 ml-1">
                            {actions}
                        </div>
                    )}
                </div>
            </div>

            {/* Page Content - Render children passed to the container */}
            {/* Apply contentClassName here if provided */}
            <div className={cn(contentClassName)}>
                 {children}
             </div>

        </div>
    );
}