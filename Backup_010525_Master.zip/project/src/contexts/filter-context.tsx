// src/contexts/filter-context.tsx

import React, {
    createContext,
    useState,
    useContext,
    useEffect,
    useCallback,
    ReactNode,
    useMemo,
    useRef,
} from 'react';
import debounce from 'lodash/debounce';
import type { Company, RpcResponseRow, CompanyStatus, ColumnTier, Currency, SortState, FilterSettings, MetricConfig } from '../lib/types';
import { supabase } from '../lib/supabaseClient';
import { convertRpcRowsToCompanies } from '../lib/converters';
import { metrics as allMetricConfigs } from '../lib/metric-types';
import { isValidNumber } from '../lib/utils';

// --- State Types ---
interface MetricRanges { [db_column: string]: [number | null, number | null]; }
interface MetricFullRanges { [db_column: string]: [number, number]; }

// --- Context Type ---
interface FilterContextType {
    currentUserTier: ColumnTier;
    currentCurrency: Currency;
    filterSettings: FilterSettings;
    metricFullRanges: MetricFullRanges;
    displayData: Company[];
    totalCount: number;
    filteredCompanyIds: number[];
    excludedCompanyIds: Set<number>;
    toggleCompanyExclusion: (companyId: number) => void;
    loadingPaginated: boolean;
    loadingRanges: boolean;
    loadingFilteredSet: boolean;
    loading: boolean; // Combined state
    error: string | null;
    setCurrentUserTier: (tier: ColumnTier) => void;
    setCurrentCurrency: (currency: Currency) => void;
    setDevelopmentStatusFilter: (statuses: CompanyStatus[]) => void;
    setMetricRange: (db_column: string, min: number | null, max: number | null) => void;
    setSearchTerm: (term: string) => void;
    resetFilters: () => void;
    getMetricConfigByDbColumn: (db_column: string) => MetricConfig | undefined;
    sortState: SortState;
    currentPage: number;
    pageSize: number;
    setSort: (newSortState: SortState) => void;
    setPage: (page: number) => void;
    setPageSize: (size: number) => void;
    fetchCompaniesByIds: (ids: number[]) => Promise<Company[]>; // Important: Returns Promise<Company[]>
}

const FilterContext = createContext<FilterContextType | undefined>(undefined);

// --- Defaults ---
const DEFAULT_FILTER_SETTINGS: FilterSettings = { developmentStatus: [], metricRanges: {}, searchTerm: '' };
const DEFAULT_SORT_STATE: SortState = { key: 'company_name', direction: 'asc' };
const DEFAULT_PAGE = 1;
const DEFAULT_PAGE_SIZE = 25;
const FILTER_UPDATE_DEBOUNCE_MS = 450;
const PAGE_FETCH_DEBOUNCE_MS = 150;
const pageSizeOptions = [10, 25, 50, 100];
const EMPTY_ARRAY: Company[] = [];
const EMPTY_ID_ARRAY: number[] = [];
const EMPTY_SET = new Set<number>();

// --- Provider Component ---
export const FilterProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    // --- State ---
    const [currentUserTier, setCurrentUserTierState] = useState<ColumnTier>('free');
    const [currentCurrency, setCurrentCurrencyState] = useState<Currency>('USD');
    const [filterSettings, setFilterSettings] = useState<FilterSettings>(DEFAULT_FILTER_SETTINGS);
    const [metricFullRanges, setMetricFullRanges] = useState<MetricFullRanges>({});
    const [displayData, setDisplayData] = useState<Company[]>(EMPTY_ARRAY);
    const [totalCount, setTotalCount] = useState<number>(0);
    const [filteredCompanyIds, setFilteredCompanyIds] = useState<number[]>(EMPTY_ID_ARRAY);
    const [excludedCompanyIds, setExcludedCompanyIds] = useState<Set<number>>(EMPTY_SET);
    const [loadingPaginated, setLoadingPaginated] = useState<boolean>(false);
    const [loadingRanges, setLoadingRanges] = useState<boolean>(true);
    const [loadingFilteredSet, setLoadingFilteredSet] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [sortState, setSortState] = useState<SortState>(DEFAULT_SORT_STATE);
    const [currentPage, setCurrentPage] = useState<number>(DEFAULT_PAGE);
    const [pageSize, setPageSizeState] = useState<number>(DEFAULT_PAGE_SIZE);

    const isFilterOrCurrencyChangeRef = useRef(false);
    const loading = useMemo(() => loadingRanges || loadingFilteredSet || loadingPaginated, [loadingRanges, loadingFilteredSet, loadingPaginated]);

    // --- Fetch Full Metric Ranges (on mount) ---
    useEffect(() => {
        let mounted = true;
        const fetchFullRanges = async () => {
            if (!mounted) return; setLoadingRanges(true); setError(null);
            console.log("[FilterContext] Fetching full metric ranges...");
            try {
                const { data, error: rpcError } = await supabase.rpc('get_metrics_ranges');
                if (!mounted) return; if (rpcError) throw rpcError;
                const rangesData = (data as MetricFullRanges) ?? {};
                setMetricFullRanges(rangesData);
            } catch (err: any) {
                if (!mounted) return; console.error("[FilterContext] Error fetching ranges:", err);
                setError(`Failed to load metric ranges: ${err.message}`); setMetricFullRanges({});
            } finally { if (mounted) setLoadingRanges(false); }
        };
        fetchFullRanges();
        return () => { mounted = false; };
    }, []);

    // --- Core Data Fetching Logic ---
    const buildFiltersJson = useCallback((settings: FilterSettings): Record<string, any> => {
        const filtersJson: Record<string, any> = {};
        if (settings.developmentStatus?.length > 0) filtersJson.status = settings.developmentStatus.filter(s => typeof s === 'string');
        const searchTerm = settings.searchTerm?.trim(); if (searchTerm) filtersJson.searchTerm = searchTerm;
        if (settings.metricRanges) { Object.entries(settings.metricRanges).forEach(([db_column, range]) => { if (Array.isArray(range)) { const [minVal, maxVal] = range; if (minVal !== null && isValidNumber(minVal)) filtersJson[`min_${db_column}`] = minVal; if (maxVal !== null && isValidNumber(maxVal)) filtersJson[`max_${db_column}`] = maxVal; } }); }
        return filtersJson;
    }, []);

    // fetchPaginatedDataOnly (Dependency Corrected)
    const fetchPaginatedDataOnly = useCallback(async ( pageToFetch: number, sizeToFetch: number, currentSort: SortState, currentFilters: FilterSettings, currency: Currency ) => {
        if (loadingPaginated || loadingFilteredSet || loadingRanges) { console.log(`[FilterContext] Skipping Paginated Fetch (loading active)`); return; }
        setLoadingPaginated(true); setError(null);
        console.log(`[FilterContext] Fetching Page Only: ${pageToFetch}, Size: ${sizeToFetch}, Sort: ${currentSort.key}, Currency: ${currency}`);
        const filtersJson = buildFiltersJson(currentFilters);
        try {
            const { data, error: rpcError } = await supabase.rpc('get_companies_paginated', { page_num: pageToFetch, page_size: sizeToFetch, sort_column: currentSort.key, sort_direction: currentSort.direction, target_currency: currency, filters: filtersJson });
            if (rpcError) throw rpcError;
            setDisplayData(data ? convertRpcRowsToCompanies(data as RpcResponseRow[]) : EMPTY_ARRAY); // Ensure array even if data is null
            if (data && data.length > 0) {
                const exactTotal = data[0]?.total_rows;
                if (typeof exactTotal === 'number' && isFinite(exactTotal) && exactTotal !== totalCount) {
                    console.warn(`[FilterContext] Paginated total_rows (${exactTotal}) inconsistent with stored total (${totalCount}) on page ${pageToFetch}.`);
                }
            }
        } catch (err: any) {
            console.error('[FilterContext] Error fetching paginated only:', err);
            setError(`Data fetch failed for page ${pageToFetch}: ${err.message}`);
            setDisplayData(EMPTY_ARRAY);
        } finally { setLoadingPaginated(false); }
    }, [buildFiltersJson, loadingPaginated, loadingFilteredSet, loadingRanges, totalCount]); // Read totalCount for warning, but removed from deps previously - re-added as it IS read. Let's monitor if this causes issues. If so, remove again.

    // fetchFilteredSetAndFirstPage (Unchanged logic, check dependencies)
    const fetchFilteredSetAndFirstPage = useCallback(async ( currentFilters: FilterSettings, currentSort: SortState, sizeForFirstPage: number, currency: Currency ) => {
        setLoadingFilteredSet(true); setLoadingPaginated(true); setError(null);
        console.log(`[FilterContext] Updating Full Filtered Set & First Page. Size: ${sizeForFirstPage}, Sort: ${currentSort.key}, Currency: ${currency}`);
        const filtersJson = buildFiltersJson(currentFilters);
        let fetchedCount = 0;
        let firstPageData: Company[] = EMPTY_ARRAY;
        let allIds: number[] = EMPTY_ID_ARRAY;
        try {
            const { data: pageData, error: pageError } = await supabase.rpc('get_companies_paginated', { page_num: 1, page_size: sizeForFirstPage, sort_column: currentSort.key, sort_direction: currentSort.direction, target_currency: currency, filters: filtersJson });
            if (pageError) throw new Error(`Failed to fetch initial page data: ${pageError.message}`);
            if (!pageData || pageData.length === 0) {
                 fetchedCount = 0; firstPageData = EMPTY_ARRAY; allIds = EMPTY_ID_ARRAY;
            } else {
                 const exactTotal = pageData[0]?.total_rows;
                 if (typeof exactTotal !== 'number' || !isFinite(exactTotal)) throw new Error("Invalid total_rows received from RPC.");
                 fetchedCount = exactTotal;
                 firstPageData = convertRpcRowsToCompanies(pageData as RpcResponseRow[]);
                 if (fetchedCount > 0) {
                     const { data: idData, error: idError } = await supabase.rpc('get_filtered_company_ids', { filters: filtersJson });
                     if (idError) throw new Error(`Failed to fetch filtered company IDs: ${idError.message}`);
                     allIds = (idData as { company_id: number }[] || []).map(r => r.company_id);
                     if (allIds.length !== fetchedCount) console.warn(`[FilterContext] Count mismatch: paginated total (${fetchedCount}) vs fetched IDs (${allIds.length}).`);
                 } else { allIds = EMPTY_ID_ARRAY; }
             }
             setTotalCount(fetchedCount);
             setDisplayData(firstPageData);
             setFilteredCompanyIds(allIds);
        } catch (err: any) {
             console.error('[FilterContext] Error updating filtered set:', err);
             setError(`Filter update failed: ${err.message}`);
             setTotalCount(0); setDisplayData(EMPTY_ARRAY); setFilteredCompanyIds(EMPTY_ID_ARRAY);
        } finally { setLoadingFilteredSet(false); setLoadingPaginated(false); }
    }, [buildFiltersJson]); // Depends only on stable buildFiltersJson

    // --- Debounced Fetch Triggers ---
    const debouncedFetchFilteredSet = useMemo(() => debounce((settings: FilterSettings, sort: SortState, size: number, currency: Currency) => { fetchFilteredSetAndFirstPage(settings, sort, size, currency); }, FILTER_UPDATE_DEBOUNCE_MS), [fetchFilteredSetAndFirstPage]);
    const debouncedFetchPaginatedOnly = useMemo(() => debounce((page: number, size: number, sort: SortState, settings: FilterSettings, currency: Currency) => {
        if (isFilterOrCurrencyChangeRef.current && page === DEFAULT_PAGE) { isFilterOrCurrencyChangeRef.current = false; return; }
        fetchPaginatedDataOnly(page, size, sort, settings, currency);
    }, PAGE_FETCH_DEBOUNCE_MS), [fetchPaginatedDataOnly]);

    // --- Effects to Trigger Fetches ---
    // Effect 1: Filters, Currency, PageSize, Sort changes -> Full Update
    useEffect(() => {
        if (loadingRanges) return; // Don't run while ranges are loading
        isFilterOrCurrencyChangeRef.current = true;
        setCurrentPage(DEFAULT_PAGE); // Reset page on significant changes
        debouncedFetchFilteredSet(filterSettings, sortState, pageSize, currentCurrency);
        return () => { debouncedFetchFilteredSet.cancel(); isFilterOrCurrencyChangeRef.current = false; };
    }, [filterSettings, currentCurrency, pageSize, sortState, loadingRanges, debouncedFetchFilteredSet]);

    // Effect 2: Page changes ONLY -> Paginated Update
    useEffect(() => {
        if (loadingRanges || loadingFilteredSet) return; // Don't run if context isn't ready
        if (isFilterOrCurrencyChangeRef.current && currentPage === DEFAULT_PAGE) { isFilterOrCurrencyChangeRef.current = false; return; } // Skip if handled by effect 1
        if (isFilterOrCurrencyChangeRef.current) { isFilterOrCurrencyChangeRef.current = false; } // Reset flag otherwise
        debouncedFetchPaginatedOnly(currentPage, pageSize, sortState, filterSettings, currentCurrency); // Fetch current page
        return () => { debouncedFetchPaginatedOnly.cancel(); };
    }, [currentPage, loadingRanges, loadingFilteredSet, debouncedFetchPaginatedOnly, pageSize, sortState, filterSettings, currentCurrency]); // Dependencies needed by debounced call

    // --- Function to fetch full company data for a list of IDs (Robust Return) ---
    const fetchCompaniesByIds = useCallback(async (ids: number[]): Promise<Company[]> => {
        // Ensure input is valid
        if (!Array.isArray(ids) || ids.length === 0) {
            console.log('[FilterContext] fetchCompaniesByIds called with empty/invalid IDs. Returning empty array.');
            return EMPTY_ARRAY; // Return []
        }
        console.log(`[FilterContext] Fetching full data for ${ids.length} companies by ID using view.`);
        setError(null); // Clear previous errors related to this fetch
        try {
            const { data, error } = await supabase
                .from('companies_detailed_view') // CHECK VIEW NAME
                .select('*')
                .in('company_id', ids) // CHECK COLUMN NAME
                .limit(ids.length); // Optimization

            if (error) {
                console.error('[FilterContext] Supabase error fetching companies by IDs:', error);
                throw error; // Throw the specific error
            }

            // Explicitly handle null data from Supabase (means no matching rows found)
            if (data === null) {
                console.log('[FilterContext] fetchCompaniesByIds received null data from Supabase. Returning empty array.');
                return EMPTY_ARRAY; // Return []
            }

            // Ensure data is an array before conversion (Supabase types should guarantee array or null, but check anyway)
            if (!Array.isArray(data)) {
                console.error('[FilterContext] fetchCompaniesByIds received non-array/non-null data from Supabase:', data);
                throw new Error('Unexpected data format received when fetching company details.');
            }

            // Convert the data (which is now guaranteed to be an array)
            const convertedData = convertRpcRowsToCompanies(data as RpcResponseRow[]);

            // Final safety check: Ensure the converter didn't return undefined
            if (convertedData === undefined) {
                console.error('[FilterContext] convertRpcRowsToCompanies returned undefined. Input data:', data);
                return EMPTY_ARRAY; // Return [] if converter fails
            }

            console.log(`[FilterContext] fetchCompaniesByIds successfully returning ${convertedData.length} companies.`);
            return convertedData; // Return the valid Company[] (possibly empty)

        } catch (err: any) {
            console.error('[FilterContext] Catch block: Error fetching companies by IDs from view:', err);
            setError(`Failed to load detailed company data: ${err.message || 'Unknown error'}`);
            return EMPTY_ARRAY; // CRITICAL: Always return an empty array on error
        }
    }, [/* setError is stable */]); // Empty dependency array as setError is stable

    // --- State Setters (Handlers) ---
    const handleSetDevelopmentStatus = useCallback((statuses: CompanyStatus[]) => { setFilterSettings(prev => ({ ...prev, developmentStatus: statuses })); }, []);
    const handleSetMetricRange = useCallback((db_column: string, min: number | null, max: number | null) => { setFilterSettings(prev => ({ ...prev, metricRanges: { ...prev.metricRanges, [db_column]: [min, max] } })); }, []);
    const handleSetSearchTerm = useCallback((term: string) => { setFilterSettings(prev => ({ ...prev, searchTerm: term })); }, []);
    const handleResetFilters = useCallback(() => {
         console.log("[FilterContext] Resetting filters to default.");
         setFilterSettings(DEFAULT_FILTER_SETTINGS);
         setSortState(DEFAULT_SORT_STATE);
         setExcludedCompanyIds(EMPTY_SET); // Reset exclusions
         if (currentPage !== DEFAULT_PAGE) { setCurrentPage(DEFAULT_PAGE); } // Reset page only if not already 1
     }, [currentPage]); // Dependency needed for page check
    const handleToggleCompanyExclusion = useCallback((companyId: number) => {
        setExcludedCompanyIds(prev => { const newSet = new Set(prev); if (newSet.has(companyId)) { newSet.delete(companyId); } else { newSet.add(companyId); } return newSet; });
    }, []); // Stable
    const handleSetSort = useCallback((newSortState: SortState) => { if (newSortState.key !== sortState.key || newSortState.direction !== sortState.direction) { setSortState(newSortState); } }, [sortState]);
    const handleSetPage = useCallback((page: number) => { const maxPage = Math.max(1, Math.ceil(totalCount / pageSize)); const validPage = Math.max(1, Math.min(page, maxPage)); if (validPage !== currentPage) { setCurrentPage(validPage); } }, [currentPage, totalCount, pageSize]);
    const handleSetPageSize = useCallback((size: number) => { if (pageSizeOptions.includes(size) && size !== pageSize) { setPageSizeState(size); } }, [pageSize]);
    const handleSetCurrentUserTier = useCallback((tier: ColumnTier) => { setCurrentUserTierState(tier); }, []);
    const handleSetCurrentCurrency = useCallback((currency: Currency) => { if (currency !== currentCurrency) { setCurrentCurrencyState(currency); } }, [currentCurrency]);
    const getMetricConfigByDbColumn = useCallback((db_column: string): MetricConfig | undefined => { return allMetricConfigs.find(m => m.db_column === db_column || m.key === db_column || m.nested_path === db_column); }, []);

    // --- CONTEXT VALUE (Ensuring all properties are included) ---
    const value = useMemo<FilterContextType>(() => ({
        currentUserTier, currentCurrency, filterSettings, metricFullRanges, displayData, totalCount,
        filteredCompanyIds, excludedCompanyIds, toggleCompanyExclusion: handleToggleCompanyExclusion, // Correctly providing state & handler
        loadingPaginated, loadingRanges, loadingFilteredSet, loading, error,
        setCurrentUserTier: handleSetCurrentUserTier, setCurrentCurrency: handleSetCurrentCurrency,
        setDevelopmentStatusFilter: handleSetDevelopmentStatus, setMetricRange: handleSetMetricRange,
        setSearchTerm: handleSetSearchTerm, resetFilters: handleResetFilters,
        getMetricConfigByDbColumn, sortState, currentPage, pageSize, setSort: handleSetSort,
        setPage: handleSetPage, setPageSize: handleSetPageSize, fetchCompaniesByIds,
    }), [
        // Include all state variables and stable callbacks provided in the value
        currentUserTier, currentCurrency, filterSettings, metricFullRanges, displayData, totalCount,
        filteredCompanyIds, excludedCompanyIds, loadingPaginated, loadingRanges, loadingFilteredSet,
        loading, error, handleSetCurrentUserTier, handleSetCurrentCurrency, handleSetDevelopmentStatus,
        handleSetMetricRange, handleSetSearchTerm, handleResetFilters, handleToggleCompanyExclusion,
        getMetricConfigByDbColumn, sortState, currentPage, pageSize, handleSetSort,
        handleSetPage, handleSetPageSize, fetchCompaniesByIds,
    ]);

    return <FilterContext.Provider value={value}>{children}</FilterContext.Provider>;
};

// --- Custom Hook ---
export const useFilters = (): FilterContextType => {
    const context = useContext(FilterContext);
    if (context === undefined) {
        console.error("useFilters must be used within a FilterProvider. Context was undefined.");
        throw new Error('useFilters must be used within a FilterProvider');
    }
    return context;
};