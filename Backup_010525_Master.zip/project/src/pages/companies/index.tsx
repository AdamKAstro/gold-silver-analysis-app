// src/pages/companies/index.tsx
import React, { useState, useEffect, useCallback, useMemo } from "react"; // Ensure all hooks are imported
import { useFilters } from "../../contexts/filter-context";
import { CompanyDataTable } from "../../components/company-data-table";
import { CurrencySelector } from "../../components/currency-selector";
import { LoadingIndicator } from "../../components/ui/loading-indicator";
import { Button } from "../../components/ui/button"; // Needed for StatusFilter buttons within this file if refactored, keep for now
import { PageContainer } from "../../components/ui/page-container";
import { cn } from "../../lib/utils";
import type { Company, SortState, CompanyStatus } from "../../lib/types";
import debounce from 'lodash/debounce';
// FilterX removed - PageContainer provides the reset button

const FILTERABLE_STATUSES: CompanyStatus[] = ['producer', 'developer', 'explorer', 'royalty', 'other'];
const SEARCH_DEBOUNCE_MS = 350;

export function CompaniesPage() {
    // Destructure needed values from context
    const {
        displayData, totalCount, loading, loadingPaginated, error, filterSettings,
        setDevelopmentStatusFilter, setSearchTerm, currentUserTier, sortState,
        currentPage, pageSize, setSort, setPage, setPageSize,
        excludedCompanyIds, toggleCompanyExclusion,
        // No need to get resetFilters, PageContainer handles it
    } = useFilters();

    // Local state ONLY for the search input debounce mechanism
    const [localSearchTerm, setLocalSearchTerm] = useState<string>(filterSettings.searchTerm || '');

    // Derive selectedStatuses directly from context for consistency
    const selectedStatuses = filterSettings.developmentStatus || [];

    // Effect to sync local search input if context changes elsewhere
    useEffect(() => {
        if (filterSettings.searchTerm !== localSearchTerm) {
            setLocalSearchTerm(filterSettings.searchTerm || '');
        }
    }, [filterSettings.searchTerm]); // Dependency: context search term

    // Apply the checkbox filter *locally* just before rendering the table
    const companiesForTable = useMemo(() => {
        const idsToExclude = excludedCompanyIds instanceof Set ? excludedCompanyIds : new Set<number>();
        // Ensure displayData is an array before filtering
        if (!Array.isArray(displayData)) {
            console.warn("[CompaniesPage] displayData from context is not an array:", displayData);
            return [];
        }
        return displayData.filter(company => !idsToExclude.has(company.company_id));
    }, [displayData, excludedCompanyIds]); // Dependencies: data from context and exclusion set from context

    // Callbacks for table interactions, passing actions up to context
    const handlePageChange = useCallback((newPage: number) => { setPage(newPage); window.scrollTo({ top: 0, behavior: 'smooth' }); }, [setPage]);
    const handlePageSizeChange = useCallback((newPageSize: number) => { setPageSize(newPageSize); }, [setPageSize]);
    const handleSort = useCallback((dbSortKey: string, direction: 'asc' | 'desc') => { setSort({ key: dbSortKey, direction }); }, [setSort]);

    // Callback for local status filter changes, updating context
    const handleStatusChange = useCallback((status: CompanyStatus) => {
        const newStatuses = selectedStatuses.includes(status)
            ? selectedStatuses.filter(s => s !== status)
            : [...selectedStatuses, status];
        setDevelopmentStatusFilter(newStatuses); // Update context
    }, [selectedStatuses, setDevelopmentStatusFilter]); // Dependencies: current statuses and context setter

    // Debounced search term update for context
    const debouncedContextSearchUpdate = useMemo(
        () => debounce((value: string) => { setSearchTerm(value); }, SEARCH_DEBOUNCE_MS),
        [setSearchTerm] // Dependency: context setter
    );

    // Callback for search input changes
    const handleSearchInputChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
        const value = event.target.value;
        setLocalSearchTerm(value); // Update local input immediately
        debouncedContextSearchUpdate(value); // Update context debounced
     }, [debouncedContextSearchUpdate]); // Dependency: debounced function

    const effectiveTier = currentUserTier;

    // Page actions passed to PageContainer (NO Reset Button here)
    const pageActions = (
        <>
            <CurrencySelector />
        </>
    );

    // Description text based on filtered data for table
    const descriptionText = loadingPaginated ? "Loading companies..."
        : error ? "Error loading data"
        : `${companiesForTable.length} companies shown${totalCount > 0 ? ` (of ${totalCount} total based on filters)` : ''}`;

    return (
        <PageContainer
            title="Mining Companies Database"
            description={descriptionText}
            actions={pageActions} // Only pass non-reset actions
            className="relative isolate flex flex-col flex-grow"
            contentClassName="flex flex-col flex-grow min-h-0"
        >
           {/* Background */}
           <div className="absolute inset-0 bg-cover bg-center bg-no-repeat bg-fixed -z-10 opacity-[0.03]" style={{ backgroundImage: "url('/Background2.jpg')" }} aria-hidden="true" />

            <div className="space-y-4 flex flex-col flex-grow min-h-0">
                {/* Search and Status Filters Section */}
                 <div className="flex items-center flex-wrap gap-3 bg-navy-400/20 p-3 rounded-lg shadow flex-shrink-0">
                     {/* Search Input */}
                     <div className="relative flex-grow min-w-[200px] sm:min-w-[250px] md:max-w-md">
                         <input
                             type="text"
                             placeholder="Search name, ticker..."
                             className="w-full pl-3 pr-8 py-2 bg-navy-500/80 border border-navy-300/20 rounded-md text-xs text-surface-white placeholder-surface-white/50 focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-offset-navy-500 focus:ring-accent-teal transition-shadow"
                             value={localSearchTerm}
                             onChange={handleSearchInputChange}
                             aria-label="Search Companies"
                         />
                     </div>
                     {/* Status Checkboxes */}
                     <div className="flex items-center gap-2 flex-wrap">
                         {FILTERABLE_STATUSES.map(status => (
                             <label key={status} className="flex items-center gap-1.5 sm:gap-2 cursor-pointer p-1 hover:bg-navy-400/30 rounded">
                                 <input
                                     type="checkbox"
                                     checked={selectedStatuses.includes(status)}
                                     onChange={() => handleStatusChange(status)}
                                     className="h-3.5 w-3.5 rounded border-gray-400 bg-navy-600 text-accent-teal focus:ring-accent-teal focus:ring-offset-navy-700"
                                 />
                                 <span className="text-xs sm:text-sm text-surface-white/90 capitalize select-none">{status}</span>
                             </label>
                         ))}
                     </div>
                 </div>

                {/* Data Table Container */}
                <div className="bg-navy-700/30 backdrop-blur-sm rounded-lg shadow-lg border border-navy-600/50 flex flex-col flex-grow overflow-hidden min-h-[500px]">
                   {/* Loading/Error/DataTable rendering */}
                   {loading && !companiesForTable.length ? ( // Show loading if context is loading AND table data isn't ready
                       <div className="flex justify-center items-center h-64 p-4"> <LoadingIndicator message="Loading companies..." /> </div>
                   ) : error ? (
                       <div className="flex justify-center items-center h-64 p-4 text-red-400"> <p>{error}</p> </div>
                   ) : (
                       <CompanyDataTable
                           companies={companiesForTable} // Pass locally filtered data
                           onSort={handleSort}
                           currentSort={sortState}
                           currentTier={effectiveTier}
                           page={currentPage}
                           pageSize={pageSize}
                           totalCount={totalCount} // Use total from context for pagination
                           onPageChange={handlePageChange}
                           onPageSizeChange={handlePageSizeChange}
                           excludedCompanyIds={excludedCompanyIds instanceof Set ? excludedCompanyIds : new Set()} // Pass context set
                           onCompanyToggle={toggleCompanyExclusion} // Pass context toggle function
                       />
                   )}
                </div>
            </div>
        </PageContainer>
    );
}