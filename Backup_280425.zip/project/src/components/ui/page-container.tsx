// src/components/ui/page-container.tsx
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
// Icons for Nav items - Ensure all needed icons are imported
import { Home, Table2, LineChart, Filter, Calculator, Crown, RotateCcw } from 'lucide-react';
import { Button } from './button';
import { cn } from '../../lib/utils';
import { useFilters } from '../../contexts/filter-context'; // Needed for resetFilters

interface PageContainerProps {
    title: string;
    description?: string;
    children: React.ReactNode;
    actions?: React.ReactNode; // For page-specific actions like CurrencySelector
    className?: string;
    showNav?: boolean; // Prop to control visibility of nav icons/reset button
}

// Navigation items definition
const navItems = [
    { path: "/companies", label: "Companies", icon: Table2 },
    { path: "/scatter-chart", label: "Analysis", icon: LineChart }, // Changed from Scatter Chart for consistency maybe?
    { path: "/filter", label: "Filters", icon: Filter },
    { path: "/scoring", label: "Scoring", icon: Calculator }, // Changed from Rankings
    { path: "/subscribe", label: "Subscribe", icon: Crown },
];

export function PageContainer({
    title,
    description,
    children,
    actions,
    className,
    showNav = true // Default to showing navigation/reset
}: PageContainerProps) {
    const { resetFilters } = useFilters();
    const location = useLocation();
    const logoImage = "/new-logo.png"; // Define logo path

    return (
        // Main container with background color (background image applied in page)
        <div className={cn("min-h-screen bg-navy-900", className)}> {/* Use bg-navy-900 for consistency */}
            {/* Actual content area with padding */}
            <div className="container mx-auto px-4 py-4 space-y-4">

                {/* Top Bar: Logo/Title on Left, Nav/Actions on Right */}
                <div className="flex items-center justify-between flex-wrap gap-4 border-b border-navy-700 pb-3 mb-4">
                    {/* Left Side: Logo and Title/Description */}
                    <div className="flex items-center gap-3">
                        {/* Logo Link */}
                        <Link to="/" title="Go to Homepage">
                            <img
                                src={logoImage}
                                alt="Maple Aurum Logo"
                                className="h-9 w-9 object-contain flex-shrink-0" // Slightly adjusted size
                            />
                        </Link>
                         {/* Title and Description */}
                        <div>
                            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                                {title}
                            </h1>
                            {description && (
                                <p className="text-xs sm:text-sm text-gray-400">
                                    {description}
                                </p>
                            )}
                        </div>
                    </div>

                    {/* Right Side: Nav Icons, Reset Button, Page Actions */}
                    <div className="flex items-center gap-2 flex-wrap">
                        {/* Conditional Navigation Icons */}
                        {showNav && navItems
                            .filter(item => item.path !== location.pathname) // Filter out current page
                            .map((item) => (
                                <Link
                                    key={item.path}
                                    to={item.path}
                                    className="hidden sm:block" // Hide icons on very small screens
                                >
                                    <Button
                                        variant="ghost"
                                        size="icon-sm" // Make icons slightly smaller
                                        className="text-gray-400 hover:text-white hover:bg-navy-700/50"
                                        title={item.label} // Tooltip text
                                    >
                                        <item.icon className="h-4 w-4" />
                                    </Button>
                                </Link>
                            ))}

                         {/* Conditional Reset Button */}
                        {showNav && location.pathname !== '/' && ( // Show reset everywhere except home
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={resetFilters}
                                className="text-xs border-navy-600 text-gray-300 hover:bg-navy-700 hover:text-white flex items-center gap-1.5" // Added flex/gap
                                title="Reset all filters"
                            >
                                <RotateCcw className="h-3.5 w-3.5" /> {/* Slightly smaller icon */}
                                <span className="hidden md:inline">Reset Filters</span> {/* Hide text on small screens */}
                                <span className="md:hidden">Reset</span> {/* Show shorter text */}
                            </Button>
                        )}

                        {/* Page Specific Actions */}
                        {actions && (
                            <div className="flex items-center gap-2 border-l border-navy-700 pl-2 ml-1"> {/* Separator */}
                                {actions}
                            </div>
                        )}
                    </div>
                </div>

                {/* Page Content */}
                {/* The background image div will be placed HERE by the page component */}
                <div className="relative">
                     {children}
                 </div>

            </div>
        </div>
    );
}