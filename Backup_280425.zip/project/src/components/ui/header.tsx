import React from 'react';
import { Link } from 'react-router-dom';
import { Home } from 'lucide-react'; // Removed Database icon import
import { useFilters } from '../../contexts/filter-context';
import { CurrencySelector } from '../../components/currency-selector'; // Adjusted path assuming components are siblings
import { TierSelector } from '../../components/tier-selector';     // Adjusted path assuming components are siblings
import { Button } from './button'; // Assuming button is in the same ui folder

export function Header() {
    const { currentUserTier, setCurrentUserTier } = useFilters();

    return (
        <header className="sticky top-0 z-40 w-full border-b border-navy-300/20 bg-navy-500/95 backdrop-blur supports-[backdrop-filter]:bg-navy-500/60">
            <div className="container flex h-14 items-center justify-between mx-auto px-4">
                {/* Brand / Logo */}
                <div className="mr-4 flex">
                    <Link className="mr-6 flex items-center gap-2" to="/">
                        {/* --- Replaced Icon with Logo Image --- */}
                        <img
                            src="/new-logo.png" // Assumes logo is in /public folder
                            alt="Maple Aurum Logo" // Added alt text
                            className="h-8 w-8 object-contain" // Adjusted classes: h-8 w-8, object-contain is often good for logos
                        />
                        {/* ------------------------------------ */}
                        <span className="font-bold text-surface-white hidden sm:inline-block">
                            Maple Aurum {/* - Mining Analytics */} {/* Optional: Shorten name if needed */}
                        </span>
                    </Link>
                </div>

                {/* Right Side Items */}
                <div className="flex items-center gap-2 md:gap-4"> {/* Adjusted gap slightly */}
                    <TierSelector
                        currentTier={currentUserTier}
                        onTierChange={setCurrentUserTier}
                    />
                    <CurrencySelector />
                    {/* Removed Home button as Logo links home */}
                    {/*
                    <Link to="/">
                        <Button
                            variant="ghost"
                            size="sm"
                            className="text-surface-white/70 hover:text-surface-white"
                        >
                            <Home className="h-4 w-4" />
                        </Button>
                    </Link>
                    */}
                </div>
            </div>
        </header>
    );
}