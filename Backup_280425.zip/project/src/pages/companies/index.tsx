import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useSearchParams, Link } from 'react-router-dom';
import { useFilters } from "../../contexts/filter-context";
import { CompanyDataTable } from "../../components/company-data-table"; // !! IMPORTANT: Needs virtualization for performance !!
import { CurrencySelector } from "../../components/currency-selector";
import { LoadingIndicator } from "../../components/ui/loading-indicator";
import { Button } from "../../components/ui/button";
import { PageContainer } from "../../components/ui/page-container";
// Removed useSubscription and useCurrency as they weren't used directly here (tier/currency come from useFilters/other contexts if needed by children)
import { cn } from "../../lib/utils";
import type { Company, SortState, CompanyStatus } from "../../lib/types"; // Removed unused FilterState, ColumnTier

// Define constants
const FILTERABLE_STATUSES: CompanyStatus[] = ['producer', 'developer', 'explorer', 'royalty', 'other'];
const initialSortState: SortState = { key: 'company_name', direction: 'asc' };
const DEFAULT_PAGE_SIZE = 25;
const SEARCH_DEBOUNCE_MS = 350;

// Debounce utility (keep as is)
function debounce<F extends (...args: any[]) => any>(func: F, waitFor: number) {
    let timeout: NodeJS.Timeout | null = null;
    const debounced = (...args: Parameters<F>) => {
        if (timeout !== null) { clearTimeout(timeout); timeout = null; }
        timeout = setTimeout(() => func(...args), waitFor);
    };
    return debounced;
}

export function CompaniesPage() {
    const [searchParams, setSearchParams] = useSearchParams();
    const {
        displayData,
        loading: contextLoading,
        error: contextError,
        totalCount: contextTotalCount,
        filterSettings,
        setDevelopmentStatusFilter,
        setSearchTerm,
        resetFilters,
        currentUserTier // Keep tier for passing down
    } = useFilters();

    // Memoize companies data derived from context
    const companies = useMemo(() => displayData || [], [displayData]);
    const loading = contextLoading; // Use context loading state directly
    const error = contextError;     // Use context error state directly
    // Use context total count, provide fallback if needed (e.g., for pagination if context doesn't estimate)
    const totalCount = contextTotalCount ?? companies.length;

    // --- State Management ---
    // REMOVED: isTableVisible state

    // State derived from URL Search Params, with defaults
    const [page, setPage] = useState(() => Number(searchParams.get('page')) || 1);
    const [pageSize, setPageSize] = useState(() => Number(searchParams.get('pageSize')) || DEFAULT_PAGE_SIZE);
    const [sortState, setSortState] = useState<SortState>(() => ({
        key: searchParams.get('sortKey') || initialSortState.key,
        direction: (searchParams.get('sortDir') as 'asc' | 'desc') || initialSortState.direction,
    }));

    // Local state for controlled search input, synced with context via debounce
    const [localSearchTerm, setLocalSearchTerm] = useState<string>(filterSettings.searchTerm || '');
    // Derived state for status checkboxes based on context
    const selectedStatuses = useMemo(() => filterSettings.developmentStatus || [], [filterSettings.developmentStatus]);

    // --- URL Synchronization ---
    // Memoized function to update URL params without causing extra renders if params haven't changed
    const updateUrlParams = useCallback((newParams: Record<string, string | number | null>) => {
        const current = new URLSearchParams(searchParams);
        let changed = false;
        Object.entries(newParams).forEach(([key, value]) => {
            const stringValue = (value === null || value === undefined) ? null : String(value);
            const currentValue = current.get(key);
            if (stringValue === null || stringValue === '') {
                if (currentValue !== null) {
                    current.delete(key);
                    changed = true;
                }
            } else if (stringValue !== currentValue) {
                current.set(key, stringValue);
                changed = true;
            }
        });

        // Only update if something actually changed to prevent potential loops
        if (changed) {
            setSearchParams(current, { replace: true });
        }
    }, [searchParams, setSearchParams]);

    // Effect to sync state changes TO URL
    useEffect(() => {
        updateUrlParams({
            page,
            pageSize,
            sortKey: sortState.key,
            sortDir: sortState.direction,
            search: filterSettings.searchTerm || null, // Use context state for source of truth
            status: filterSettings.developmentStatus?.join(',') || null, // Use context state
        });
    }, [page, pageSize, sortState, filterSettings, updateUrlParams]);

    // Effect to sync URL changes TO local state (e.g., browser back/forward)
     useEffect(() => {
         setPage(Number(searchParams.get('page')) || 1);
         setPageSize(Number(searchParams.get('pageSize')) || DEFAULT_PAGE_SIZE);
         setSortState({
             key: searchParams.get('sortKey') || initialSortState.key,
             direction: (searchParams.get('sortDir') as 'asc' | 'desc') || initialSortState.direction,
         });
         // Sync search term if URL changes (might conflict slightly with debounce, but handles back button)
         const urlSearch = searchParams.get('search') || '';
         if (urlSearch !== localSearchTerm) {
             setLocalSearchTerm(urlSearch);
             // Optionally update context directly here too, or rely on component logic
             // setSearchTerm(urlSearch); // Careful not to cause loops
         }
         // Sync status if URL changes
         const urlStatuses = searchParams.get('status')?.split(',') || [];
         if (urlStatuses.join(',') !== selectedStatuses.join(',')) {
              // Ensure statuses are valid before setting
              const validUrlStatuses = urlStatuses.filter(s => FILTERABLE_STATUSES.includes(s as CompanyStatus));
              setDevelopmentStatusFilter(validUrlStatuses as CompanyStatus[]);
         }

     }, [searchParams, setDevelopmentStatusFilter, localSearchTerm, selectedStatuses]);


    // --- Handlers ---
    const handlePageChange = useCallback((newPage: number) => {
        setPage(newPage);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }, []);

    const handlePageSizeChange = useCallback((newPageSize: number) => {
        setPageSize(newPageSize);
        setPage(1); // Reset to first page on size change
    }, []);

    const handleSort = useCallback((key: string, direction: 'asc' | 'desc') => {
        setSortState({ key, direction });
        setPage(1); // Reset to first page on sort change
    }, []);

    // Update context state for status filters
    const handleStatusChange = useCallback((newStatuses: CompanyStatus[]) => {
        setDevelopmentStatusFilter(newStatuses);
        setPage(1); // Reset to first page on filter change
    }, [setDevelopmentStatusFilter]);

    // Debounced update for the search term in the context
    const debouncedFilterUpdate = useMemo(
        () => debounce((value: string) => {
            setSearchTerm(value); // Update context
            setPage(1); // Reset to first page on search
        }, SEARCH_DEBOUNCE_MS),
        [setSearchTerm] // Dependency: context setter function
    );

    // Handler for the search input field changes
    const handleSearchInputChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
        const newValue = event.target.value;
        setLocalSearchTerm(newValue); // Update local state immediately for responsiveness
        debouncedFilterUpdate(newValue); // Trigger debounced update to context
    }, [debouncedFilterUpdate]);

    // Get the effective tier to pass down (could use useSubscription directly if needed)
    const effectiveTier = currentUserTier;

    // Actions specific to this page (Currency Selector)
    const pageActions = (
        <CurrencySelector />
    );

    // --- Render Logic ---
    return (
        <PageContainer
            title="Mining Companies Database"
            description={loading ? "Loading data..." : error ? "Error loading data" : `Explore ${totalCount ?? 0} companies`}
            actions={pageActions}
            // Add a wrapper div for the background
            className="relative isolate" // isolate ensures z-index context for pseudo-elements or absolute children
        >
             {/* Background Image Div - Positioned behind content */}
            <div
                className="absolute inset-0 bg-cover bg-center bg-no-repeat bg-fixed -z-10 opacity-[0.03]" // Very low opacity, fixed attachment
                style={{ backgroundImage: "url('/Background2.jpg')" }} // Assumes image in /public
                aria-hidden="true"
             />
             {/* Optional: Add a subtle overlay */}
             {/* <div className="absolute inset-0 bg-navy-900/10 -z-10" aria-hidden="true" /> */}

            {/* Main Content Area */}
            <div className="space-y-4">
                {/* Filter Controls */}
                <div className="flex items-center flex-wrap gap-3 bg-navy-400/20 p-3 rounded-lg shadow">
                    {/* Search Input */}
                    <div className="relative flex-grow min-w-[200px] sm:min-w-[250px] md:max-w-md">
                        <input
                            type="text"
                            placeholder="Search name, ticker..."
                            className="w-full pl-3 pr-8 py-2 bg-navy-500/80 border border-navy-300/20 rounded-md text-xs text-surface-white placeholder-surface-white/50 focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-offset-navy-500 focus:ring-accent-teal transition-shadow"
                            value={localSearchTerm}
                            onChange={handleSearchInputChange}
                            aria-label="Search Companies"
                        />
                        {/* Optional: Add search icon */}
                    </div>

                    {/* Status Checkboxes */}
                    <div className="flex items-center gap-2 flex-wrap">
                        {FILTERABLE_STATUSES.map(status => (
                            <label key={status} className="flex items-center gap-1.5 sm:gap-2 cursor-pointer p-1 hover:bg-navy-400/30 rounded">
                                <input
                                    type="checkbox"
                                    checked={selectedStatuses.includes(status)}
                                    onChange={() => {
                                        handleStatusChange(
                                            selectedStatuses.includes(status)
                                                ? selectedStatuses.filter(s => s !== status)
                                                : [...selectedStatuses, status]
                                        );
                                    }}
                                    // Consider using a styled checkbox component if available
                                    className="h-3.5 w-3.5 rounded border-gray-400 bg-navy-600 text-accent-teal focus:ring-accent-teal focus:ring-offset-navy-700"
                                />
                                <span className="text-xs sm:text-sm text-surface-white/90 capitalize select-none">
                                    {status}
                                </span>
                            </label>
                        ))}
                    </div>
                </div> {/* End Filter Controls */}

                {/* Data Table Area */}
                <div className="bg-navy-500/60 backdrop-blur-sm rounded-lg shadow-lg border border-navy-400/20 min-h-[400px] flex flex-col overflow-hidden">
                    {/* Loading State */}
                    {loading && !error && (
                        <div className="flex-grow flex items-center justify-center p-6">
                            <LoadingIndicator message="Loading companies..." />
                        </div>
                    )}

                    {/* Error State */}
                    {error && (
                        <div className="flex-grow flex flex-col items-center justify-center text-center p-6 text-red-400">
                            <p className="font-semibold mb-2">Error Loading Data</p>
                            <p className="text-xs">{error}</p>
                            {/* Use the main reset button from PageContainer now */}
                            {/* <Button onClick={resetFilters} variant="destructive" size="sm" className="mt-4"> Clear Filters & Retry </Button> */}
                        </div>
                    )}

                    {/* Table Display (Direct Conditional Rendering) */}
                    {/* !! URGENT: Implement Virtualization in CompanyDataTable for performance !! */}
                    {!loading && !error && companies.length > 0 && (
                        <CompanyDataTable
                            companies={companies}
                            onSort={handleSort}
                            currentSort={sortState}
                            currentTier={effectiveTier} // Pass effective tier
                            // Pagination props
                            page={page}
                            pageSize={pageSize}
                            totalCount={totalCount}
                            onPageChange={handlePageChange}
                            onPageSizeChange={handlePageSizeChange}
                        />
                    )}

                    {/* No Results State */}
                    {!loading && !error && companies.length === 0 && (
                        <div className="flex-grow flex flex-col items-center justify-center text-center text-surface-white/70 py-16 px-6">
                            <p className="font-semibold">No companies found</p>
                            <p className="text-xs mt-1">Try adjusting your search or filters.</p>
                            {/* Use the main reset button from PageContainer now */}
                             {/* <Button onClick={resetFilters} variant="secondary" size="sm" className="mt-4"> Reset Filters </Button> */}
                        </div>
                    )}
                </div> {/* End Data Table Area */}
            </div> {/* End Main Content Area */}
        </PageContainer>
    );
}