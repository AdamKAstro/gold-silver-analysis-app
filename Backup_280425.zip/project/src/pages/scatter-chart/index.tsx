//src/pages/scatter-chart/index.tsx
import React, { useState, useCallback, useMemo, useEffect, useRef } from 'react';
// Icons: Added FilterX for reset button
import { Download, Settings, ZoomIn, ZoomOut, RotateCcw, FilterX } from 'lucide-react';
import { Chart as ChartJS, LinearScale, PointElement, LogarithmicScale, Tooltip, Legend, ChartOptions, ScatterDataPoint, ScriptableContext } from 'chart.js';
import { Scatter } from 'react-chartjs-2';
import zoomPlugin from 'chartjs-plugin-zoom';
import gradient from 'chartjs-plugin-gradient';
import ChartDataLabels, { Context as DataLabelsContext } from 'chartjs-plugin-datalabels'; // Use specific name for Context type

// *** Context Hooks ***
import { useFilters } from '../../contexts/filter-context'; // Use global filters
import { useCurrency } from '../../contexts/currency-context';

// Lib Utilities and Types
import { cn, getNestedValue } from '../../lib/utils';
// REMOVED: import { getCompaniesForScatterChart } from '../../lib/supabase'; // No longer fetching locally
import { getMetricByKey, getAccessibleMetrics, MetricConfig } from '../../lib/metric-types'; // Added MetricConfig type import
import { normalizeValues, formatValueWrapper, exportChartCode, downloadJson } from './chartUtils'; // Removed getDomain as it wasn't used
import type { Company, ColumnTier, Currency, MetricFormat } from '../../lib/types'; // Added MetricFormat

// UI Components
import { Button } from '../../components/ui/button';
import { MetricSelector } from '../../components/metric-selector';
import { LoadingIndicator } from '../../components/ui/loading-indicator';
import { PageContainer } from '../../components/ui/page-container';
import { FeatureAccess } from '../../components/ui/feature-access';

// Register Chart.js plugins
ChartJS.register(
    LinearScale, LogarithmicScale, PointElement, Tooltip, Legend, zoomPlugin, gradient, ChartDataLabels
);

// --- ScaleToggle Component (Keep as is) ---
function ScaleToggle({ scale, onChange, label }: { scale: 'linear' | 'log', onChange: (scale: 'linear' | 'log') => void, label: string }) {
    // (Component code remains the same as provided previously)
    return (
        <div className="flex items-center gap-2 text-xs">
            <span className="text-surface-white/70">{label}:</span>
            <div className="flex bg-navy-400/20 rounded-lg overflow-hidden p-0.5 gap-0.5">
                <button
                    className={cn(
                        "px-3 py-1.5 text-xs font-medium rounded-md transition-all duration-200",
                        scale === 'linear'
                            ? "bg-navy-400 text-surface-white shadow-lg shadow-navy-300/30 ring-1 ring-navy-300/30"
                            : "text-surface-white/70 hover:bg-navy-400/30"
                    )}
                    onClick={() => onChange('linear')} aria-pressed={scale === 'linear'}
                > Linear </button>
                <button
                    className={cn(
                        "px-3 py-1.5 text-xs font-medium rounded-md transition-all duration-200",
                         scale === 'log'
                            ? "bg-navy-400 text-surface-white shadow-lg shadow-navy-300/30 ring-1 ring-navy-300/30"
                            : "text-surface-white/70 hover:bg-navy-400/30"
                    )}
                    onClick={() => onChange('log')} aria-pressed={scale === 'log'}
                > Log </button>
            </div>
        </div>
     );
}

// --- Chart Settings Constants (Keep as is) ---
const chartSettingsFunctions = { // (Functions remain the same)
    pointRadius: (normalizedValue: number): number => 6 + (Math.max(0, Math.min(1, normalizedValue || 0)) * 35),
    pointHoverRadius: (normalizedValue: number): number => 8 + (Math.max(0, Math.min(1, normalizedValue || 0)) * 48),
};
const statusColors: Record<string, { background: string; border: string }> = { // (Mapping remains the same)
    producer: { background: 'rgba(34, 197, 94, 0.7)', border: 'rgb(12, 163, 74)' },
    developer: { background: 'rgba(59, 130, 246, 0.7)', border: 'rgb(37, 99, 195)' },
    explorer: { background: 'rgba(168, 85, 247, 0.7)', border: 'rgb(147, 51, 194)' },
    royalty: { background: 'rgba(244, 162, 97, 0.7)', border: 'rgb(217, 119, 6)' },
    other: { background: 'rgba(107, 114, 128, 0.7)', border: 'rgb(75, 85, 99)' },
    default: { background: 'rgba(107, 114, 128, 0.7)', border: 'rgb(75, 85, 99)' },
};


// --- ScatterChartPage Component ---
export function ScatterChartPage() {
    // *** Hooks ***
    // Get filter state and actions from context
    const {
        displayData, // Use filtered data from context
        loading: isContextLoading, // Rename to avoid conflict
        error: contextError, // Rename to avoid conflict
        resetFilters, // Get reset action
        currentUserTier
    } = useFilters();
    const { currency } = useCurrency();

    // *** State ***
    // REMOVED: local rawData, loading, error states
    // Local state for chart axis/scale settings
    const [xMetric, setXMetric] = useState('financials.market_cap_value');
    const [yMetric, setYMetric] = useState('valuation_metrics.ev_per_resource_oz_all');
    const [zMetric, setZMetric] = useState('production.current_production_total_aueq_koz');
    const [xScale, setXScale] = useState<'linear' | 'log'>('log');
    const [yScale, setYScale] = useState<'linear' | 'log'>('log');
    const [zScale, setZScale] = useState<'linear' | 'log'>('linear');
    // REMOVED: isMounted state

    // *** Refs ***
    const chartRef = useRef<ChartJS<'scatter', (number | ScatterDataPoint | null)[], unknown> | null>(null);
    const containerRef = useRef<HTMLDivElement>(null); // Keep for chart container size

    // *** Effects ***
    // REMOVED: useEffect for local fetchData
    // REMOVED: useEffect for isMounted
    // Effect to destroy chart on unmount
    useEffect(() => {
        const chart = chartRef.current; // Capture ref in effect closure
        return () => {
            chart?.destroy();
            chartRef.current = null;
        };
    }, []); // Empty dependency array, runs once on mount/unmount

    // *** Memos ***
    const accessibleMetrics = useMemo(() => getAccessibleMetrics(currentUserTier), [currentUserTier]);
    const xMetricConfig = useMemo(() => getMetricByKey(xMetric), [xMetric]);
    const yMetricConfig = useMemo(() => getMetricByKey(yMetric), [yMetric]);
    const zMetricConfig = useMemo(() => getMetricByKey(zMetric), [zMetric]);

    // Memo for chart data transformation (using displayData from context)
    const chartDatasets = useMemo(() => {
        console.log(`[ScatterChart] Recalculating datasets. displayData length: ${displayData?.length ?? 'N/A'}`);
        // Use displayData instead of rawData
        if (!Array.isArray(displayData) || !displayData.length || !xMetricConfig?.nested_path || !yMetricConfig?.nested_path || !zMetricConfig?.nested_path) {
            return [];
        }

        // Map displayData to points
        const points = displayData.map(company => ({
            x: getNestedValue(company, xMetricConfig.nested_path),
            y: getNestedValue(company, yMetricConfig.nested_path),
            z: getNestedValue(company, zMetricConfig.nested_path),
            company, // Keep entire company object from displayData
        })).filter(point => // Filter out invalid points based on selected scales
            Number.isFinite(point.x) && Number.isFinite(point.y) && Number.isFinite(point.z) &&
            (xScale !== 'log' || (typeof point.x === 'number' && point.x > 0)) &&
            (yScale !== 'log' || (typeof point.y === 'number' && point.y > 0)) &&
            (zScale !== 'log' || (typeof point.z === 'number' && point.z > 0))
        );

        console.log(`[ScatterChart] Generated ${points.length} valid points from ${displayData.length} companies in displayData.`);

        const zValues = points.map(p => p.z as number);
        const normalizedZ = normalizeValues(zValues, zScale); // Normalize Z values (0-1)

        // Group valid points by status
        const groupedPoints = points.reduce((acc, point, i) => {
            // Use the status field confirmed from previous debugging
            const status = point.company.status?.toLowerCase() || 'default';
            if (!acc[status]) {
                acc[status] = {
                    label: status.charAt(0).toUpperCase() + status.slice(2),
                    data: [],
                    backgroundColor: statusColors[status]?.background || statusColors.default.background,
                    borderColor: statusColors[status]?.border || statusColors.default.border,
                    borderWidth: 2, hoverBorderWidth: 4,
                    // Datalabels config per dataset
                    datalabels: {
                        // --- COLOR OPTIONS ---
                        //color: '#F9C74F', // Adjusted color
                        //color: '#F8FAFC', // Slate-50 (brightest off-white)
                      // color: '#FFFFFF', // White (good contrast on dark background)
                        color: '#E2E8F0', // Slate-200 (slightly softer white)
                      // color: '#FACC15', // Yellow-400 (like your original)
                      // color: '#5EEAD4', // Teal-300
                       // color: '#A5B4FC', // Indigo-300


                      
                        //font: { size: 9, weight: '600', family: "'Courier New', Courier, monospace" },
                       
                        //font: { size: 12, weight: '680', family: 'Inter, sans-serif' },
                        font: { size: 12, weight: '580', family: 'Arial, sans-serif' },
       // Weight (numeric or string):
       // weight: '500', // Medium
        // weight: '600', // Semi-bold (like original)
        // weight: 'bold', // Bold
        // weight: 400, // Normal

        // Family (ensure fonts are loaded/available):
        //family: "'Inter', sans-serif", // Your current default sans-serif
        // family: "'Roboto Mono', monospace", // A clean monospace font
        // family: "'Source Code Pro', monospace", // Another popular monospace
        // family: "'Arial', sans-serif", // Web-safe fallback
        // family: "'Courier New', Courier, monospace", // Classic monospace (like original)


                      
                        backgroundColor: 'rgba(30, 21, 19, 0.5)',
                      
                        borderRadius: 3, padding: { top: 2, bottom: 1, left: 4, right: 4 }, textAlign: 'center', anchor: 'center', align: 'center', offset: 0, clamp: true,
                        display: true, // Display logic (consider size threshold later)
                        formatter: (value: any, context: DataLabelsContext): string | null => {
                             // Accessing data for formatter - needs careful handling
                             // Re-fetch datasets dynamically within formatter or structure data differently?
                             // Let's try accessing via context - assumes `chartDatasets` is stable enough
                             const dataset = context.chart.data.datasets[context.datasetIndex];
                             const dataPoint = dataset?.data?.[context.dataIndex] as any;
                             const company = dataPoint?.company;
                             const tsxCode = company?.tsx_code;
                             // const rNormValue = dataPoint?.r_normalized;
                             // if (rNormValue < 0.1) return null; // Example threshold
                             return tsxCode || null;
                        }
                    } // End datalabels
                }; // End dataset init
            }
            // Add point to the correct group's data array
            acc[status].data.push({
                x: point.x as number,
                y: point.y as number,
                r_normalized: normalizedZ[i] ?? 0, // Store normalized Z value (0-1)
                company: point.company // Keep company data
            });
            return acc;
        }, {} as Record<string, any>); // Initial empty object

        return Object.values(groupedPoints);

    // **Dependencies updated to use displayData from context**
    }, [displayData, xMetricConfig, yMetricConfig, zMetricConfig, xScale, yScale, zScale]);


    // Memo for chart options (remains largely the same, accesses data via context.raw)
    const chartOptions = useMemo(() => {
        const options: ChartOptions<'scatter'> = {
            responsive: true, maintainAspectRatio: false, animation: false,
            elements: {
                point: {
                    radius: (context: ScriptableContext<'scatter'>) => {
                        const dataPoint = context.raw as any;
                        if (!dataPoint || typeof dataPoint.r_normalized !== 'number') return 5;
                        return chartSettingsFunctions.pointRadius(dataPoint.r_normalized);
                    },
                    hoverRadius: (context: ScriptableContext<'scatter'>) => {
                         const dataPoint = context.raw as any;
                         if (!dataPoint || typeof dataPoint.r_normalized !== 'number') return 7;
                        return chartSettingsFunctions.pointHoverRadius(dataPoint.r_normalized);
                    },
                }
            },
            scales: {
                x: {
                    type: xScale === 'log' ? 'logarithmic' : 'linear', position: 'bottom',
                    title: { display: true, text: xMetricConfig?.label ? `${xMetricConfig.label}${xScale === 'log' ? ' (Log)' : ''}` : 'X Axis', color: '#E5E7EB', font: { size: 12 } },
                    ticks: { color: '#9CA3AF', font: { size: 10 }, callback: (value: number | string) => formatValueWrapper(typeof value === 'number' ? value : NaN, xMetricConfig?.format, currency as Currency), maxTicksLimit: 8 },
                    grid: { color: 'rgba(75, 85, 99, 0.2)', borderColor: 'rgba(75, 85, 99, 0.5)' }
                },
                y: {
                    type: yScale === 'log' ? 'logarithmic' : 'linear', position: 'left',
                    title: { display: true, text: yMetricConfig?.label ? `${yMetricConfig.label}${yScale === 'log' ? ' (Log)' : ''}` : 'Y Axis', color: '#E5E7EB', font: { size: 12 } },
                    ticks: { color: '#9CA3AF', font: { size: 10 }, callback: (value: number | string) => formatValueWrapper(typeof value === 'number' ? value : NaN, yMetricConfig?.format, currency as Currency), maxTicksLimit: 8 },
                    grid: { color: 'rgba(75, 85, 99, 0.2)', borderColor: 'rgba(75, 85, 99, 0.5)' }
                }
            },
            plugins: {
                legend: { position: 'bottom', labels: { color: '#E5E7EB', usePointStyle: true, pointStyle: 'circle', padding: 20, font: { size: 11 } } },
                tooltip: {
                    enabled: true, backgroundColor: 'rgba(17, 24, 39, 0.9)', titleColor: '#F3F4F6', bodyColor: '#D1D5DB', borderColor: 'rgba(75, 85, 99, 0.5)', borderWidth: 1, padding: 12, boxPadding: 4, usePointStyle: true,
                    callbacks: {
                        label: (context: any) => {
                            // Access data point via context.raw
                            const dataPoint = context.raw as any;
                            if (!dataPoint || !dataPoint.company) return '';

                            const lines = [];
                            lines.push(` ${dataPoint.company.company_name} (${dataPoint.company.tsx_code || 'N/A'})`);
                            if (xMetricConfig) lines.push(` ${xMetricConfig.label}: ${formatValueWrapper(dataPoint.x, xMetricConfig.format, currency as Currency)}`);
                            if (yMetricConfig) lines.push(` ${yMetricConfig.label}: ${formatValueWrapper(dataPoint.y, yMetricConfig.format, currency as Currency)}`);
                            if (zMetricConfig) {
                                // Get original Z value from company object for display
                                const rawZ = getNestedValue(dataPoint.company, zMetricConfig.nested_path);
                                const pixelRadius = chartSettingsFunctions.pointRadius(dataPoint.r_normalized);
                                lines.push(` ${zMetricConfig.label}: ${formatValueWrapper(rawZ, zMetricConfig.format, currency as Currency)} (Size: ${pixelRadius.toFixed(1)}px)`);
                            }
                            return lines;
                        }
                    }
                },
                zoom: { zoom: { wheel: { enabled: true, speed: 0.1 }, pinch: { enabled: true }, mode: 'xy' }, pan: { enabled: true, mode: 'xy', threshold: 5 } },
                datalabels: { display: false } // Global disable, enabled per dataset
            } // End plugins
        };
        return options;
    }, [xScale, yScale, xMetricConfig, yMetricConfig, zMetricConfig, currency]); // Dependencies


    // --- Handlers ---
    const handleZoomIn = useCallback(() => { chartRef.current?.zoom(1.2); }, []);
    const handleZoomOut = useCallback(() => { chartRef.current?.zoom(0.8); }, []);
    const handleResetZoom = useCallback(() => { chartRef.current?.resetZoom(); }, []);
    const handleExportCode = useCallback(() => {
        try { const code = exportChartCode(); downloadJson(code, 'scatter-chart-code.json'); }
        catch (exportError) { console.error("Failed to export code:", exportError); }
    }, []);
    // **NEW Reset Filters Handler**
    const handleResetFilters = useCallback(() => {
        resetFilters(); // Call the function from context
        // Optional: Reset local chart settings too? E.g., axes, scales?
        // setXMetric('financials.market_cap_value');
        // setYMetric('valuation_metrics.ev_per_resource_oz_all');
        // setZMetric('production.current_production_total_aueq_koz');
        // setXScale('log'); setYScale('log'); setZScale('linear');
        // Resetting zoom might also be desirable here
        handleResetZoom();
    }, [resetFilters, handleResetZoom]); // Include handleResetZoom if resetting zoom


    // --- Page Actions ---
    // **ADDED Reset Filters Button**
    const pageActions = (
        <>
            <Button variant="outline" size="sm" onClick={handleResetFilters} title="Reset Filters">
                <FilterX className="h-4 w-4 mr-1" /> Reset Filters
            </Button>
            <Button variant="ghost" size="sm" onClick={handleExportCode} title="Download Code Snippets">
                <Download className="h-4 w-4 mr-1" /> Code
            </Button>
        </>
    );

    // --- Render Logic ---
    return (
        <PageContainer
            title="Scatter Analysis"
            // Use context loading/error state for description
            description={isContextLoading ? "Loading filtered data..." : contextError ? "Error loading data" : `Comparing ${displayData?.length ?? 0} companies based on filters`}
            actions={pageActions}
        >
            <div className="space-y-6">
                {/* Controls Section (remains the same) */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start bg-navy-400/10 p-4 rounded-lg">
                     <FeatureAccess requiredTier={xMetricConfig?.tier ?? 'free'} currentTier={currentUserTier}>
                           <div className="space-y-2"><MetricSelector label="X Axis" selectedMetric={xMetric} onMetricChange={setXMetric} metrics={accessibleMetrics} currentTier={currentUserTier}/><ScaleToggle scale={xScale} onChange={setXScale} label="X Scale"/></div>
                     </FeatureAccess>
                      <FeatureAccess requiredTier={yMetricConfig?.tier ?? 'free'} currentTier={currentUserTier}>
                            <div className="space-y-2"><MetricSelector label="Y Axis" selectedMetric={yMetric} onMetricChange={setYMetric} metrics={accessibleMetrics} currentTier={currentUserTier}/><ScaleToggle scale={yScale} onChange={setYScale} label="Y Scale"/></div>
                      </FeatureAccess>
                      <FeatureAccess requiredTier={zMetricConfig?.tier ?? 'free'} currentTier={currentUserTier}>
                            <div className="space-y-2"><MetricSelector label="Bubble Size" selectedMetric={zMetric} onMetricChange={setZMetric} metrics={accessibleMetrics} currentTier={currentUserTier}/><ScaleToggle scale={zScale} onChange={setZScale} label="Size Scale"/></div>
                      </FeatureAccess>
                </div>

                {/* Chart Section */}
                <div className="relative bg-navy-400/20 rounded-lg p-4 shadow-lg border border-navy-300/10">
                    {/* Toolbar (remains the same) */}
                    <div className="absolute top-3 right-3 flex items-center gap-1.5 z-10">
                        <Button variant="outline" size="icon-sm" onClick={handleZoomIn} title="Zoom In"> <ZoomIn className="h-4 w-4" /> </Button>
                        <Button variant="outline" size="icon-sm" onClick={handleZoomOut} title="Zoom Out"> <ZoomOut className="h-4 w-4" /> </Button>
                        <Button variant="outline" size="icon-sm" onClick={handleResetZoom} title="Reset Zoom"> <RotateCcw className="h-4 w-4" /> </Button>
                    </div>

                    {/* Canvas Container */}
                    <div className="h-[65vh] min-h-[500px]" ref={containerRef}>
                         {/* Use context loading/error state */}
                         {isContextLoading ? (
                            <div className="h-full flex items-center justify-center text-surface-white/70"> <LoadingIndicator message="Loading filtered chart data..." /> </div>
                        ) : contextError ? (
                            <div className="h-full flex flex-col items-center justify-center text-red-400"> <p className="font-semibold mb-2">Error Loading Data</p> <p className="text-sm">{contextError}</p> </div>
                        ) : !displayData || displayData.length === 0 ? ( // Handle case where filters result in no data
                             <div className="h-full flex flex-col items-center justify-center text-surface-white/70"> <p>No companies match the current filters.</p> </div>
                        ) : chartDatasets.length === 0 && !isContextLoading ? ( // Handle case where data exists but no points valid for chart axes/scales
                             <div className="h-full flex flex-col items-center justify-center text-surface-white/70"> <p>No valid data points for the selected metrics/scales.</p><p className="text-xs">(Try adjusting axes or using linear scale if log scale has zero/negative values)</p></div>
                        ) : containerRef.current ? ( // Only render chart if container is ready and data is present
                             <Scatter
                                ref={chartRef}
                                data={{ datasets: chartDatasets }}
                                options={chartOptions}
                             />
                        ) : ( // Fallback while container ref might not be ready
                            <div className="h-full flex items-center justify-center text-surface-white/50"> Initializing chart... </div>
                        )}
                    </div> {/* End Canvas Container */}
                </div> {/* End Chart Section */}
            </div> {/* End Page Content Wrapper */}
        </PageContainer>
    );
} // End ScatterChartPage Component