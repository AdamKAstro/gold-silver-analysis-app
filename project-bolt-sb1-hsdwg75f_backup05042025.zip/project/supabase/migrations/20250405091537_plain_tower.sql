/*
  # Revert get_companies_paginated to working version

  1. Changes
    - Revert to single column sorting
    - Restore original parameter signature
    - Keep all existing filters and functionality
    - Fix status handling
    - Maintain currency support
*/

-- Drop the current version first
DROP FUNCTION IF EXISTS get_companies_paginated(jsonb, integer, integer, jsonb, text);

-- Restore the working version
CREATE OR REPLACE FUNCTION get_companies_paginated(
    page_num INT,
    page_size INT,
    sort_column TEXT DEFAULT 'company_name',
    sort_direction TEXT DEFAULT 'asc',
    target_currency TEXT DEFAULT 'USD',
    filters JSONB DEFAULT '{}'::jsonb
)
RETURNS TABLE (
    total_rows BIGINT,
    company_id BIGINT,
    company_name TEXT,
    tsx_code TEXT,
    status TEXT,
    headquarters TEXT,
    description TEXT,
    minerals_of_interest TEXT,
    percent_gold double precision,
    percent_silver double precision,
    share_price double precision,
    f_cash_value double precision,
    f_market_cap_value double precision,
    f_enterprise_value_value double precision,
    f_net_financial_assets double precision,
    f_free_cash_flow double precision,
    f_price_to_book double precision,
    f_price_to_sales double precision,
    f_enterprise_to_revenue double precision,
    f_enterprise_to_ebitda double precision,
    f_trailing_pe double precision,
    f_forward_pe double precision,
    f_revenue_value double precision,
    f_ebitda double precision,
    f_net_income_value double precision,
    f_debt_value double precision,
    f_shares_outstanding double precision,
    cs_existing_shares BIGINT,
    cs_fully_diluted_shares BIGINT,
    cs_in_the_money_options BIGINT,
    cs_options_revenue double precision,
    me_reserves_total_aueq_moz double precision,
    me_measured_indicated_total_aueq_moz double precision,
    me_resources_total_aueq_moz double precision,
    me_potential_total_aueq_moz double precision,
    me_reserves_precious_aueq_moz double precision,
    me_measured_indicated_precious_aueq_moz double precision,
    me_resources_precious_aueq_moz double precision,
    vm_ev_per_resource_oz_all double precision,
    vm_ev_per_reserve_oz_all double precision,
    vm_mkt_cap_per_resource_oz_all double precision,
    vm_mkt_cap_per_reserve_oz_all double precision,
    vm_ev_per_resource_oz_precious double precision,
    vm_ev_per_reserve_oz_precious double precision,
    vm_mkt_cap_per_resource_oz_precious double precision,
    vm_mkt_cap_per_reserve_oz_precious double precision,
    p_current_production_total_aueq_koz double precision,
    p_future_production_total_aueq_koz double precision,
    p_reserve_life_years double precision,
    p_current_production_precious_aueq_koz double precision,
    p_current_production_non_precious_aueq_koz double precision,
    c_aisc_future double precision,
    c_construction_costs double precision,
    c_tco_future double precision,
    c_aisc_last_quarter double precision,
    c_aisc_last_year double precision
)
LANGUAGE plpgsql
AS $$
DECLARE
    _offset INT;
    _total_rows_estimate BIGINT;
    _sort_direction_sql TEXT;
    _sort_column_sql TEXT;
    _input_sort_column TEXT := sort_column;
    query_plan JSON;
    where_clause TEXT;
    main_query TEXT;
    _search_term TEXT                   := filters ->> 'searchTerm';
    _status_filter TEXT[]               := ARRAY(SELECT jsonb_array_elements_text(filters -> 'status'));
    _min_f_market_cap_value NUMERIC     := (filters ->> 'min_f_market_cap_value')::NUMERIC;
    _max_f_market_cap_value NUMERIC     := (filters ->> 'max_f_market_cap_value')::NUMERIC;
    _min_f_cash_value NUMERIC           := (filters ->> 'min_f_cash_value')::NUMERIC;
    _max_f_cash_value NUMERIC           := (filters ->> 'max_f_cash_value')::NUMERIC;
    _min_f_enterprise_value_value NUMERIC := (filters ->> 'min_f_enterprise_value_value')::NUMERIC;
    _max_f_enterprise_value_value NUMERIC := (filters ->> 'max_f_enterprise_value_value')::NUMERIC;
    _min_percent_gold NUMERIC           := (filters ->> 'min_percent_gold')::NUMERIC;
    _max_percent_gold NUMERIC           := (filters ->> 'max_percent_gold')::NUMERIC;
    _min_percent_silver NUMERIC         := (filters ->> 'min_percent_silver')::NUMERIC;
    _max_percent_silver NUMERIC         := (filters ->> 'max_percent_silver')::NUMERIC;
    _min_me_reserves_total_aueq_moz NUMERIC := (filters ->> 'min_me_reserves_total_aueq_moz')::NUMERIC;
    _max_me_reserves_total_aueq_moz NUMERIC := (filters ->> 'max_me_reserves_total_aueq_moz')::NUMERIC;
    _min_me_resources_total_aueq_moz NUMERIC := (filters ->> 'min_me_resources_total_aueq_moz')::NUMERIC;
    _max_me_resources_total_aueq_moz NUMERIC := (filters ->> 'max_me_resources_total_aueq_moz')::NUMERIC;
    _max_c_aisc_future NUMERIC                  := (filters ->> 'max_c_aisc_future')::NUMERIC;
    _max_c_aisc_last_quarter NUMERIC           := (filters ->> 'max_c_aisc_last_quarter')::NUMERIC;
    _max_c_aisc_last_year NUMERIC              := (filters ->> 'max_c_aisc_last_year')::NUMERIC;
    _max_c_construction_costs NUMERIC          := (filters ->> 'max_c_construction_costs')::NUMERIC;
    _max_p_current_production_total_aueq_koz NUMERIC := (filters ->> 'max_p_current_production_total_aueq_koz')::NUMERIC;
    _max_p_current_production_non_precious_aueq_koz NUMERIC := (filters ->> 'max_p_current_production_non_precious_aueq_koz')::NUMERIC;
    _max_p_current_production_precious_aueq_koz NUMERIC := (filters ->> 'max_p_current_production_precious_aueq_koz')::NUMERIC;
    _max_f_debt_value NUMERIC                  := (filters ->> 'max_f_debt_value')::NUMERIC;
    _max_f_ebitda NUMERIC                      := (filters ->> 'max_f_ebitda')::NUMERIC;
    _max_f_enterprise_to_ebitda NUMERIC        := (filters ->> 'max_f_enterprise_to_ebitda')::NUMERIC;
    _max_f_enterprise_to_revenue NUMERIC       := (filters ->> 'max_f_enterprise_to_revenue')::NUMERIC;
    _max_vm_ev_per_reserve_oz_all NUMERIC      := (filters ->> 'max_vm_ev_per_reserve_oz_all')::NUMERIC;
    _max_vm_ev_per_reserve_oz_precious NUMERIC := (filters ->> 'max_vm_ev_per_reserve_oz_precious')::NUMERIC;
    _max_vm_ev_per_resource_oz_all NUMERIC     := (filters ->> 'max_vm_ev_per_resource_oz_all')::NUMERIC;
    _max_vm_ev_per_resource_oz_precious NUMERIC := (filters ->> 'max_vm_ev_per_resource_oz_precious')::NUMERIC;
    _max_cs_existing_shares BIGINT             := (filters ->> 'max_cs_existing_shares')::BIGINT;
    _max_f_forward_pe NUMERIC                  := (filters ->> 'max_f_forward_pe')::NUMERIC;
    _max_f_free_cash_flow NUMERIC              := (filters ->> 'max_f_free_cash_flow')::NUMERIC;
    _max_cs_fully_diluted_shares BIGINT        := (filters ->> 'max_cs_fully_diluted_shares')::BIGINT;
    _max_p_future_production_total_aueq_koz NUMERIC := (filters ->> 'max_p_future_production_total_aueq_koz')::NUMERIC;
    _max_cs_in_the_money_options BIGINT        := (filters ->> 'max_cs_in_the_money_options')::BIGINT;
    _max_me_measured_indicated_total_aueq_moz NUMERIC := (filters ->> 'max_me_measured_indicated_total_aueq_moz')::NUMERIC;
    _max_vm_mkt_cap_per_reserve_oz_all NUMERIC := (filters ->> 'max_vm_mkt_cap_per_reserve_oz_all')::NUMERIC;
    _max_vm_mkt_cap_per_reserve_oz_precious NUMERIC := (filters ->> 'max_vm_mkt_cap_per_reserve_oz_precious')::NUMERIC;
    _max_vm_mkt_cap_per_resource_oz_all NUMERIC := (filters ->> 'max_vm_mkt_cap_per_resource_oz_all')::NUMERIC;
    _max_vm_mkt_cap_per_resource_oz_precious NUMERIC := (filters ->> 'max_vm_mkt_cap_per_resource_oz_precious')::NUMERIC;
    _max_f_net_income_value NUMERIC            := (filters ->> 'max_f_net_income_value')::NUMERIC;
    _max_cs_options_revenue NUMERIC            := (filters ->> 'max_cs_options_revenue')::NUMERIC;
    _max_me_potential_total_aueq_moz NUMERIC   := (filters ->> 'max_me_potential_total_aueq_moz')::NUMERIC;
    _max_me_measured_indicated_precious_aueq_moz NUMERIC := (filters ->> 'max_me_measured_indicated_precious_aueq_moz')::NUMERIC;
    _max_me_reserves_precious_aueq_moz NUMERIC := (filters ->> 'max_me_reserves_precious_aueq_moz')::NUMERIC;
    _max_me_resources_precious_aueq_moz NUMERIC := (filters ->> 'max_me_resources_precious_aueq_moz')::NUMERIC;
    _max_f_price_to_book NUMERIC               := (filters ->> 'max_f_price_to_book')::NUMERIC;
    _max_f_price_to_sales NUMERIC              := (filters ->> 'max_f_price_to_sales')::NUMERIC;
    _max_p_reserve_life_years NUMERIC          := (filters ->> 'max_p_reserve_life_years')::NUMERIC;
    _max_f_revenue_value NUMERIC               := (filters ->> 'max_f_revenue_value')::NUMERIC;
    _max_c_tco_future NUMERIC                  := (filters ->> 'max_c_tco_future')::NUMERIC;
    _max_f_trailing_pe NUMERIC                 := (filters ->> 'max_f_trailing_pe')::NUMERIC;
    _min_c_aisc_future NUMERIC                 := (filters ->> 'min_c_aisc_future')::NUMERIC;
    _min_c_aisc_last_quarter NUMERIC           := (filters ->> 'min_c_aisc_last_quarter')::NUMERIC;
    _min_c_aisc_last_year NUMERIC              := (filters ->> 'min_c_aisc_last_year')::NUMERIC;
    _min_c_construction_costs NUMERIC          := (filters ->> 'min_c_construction_costs')::NUMERIC;
    _min_p_current_production_total_aueq_koz NUMERIC := (filters ->> 'min_p_current_production_total_aueq_koz')::NUMERIC;
    _min_p_current_production_non_precious_aueq_koz NUMERIC := (filters ->> 'min_p_current_production_non_precious_aueq_koz')::NUMERIC;
    _min_p_current_production_precious_aueq_koz NUMERIC := (filters ->> 'min_p_current_production_precious_aueq_koz')::NUMERIC;
    _min_f_debt_value NUMERIC                  := (filters ->> 'min_f_debt_value')::NUMERIC;
    _min_f_ebitda NUMERIC                      := (filters ->> 'min_f_ebitda')::NUMERIC;
    _min_f_enterprise_to_ebitda NUMERIC        := (filters ->> 'min_f_enterprise_to_ebitda')::NUMERIC;
    _min_f_enterprise_to_revenue NUMERIC       := (filters ->> 'min_f_enterprise_to_revenue')::NUMERIC;
    _min_vm_ev_per_reserve_oz_all NUMERIC      := (filters ->> 'min_vm_ev_per_reserve_oz_all')::NUMERIC;
    _min_vm_ev_per_reserve_oz_precious NUMERIC := (filters ->> 'min_vm_ev_per_reserve_oz_precious')::NUMERIC;
    _min_vm_ev_per_resource_oz_all NUMERIC     := (filters ->> 'min_vm_ev_per_resource_oz_all')::NUMERIC;
    _min_vm_ev_per_resource_oz_precious NUMERIC := (filters ->> 'min_vm_ev_per_resource_oz_precious')::NUMERIC;
    _min_cs_existing_shares BIGINT             := (filters ->> 'min_cs_existing_shares')::BIGINT;
    _min_f_forward_pe NUMERIC                  := (filters ->> 'min_f_forward_pe')::NUMERIC;
    _min_f_free_cash_flow NUMERIC              := (filters ->> 'min_f_free_cash_flow')::NUMERIC;
    _min_cs_fully_diluted_shares BIGINT        := (filters ->> 'min_cs_fully_diluted_shares')::BIGINT;
    _min_p_future_production_total_aueq_koz NUMERIC := (filters ->> 'min_p_future_production_total_aueq_koz')::NUMERIC;
    _min_cs_in_the_money_options BIGINT        := (filters ->> 'min_cs_in_the_money_options')::BIGINT;
    _min_me_measured_indicated_total_aueq_moz NUMERIC := (filters ->> 'min_me_measured_indicated_total_aueq_moz')::NUMERIC;
    _min_vm_mkt_cap_per_reserve_oz_all NUMERIC := (filters ->> 'min_vm_mkt_cap_per_reserve_oz_all')::NUMERIC;
    _min_vm_mkt_cap_per_reserve_oz_precious NUMERIC := (filters ->> 'min_vm_mkt_cap_per_reserve_oz_precious')::NUMERIC;
    _min_vm_mkt_cap_per_resource_oz_all NUMERIC := (filters ->> 'min_vm_mkt_cap_per_resource_oz_all')::NUMERIC;
    _min_vm_mkt_cap_per_resource_oz_precious NUMERIC := (filters ->> 'min_vm_mkt_cap_per_resource_oz_precious')::NUMERIC;
    _min_f_net_income_value NUMERIC            := (filters ->> 'min_f_net_income_value')::NUMERIC;
    _min_cs_options_revenue NUMERIC            := (filters ->> 'min_cs_options_revenue')::NUMERIC;
    _min_me_potential_total_aueq_moz NUMERIC   := (filters ->> 'min_me_potential_total_aueq_moz')::NUMERIC;
    _min_me_measured_indicated_precious_aueq_moz NUMERIC := (filters ->> 'min_me_measured_indicated_precious_aueq_moz')::NUMERIC;
    _min_me_reserves_precious_aueq_moz NUMERIC := (filters ->> 'min_me_reserves_precious_aueq_moz')::NUMERIC;
    _min_me_resources_precious_aueq_moz NUMERIC := (filters ->> 'min_me_resources_precious_aueq_moz')::NUMERIC;
    _min_f_price_to_book NUMERIC               := (filters ->> 'min_f_price_to_book')::NUMERIC;
    _min_f_price_to_sales NUMERIC              := (filters ->> 'min_f_price_to_sales')::NUMERIC;
    _min_p_reserve_life_years NUMERIC          := (filters ->> 'min_p_reserve_life_years')::NUMERIC;
    _min_f_revenue_value NUMERIC               := (filters ->> 'min_f_revenue_value')::NUMERIC;
    _min_c_tco_future NUMERIC                  := (filters ->> 'min_c_tco_future')::NUMERIC;
    _min_f_trailing_pe NUMERIC                 := (filters ->> 'min_f_trailing_pe')::NUMERIC;

BEGIN
    _offset := (page_num - 1) * page_size;

    -- Sort direction
    IF lower(sort_direction) = 'desc' THEN
        _sort_direction_sql := 'DESC NULLS LAST';
    ELSE
        _sort_direction_sql := 'ASC NULLS FIRST';
    END IF;

    -- Map sort_column to SQL expression with COALESCE(..., 0) for numerics
    _sort_column_sql := CASE _input_sort_column
        WHEN 'company_name' THEN 'co.company_name'
        WHEN 'tsx_code' THEN 'co.tsx_code'
        WHEN 'status' THEN 'co.status::text'
        WHEN 'headquarters' THEN 'co.headquarters'
        WHEN 'percent_gold' THEN 'COALESCE(co.percent_gold, 0)'
        WHEN 'percent_silver' THEN 'COALESCE(co.percent_silver, 0)'
        WHEN 'share_price' THEN 'COALESCE((CASE WHEN cs.existing_shares > 0 THEN f.market_cap_value / cs.existing_shares ELSE NULL END), 0)'
        WHEN 'f_cash_value' THEN 'COALESCE(f.cash_value, 0)'
        WHEN 'f_market_cap_value' THEN 'COALESCE(f.market_cap_value, 0)'
        WHEN 'f_enterprise_value_value' THEN 'COALESCE(f.enterprise_value_value, 0)'
        WHEN 'f_net_financial_assets' THEN 'COALESCE(f.net_financial_assets, 0)'
        WHEN 'f_free_cash_flow' THEN 'COALESCE(f.free_cash_flow, 0)'
        WHEN 'f_price_to_book' THEN 'COALESCE(f.price_to_book, 0)'
        WHEN 'f_price_to_sales' THEN 'COALESCE(f.price_to_sales, 0)'
        WHEN 'f_enterprise_to_revenue' THEN 'COALESCE(f.enterprise_to_revenue, 0)'
        WHEN 'f_enterprise_to_ebitda' THEN 'COALESCE(f.enterprise_to_ebitda, 0)'
        WHEN 'f_trailing_pe' THEN 'COALESCE(f.trailing_pe, 0)'
        WHEN 'f_forward_pe' THEN 'COALESCE(f.forward_pe, 0)'
        WHEN 'f_revenue_value' THEN 'COALESCE(f.revenue_value, 0)'
        WHEN 'f_ebitda' THEN 'COALESCE(f.ebitda, 0)'
        WHEN 'f_net_income_value' THEN 'COALESCE(f.net_income_value, 0)'
        WHEN 'f_debt_value' THEN 'COALESCE(f.debt_value, 0)'
        WHEN 'f_shares_outstanding' THEN 'COALESCE(f.shares_outstanding, 0)'
        WHEN 'cs_existing_shares' THEN 'COALESCE(cs.existing_shares, 0)'
        WHEN 'cs_fully_diluted_shares' THEN 'COALESCE(cs.fully_diluted_shares, 0)'
        WHEN 'cs_in_the_money_options' THEN 'COALESCE(cs.in_the_money_options, 0)'
        WHEN 'cs_options_revenue' THEN 'COALESCE(cs.options_revenue, 0)'
        WHEN 'me_reserves_total_aueq_moz' THEN 'COALESCE(me.reserves_total_aueq_moz, 0)'
        WHEN 'me_measured_indicated_total_aueq_moz' THEN 'COALESCE(me.measured_indicated_total_aueq_moz, 0)'
        WHEN 'me_resources_total_aueq_moz' THEN 'COALESCE(me.resources_total_aueq_moz, 0)'
        WHEN 'me_potential_total_aueq_moz' THEN 'COALESCE(me.potential_total_aueq_moz, 0)'
        WHEN 'me_reserves_precious_aueq_moz' THEN 'COALESCE(me.reserves_precious_aueq_moz, 0)'
        WHEN 'me_measured_indicated_precious_aueq_moz' THEN 'COALESCE(me.measured_indicated_precious_aueq_moz, 0)'
        WHEN 'me_resources_precious_aueq_moz' THEN 'COALESCE(me.resources_precious_aueq_moz, 0)'
        WHEN 'vm_ev_per_resource_oz_all' THEN 'COALESCE(vm.ev_per_resource_oz_all, 0)'
        WHEN 'vm_ev_per_reserve_oz_all' THEN 'COALESCE(vm.ev_per_reserve_oz_all, 0)'
        WHEN 'vm_mkt_cap_per_resource_oz_all' THEN 'COALESCE(vm.mkt_cap_per_resource_oz_all, 0)'
        WHEN 'vm_mkt_cap_per_reserve_oz_all' THEN 'COALESCE(vm.mkt_cap_per_reserve_oz_all, 0)'
        WHEN 'vm_ev_per_resource_oz_precious' THEN 'COALESCE(vm.ev_per_resource_oz_precious, 0)'
        WHEN 'vm_ev_per_reserve_oz_precious' THEN 'COALESCE(vm.ev_per_reserve_oz_precious, 0)'
        WHEN 'vm_mkt_cap_per_resource_oz_precious' THEN 'COALESCE(vm.mkt_cap_per_resource_oz_precious, 0)'
        WHEN 'vm_mkt_cap_per_reserve_oz_precious' THEN 'COALESCE(vm.mkt_cap_per_reserve_oz_precious, 0)'
        WHEN 'p_current_production_total_aueq_koz' THEN 'COALESCE(p.current_production_total_aueq_koz, 0)'
        WHEN 'p_future_production_total_aueq_koz' THEN 'COALESCE(p.future_production_total_aueq_koz, 0)'
        WHEN 'p_reserve_life_years' THEN 'COALESCE(p.reserve_life_years, 0)'
        WHEN 'p_current_production_precious_aueq_koz' THEN 'COALESCE(p.current_production_precious_aueq_koz, 0)'
        WHEN 'p_current_production_non_precious_aueq_koz' THEN 'COALESCE(p.current_production_non_precious_aueq_koz, 0)'
        WHEN 'c_aisc_future' THEN 'COALESCE(cst.aisc_future, 0)'
        WHEN 'c_construction_costs' THEN 'COALESCE(cst.construction_costs, 0)'
        WHEN 'c_tco_future' THEN 'COALESCE(cst.tco_future, 0)'
        WHEN 'c_aisc_last_quarter' THEN 'COALESCE(cst.aisc_last_quarter, 0)'
        WHEN 'c_aisc_last_year' THEN 'COALESCE(cst.aisc_last_year, 0)'
        ELSE 'co.company_name'
    END;

    -- Build WHERE clause
    where_clause := 'TRUE';
    IF _search_term IS NOT NULL AND _search_term != '' THEN
        where_clause := where_clause || format(' AND (co.company_name ILIKE %L OR co.tsx_code ILIKE %L)', '%' || _search_term || '%', '%' || _search_term || '%');
    END IF;

    IF _status_filter IS NOT NULL AND array_length(_status_filter, 1) > 0 THEN
        where_clause := where_clause || format(' AND co.status::text = ANY (%L)', _status_filter);
    END IF;

    -- Range filters
    IF _min_f_market_cap_value IS NOT NULL THEN where_clause := where_clause || format(' AND f.market_cap_value >= %s', _min_f_market_cap_value); END IF;
    IF _max_f_market_cap_value IS NOT NULL THEN where_clause := where_clause || format(' AND f.market_cap_value <= %s', _max_f_market_cap_value); END IF;
    IF _min_f_cash_value IS NOT NULL THEN where_clause := where_clause || format(' AND f.cash_value >= %s', _min_f_cash_value); END IF;
    IF _max_f_cash_value IS NOT NULL THEN where_clause := where_clause || format(' AND f.cash_value <= %s', _max_f_cash_value); END IF;
    IF _min_f_enterprise_value_value IS NOT NULL THEN where_clause := where_clause || format(' AND f.enterprise_value_value >= %s', _min_f_enterprise_value_value); END IF;
    IF _max_f_enterprise_value_value IS NOT NULL THEN where_clause := where_clause || format(' AND f.enterprise_value_value <= %s', _max_f_enterprise_value_value); END IF;
    IF _min_percent_gold IS NOT NULL THEN where_clause := where_clause || format(' AND co.percent_gold >= %s', _min_percent_gold); END IF;
    IF _max_percent_gold IS NOT NULL THEN where_clause := where_clause || format(' AND co.percent_gold <= %s', _max_percent_gold); END IF;
    IF _min_percent_silver IS NOT NULL THEN where_clause := where_clause || format(' AND co.percent_silver >= %s', _min_percent_silver); END IF;
    IF _max_percent_silver IS NOT NULL THEN where_clause := where_clause || format(' AND co.percent_silver <= %s', _max_percent_silver); END IF;
    IF _min_me_reserves_total_aueq_moz IS NOT NULL THEN where_clause := where_clause || format(' AND me.reserves_total_aueq_moz >= %s', _min_me_reserves_total_aueq_moz); END IF;
    IF _max_me_reserves_total_aueq_moz IS NOT NULL THEN where_clause := where_clause || format(' AND me.reserves_total_aueq_moz <= %s', _max_me_reserves_total_aueq_moz); END IF;
    IF _min_me_resources_total_aueq_moz IS NOT NULL THEN where_clause := where_clause || format(' AND me.resources_total_aueq_moz >= %s', _min_me_resources_total_aueq_moz); END IF;
    IF _max_me_resources_total_aueq_moz IS NOT NULL THEN where_clause := where_clause || format(' AND me.resources_total_aueq_moz <= %s', _max_me_resources_total_aueq_moz); END IF;
    IF _max_c_aisc_future IS NOT NULL THEN where_clause := where_clause || format(' AND cst.aisc_future <= %s', _max_c_aisc_future); END IF;
    IF _max_c_aisc_last_quarter IS NOT NULL THEN where_clause := where_clause || format(' AND cst.aisc_last_quarter <= %s', _max_c_aisc_last_quarter); END IF;
    IF _max_c_aisc_last_year IS NOT NULL THEN where_clause := where_clause || format(' AND cst.aisc_last_year <= %s', _max_c_aisc_last_year); END IF;
    IF _max_c_construction_costs IS NOT NULL THEN where_clause := where_clause || format(' AND cst.construction_costs <= %s', _max_c_construction_costs); END IF;
    IF _max_p_current_production_total_aueq_koz IS NOT NULL THEN where_clause := where_clause || format(' AND p.current_production_total_aueq_koz <= %s', _max_p_current_production_total_aueq_koz); END IF;
    IF _max_p_current_production_non_precious_aueq_koz IS NOT NULL THEN where_clause := where_clause || format(' AND p.current_production_non_precious_aueq_koz <= %s', _max_p_current_production_non_precious_aueq_koz); END IF;
    IF _max_p_current_production_precious_aueq_koz IS NOT NULL THEN where_clause := where_clause || format(' AND p.current_production_precious_aueq_koz <= %s', _max_p_current_production_precious_aueq_koz); END IF;
    IF _max_f_debt_value IS NOT NULL THEN where_clause := where_clause || format(' AND f.debt_value <= %s', _max_f_debt_value); END IF;
    IF _max_f_ebitda IS NOT NULL THEN where_clause := where_clause || format(' AND f.ebitda <= %s', _max_f_ebitda); END IF;
    IF _max_f_enterprise_to_ebitda IS NOT NULL THEN where_clause := where_clause || format(' AND f.enterprise_to_ebitda <= %s', _max_f_enterprise_to_ebitda); END IF;
    IF _max_f_enterprise_to_revenue IS NOT NULL THEN where_clause := where_clause || format(' AND f.enterprise_to_revenue <= %s', _max_f_enterprise_to_revenue); END IF;
    IF _max_vm_ev_per_reserve_oz_all IS NOT NULL THEN where_clause := where_clause || format(' AND vm.ev_per_reserve_oz_all <= %s', _max_vm_ev_per_reserve_oz_all); END IF;
    IF _max_vm_ev_per_reserve_oz_precious IS NOT NULL THEN where_clause := where_clause || format(' AND vm.ev_per_reserve_oz_precious <= %s', _max_vm_ev_per_reserve_oz_precious); END IF;
    IF _max_vm_ev_per_resource_oz_all IS NOT NULL THEN where_clause := where_clause || format(' AND vm.ev_per_resource_oz_all <= %s', _max_vm_ev_per_resource_oz_all); END IF;
    IF _max_vm_ev_per_resource_oz_precious IS NOT NULL THEN where_clause := where_clause || format(' AND vm.ev_per_resource_oz_precious <= %s', _max_vm_ev_per_resource_oz_precious); END IF;
    IF _max_cs_existing_shares IS NOT NULL THEN where_clause := where_clause || format(' AND cs.existing_shares <= %s', _max_cs_existing_shares); END IF;
    IF _max_f_forward_pe IS NOT NULL THEN where_clause := where_clause || format(' AND f.forward_pe <= %s', _max_f_forward_pe); END IF;
    IF _max_f_free_cash_flow IS NOT NULL THEN where_clause := where_clause || format(' AND f.free_cash_flow <= %s', _max_f_free_cash_flow); END IF;
    IF _max_cs_fully_diluted_shares IS NOT NULL THEN where_clause := where_clause || format(' AND cs.fully_diluted_shares <= %s', _max_cs_fully_diluted_shares); END IF;
    IF _max_p_future_production_total_aueq_koz IS NOT NULL THEN where_clause := where_clause || format(' AND p.future_production_total_aueq_koz <= %s', _max_p_future_production_total_aueq_koz); END IF;
    IF _max_cs_in_the_money_options IS NOT NULL THEN where_clause := where_clause || format(' AND cs.in_the_money_options <= %s', _max_cs_in_the_money_options); END IF;
    IF _max_me_measured_indicated_total_aueq_moz IS NOT NULL THEN where_clause := where_clause || format(' AND me.measured_indicated_total_aueq_moz <= %s', _max_me_measured_indicated_total_aueq_moz); END IF;
    IF _max_vm_mkt_cap_per_reserve_oz_all IS NOT NULL THEN where_clause := where_clause || format(' AND vm.mkt_cap_per_reserve_oz_all <= %s', _max_vm_mkt_cap_per_reserve_oz_all); END IF;
    IF _max_vm_mkt_cap_per_reserve_oz_precious IS NOT NULL THEN where_clause := where_clause || format(' AND vm.mkt_cap_per_reserve_oz_precious <= %s', _max_vm_mkt_cap_per_reserve_oz_precious); END IF;
    IF _max_vm_mkt_cap_per_resource_oz_all IS NOT NULL THEN where_clause := where_clause || format(' AND vm.mkt_cap_per_resource_oz_all <= %s', _max_vm_mkt_cap_per_resource_oz_all); END IF;
    IF _max_vm_mkt_cap_per_resource_oz_precious IS NOT NULL THEN where_clause := where_clause || format(' AND vm.mkt_cap_per_resource_oz_precious <= %s', _max_vm_mkt_cap_per_resource_oz_precious); END IF;
    IF _max_f_net_income_value IS NOT NULL THEN where_clause := where_clause || format(' AND f.net_income_value <= %s', _max_f_net_income_value); END IF;
    IF _max_cs_options_revenue IS NOT NULL THEN where_clause := where_clause || format(' AND cs.options_revenue <= %s', _max_cs_options_revenue); END IF;
    IF _max_me_potential_total_aueq_moz IS NOT NULL THEN where_clause := where_clause || format(' AND me.potential_total_aueq_moz <= %s', _max_me_potential_total_aueq_moz); END IF;
    IF _max_me_measured_indicated_precious_aueq_moz IS NOT NULL THEN where_clause := where_clause || format(' AND me.measured_indicated_precious_aueq_moz <= %s', _max_me_measured_indicated_precious_aueq_moz); END IF;
    IF _max_me_reserves_precious_aueq_moz IS NOT NULL THEN where_clause := where_clause || format(' AND me.reserves_precious_aueq_moz <= %s', _max_me_reserves_precious_aueq_moz); END IF;
    IF _max_me_resources_precious_aueq_moz IS NOT NULL THEN where_clause := where_clause || format(' AND me.resources_precious_aueq_moz <= %s', _max_me_resources_precious_aueq_moz); END IF;
    IF _max_f_price_to_book IS NOT NULL THEN where_clause := where_clause || format(' AND f.price_to_book <= %s', _max_f_price_to_book); END IF;
    IF _max_f_price_to_sales IS NOT NULL THEN where_clause := where_clause || format(' AND f.price_to_sales <= %s', _max_f_price_to_sales); END IF;
    IF _max_p_reserve_life_years IS NOT NULL THEN where_clause := where_clause || format(' AND p.reserve_life_years <= %s', _max_p_reserve_life_years); END IF;
    IF _max_f_revenue_value IS NOT NULL THEN where_clause := where_clause || format(' AND f.revenue_value <= %s', _max_f_revenue_value); END IF;
    IF _max_c_tco_future IS NOT NULL THEN where_clause := where_clause || format(' AND cst.tco_future <= %s', _max_c_tco_future); END IF;
    IF _max_f_trailing_pe IS NOT NULL THEN where_clause := where_clause || format(' AND f.trailing_pe <= %s', _max_f_trailing_pe); END IF;
    IF _min_c_aisc_future IS NOT NULL THEN where_clause := where_clause || format(' AND cst.aisc_future >= %s', _min_c_aisc_future); END IF;
    IF _min_c_aisc_last_quarter IS NOT NULL THEN where_clause := where_clause || format(' AND cst.aisc_last_quarter >= %s', _min_c_aisc_last_quarter); END IF;
    IF _min_c_aisc_last_year IS NOT NULL THEN where_clause := where_clause || format(' AND cst.aisc_last_year >= %s', _min_c_aisc_last_year); END IF;
    IF _min_c_construction_costs IS NOT NULL THEN where_clause := where_clause || format(' AND cst.construction_costs >= %s', _min_c_construction_costs); END IF;
    IF _min_p_current_production_total_aueq_koz IS NOT NULL THEN where_clause := where_clause || format(' AND p.current_production_total_aueq_koz >= %s', _min_p_current_production_total_aueq_koz); END IF;
    IF _min_p_current_production_non_precious_aueq_koz IS NOT NULL THEN where_clause := where_clause || format(' AND p.current_production_non_precious_aueq_koz >= %s', _min_p_current_production_non_precious_aueq_koz); END IF;
    IF _min_p_current_production_precious_aueq_koz IS NOT NULL THEN where_clause := where_clause || format(' AND p.current_production_precious_aueq_koz >= %s', _min_p_current_production_precious_aueq_koz); END IF;
    IF _min_f_debt_value IS NOT NULL THEN where_clause := where_clause || format(' AND f.debt_value >= %s', _min_f_debt_value); END IF;
    IF _min_f_ebitda IS NOT NULL THEN where_clause := where_clause || format(' AND f.ebitda >= %s', _min_f_ebitda); END IF;
    IF _min_f_enterprise_to_ebitda IS NOT NULL THEN where_clause := where_clause || format(' AND f.enterprise_to_ebitda >= %s', _min_f_enterprise_to_ebitda); END IF;
    IF _min_f_enterprise_to_revenue IS NOT NULL THEN where_clause := where_clause || format(' AND f.enterprise_to_revenue >= %s', _min_f_enterprise_to_revenue); END IF;
    IF _min_vm_ev_per_reserve_oz_all IS NOT NULL THEN where_clause := where_clause || format(' AND vm.ev_per_reserve_oz_all >= %s', _min_vm_ev_per_reserve_oz_all); END IF;
    IF _min_vm_ev_per_reserve_oz_precious IS NOT NULL THEN where_clause := where_clause || format(' AND vm.ev_per_reserve_oz_precious >= %s', _min_vm_ev_per_reserve_oz_precious); END IF;
    IF _min_vm_ev_per_resource_oz_all IS NOT NULL THEN where_clause := where_clause || format(' AND vm.ev_per_resource_oz_all >= %s', _min_vm_ev_per_resource_oz_all); END IF;
    IF _min_vm_ev_per_resource_oz_precious IS NOT NULL THEN where_clause := where_clause || format(' AND vm.ev_per_resource_oz_precious >= %s', _min_vm_ev_per_resource_oz_precious); END IF;
    IF _min_cs_existing_shares IS NOT NULL THEN where_clause := where_clause || format(' AND cs.existing_shares >= %s', _min_cs_existing_shares); END IF;
    IF _min_f_forward_pe IS NOT NULL THEN where_clause := where_clause || format(' AND f.forward_pe >= %s', _min_f_forward_pe); END IF;
    IF _min_f_free_cash_flow IS NOT NULL THEN where_clause := where_clause || format(' AND f.free_cash_flow >= %s', _min_f_free_cash_flow); END IF;
    IF _min_cs_fully_diluted_shares IS NOT NULL THEN where_clause := where_clause || format(' AND cs.fully_diluted_shares >= %s', _min_cs_fully_diluted_shares); END IF;
    IF _min_p_future_production_total_aueq_koz IS NOT NULL THEN where_clause := where_clause || format(' AND p.future_production_total_aueq_koz >= %s', _min_p_future_production_total_aueq_koz); END IF;
    IF _min_cs_in_the_money_options IS NOT NULL THEN where_clause := where_clause || format(' AND cs.in_the_money_options >= %s', _min_cs_in_the_money_options); END IF;
    IF _min_me_measured_indicated_total_aueq_moz IS NOT NULL THEN where_clause := where_clause || format(' AND me.measured_indicated_total_aueq_moz >= %s', _min_me_measured_indicated_total_aueq_moz); END IF;
    IF _min_vm_mkt_cap_per_reserve_oz_all IS NOT NULL THEN where_clause := where_clause || format(' AND vm.mkt_cap_per_reserve_oz_all >= %s', _min_vm_mkt_cap_per_reserve_oz_all); END IF;
    IF _min_vm_mkt_cap_per_reserve_oz_precious IS NOT NULL THEN where_clause := where_clause || format(' AND vm.mkt_cap_per_reserve_oz_precious >= %s', _min_vm_mkt_cap_per_reserve_oz_precious); END IF;
    IF _min_vm_mkt_cap_per_resource_oz_all IS NOT NULL THEN where_clause := where_clause || format(' AND vm.mkt_cap_per_resource_oz_all >= %s', _min_vm_mkt_cap_per_resource_oz_all); END IF;
    IF _min_vm_mkt_cap_per_resource_oz_precious IS NOT NULL THEN where_clause := where_clause || format(' AND vm.mkt_cap_per_resource_oz_precious >= %s', _min_vm_mkt_cap_per_resource_oz_precious); END IF;
    IF _min_f_net_income_value IS NOT NULL THEN where_clause := where_clause || format(' AND f.net_income_value >= %s', _min_f_net_income_value); END IF;
    IF _min_cs_options_revenue IS NOT NULL THEN where_clause := where_clause || format(' AND cs.options_revenue >= %s', _min_cs_options_revenue); END IF;
    IF _min_me_potential_total_aueq_moz IS NOT NULL THEN where_clause := where_clause || format(' AND me.potential_total_aueq_moz >= %s', _min_me_potential_total_aueq_moz); END IF;
    IF _min_me_measured_indicated_precious_aueq_moz IS NOT NULL THEN where_clause := where_clause || format(' AND me.measured_indicated_precious_aueq_moz >= %s', _min_me_measured_indicated_precious_aueq_moz); END IF;
    IF _min_me_reserves_precious_aueq_moz IS NOT NULL THEN where_clause := where_clause || format(' AND me.reserves_precious_aueq_moz >= %s', _min_me_reserves_precious_aueq_moz); END IF;
    IF _min_me_resources_precious_aueq_moz IS NOT NULL THEN where_clause := where_clause || format(' AND me.resources_precious_aueq_moz >= %s', _min_me_resources_precious_aueq_moz); END IF;
    IF _min_f_price_to_book IS NOT NULL THEN where_clause := where_clause || format(' AND f.price_to_book >= %s', _min_f_price_to_book); END IF;
    IF _min_f_price_to_sales IS NOT NULL THEN where_clause := where_clause || format(' AND f.price_to_sales >= %s', _min_f_price_to_sales); END IF;
    IF _min_p_reserve_life_years IS NOT NULL THEN where_clause := where_clause || format(' AND p.reserve_life_years >= %s', _min_p_reserve_life_years); END IF;
    IF _min_f_revenue_value IS NOT NULL THEN where_clause := where_clause || format(' AND f.revenue_value >= %s', _min_f_revenue_value); END IF;
    IF _min_c_tco_future IS NOT NULL THEN where_clause := where_clause || format(' AND cst.tco_future >= %s', _min_c_tco_future); END IF;
    IF _min_f_trailing_pe IS NOT NULL THEN where_clause := where_clause || format(' AND f.trailing_pe >= %s', _min_f_trailing_pe); END IF;

    -- Estimate total rows
    BEGIN
        EXECUTE format('EXPLAIN (FORMAT JSON) SELECT 1 FROM companies co LEFT JOIN financials f ON co.company_id = f.company_id LEFT JOIN capital_structure cs ON co.company_id = cs.company_id LEFT JOIN mineral_estimates me ON co.company_id = me.company_id LEFT JOIN valuation_metrics vm ON co.company_id = vm.company_id LEFT JOIN production p ON co.company_id = p.company_id LEFT JOIN costs cst ON co.company_id = cst.company_id WHERE %s', where_clause)
        INTO query_plan;
        _total_rows_estimate := (query_plan->0->'Plan'->>'Plan Rows')::BIGINT;
    EXCEPTION WHEN OTHERS THEN
        RAISE NOTICE 'Could not estimate rows using EXPLAIN, falling back to 0. Error: %', SQLERRM;
        _total_rows_estimate := 0;
    END;
    IF _total_rows_estimate IS NULL THEN
        _total_rows_estimate := 0;
    END IF;

    -- Build the main query string
    main_query := 'SELECT CAST(' || quote_literal(_total_rows_estimate) || ' AS BIGINT) AS total_rows, ' ||
                 'co.company_id, co.company_name, co.tsx_code, co.status::text AS status, co.headquarters, co.description, co.minerals_of_interest, co.percent_gold, co.percent_silver, ' ||
                 '(CASE WHEN cs.existing_shares > 0 THEN f.market_cap_value / cs.existing_shares ELSE NULL END) AS share_price, ' ||
                 'f.cash_value AS f_cash_value, f.market_cap_value AS f_market_cap_value, f.enterprise_value_value AS f_enterprise_value_value, f.net_financial_assets AS f_net_financial_assets, f.free_cash_flow AS f_free_cash_flow, f.price_to_book AS f_price_to_book, f.price_to_sales AS f_price_to_sales, f.enterprise_to_revenue AS f_enterprise_to_revenue, f.enterprise_to_ebitda AS f_enterprise_to_ebitda, f.trailing_pe AS f_trailing_pe, f.forward_pe AS f_forward_pe, f.revenue_value AS f_revenue_value, f.ebitda AS f_ebitda, f.net_income_value AS f_net_income_value, f.debt_value AS f_debt_value, f.shares_outstanding AS f_shares_outstanding, ' ||
                 'cs.existing_shares AS cs_existing_shares, cs.fully_diluted_shares AS cs_fully_diluted_shares, cs.in_the_money_options AS cs_in_the_money_options, cs.options_revenue AS cs_options_revenue, ' ||
                 'me.reserves_total_aueq_moz AS me_reserves_total_aueq_moz, me.measured_indicated_total_aueq_moz AS me_measured_indicated_total_aueq_moz, me.resources_total_aueq_moz AS me_resources_total_aueq_moz, me.potential_total_aueq_moz AS me_potential_total_aueq_moz, me.reserves_precious_aueq_moz AS me_reserves_precious_aueq_moz, me.measured_indicated_precious_aueq_moz AS me_measured_indicated_precious_aueq_moz, me.resources_precious_aueq_moz AS me_resources_precious_aueq_moz, ' ||
                 'vm.ev_per_resource_oz_all AS vm_ev_per_resource_oz_all, vm.ev_per_reserve_oz_all AS vm_ev_per_reserve_oz_all, vm.mkt_cap_per_resource_oz_all AS vm_mkt_cap_per_resource_oz_all, vm.mkt_cap_per_reserve_oz_all AS vm_mkt_cap_per_reserve_oz_all, vm.ev_per_resource_oz_precious AS vm_ev_per_resource_oz_precious, vm.ev_per_reserve_oz_precious AS vm_ev_per_reserve_oz_precious, vm.mkt_cap_per_resource_oz_precious AS vm_mkt_cap_per_resource_oz_precious, vm.mkt_cap_per_reserve_oz_precious AS vm_mkt_cap_per_reserve_oz_precious, ' ||
                 'p.current_production_total_aueq_koz AS p_current_production_total_aueq_koz, p.future_production_total_aueq_koz AS p_future_production_total_aueq_koz, p.reserve_life_years AS p_reserve_life_years, p.current_production_precious_aueq_koz AS p_current_production_precious_aueq_koz, p.current_production_non_precious_aueq_koz AS p_current_production_non_precious_aueq_koz, ' ||
                 'cst.aisc_future AS c_aisc_future, cst.construction_costs AS c_construction_costs, cst.tco_future AS c_tco_future, cst.aisc_last_quarter AS c_aisc_last_quarter, cst.aisc_last_year AS c_aisc_last_year ' ||
                 'FROM companies co LEFT JOIN financials f ON co.company_id = f.company_id LEFT JOIN capital_structure cs ON co.company_id = cs.company_id LEFT JOIN mineral_estimates me ON co.company_id = me.company_id LEFT JOIN valuation_metrics vm ON co.company_id = vm.company_id LEFT JOIN production p ON co.company_id = p.company_id LEFT JOIN costs cst ON co.company_id = cst.company_id ' ||
                 format('WHERE %s ORDER BY %s %s LIMIT %s OFFSET %s',
                        where_clause,
                        _sort_column_sql,
                        _sort_direction_sql,
                        page_size,
                        _offset);

    -- Execute the main query
    RETURN QUERY EXECUTE main_query;
END;
$$;

-- Grant permission
GRANT EXECUTE ON FUNCTION get_companies_paginated(INT, INT, TEXT, TEXT, TEXT, JSONB) TO authenticated;