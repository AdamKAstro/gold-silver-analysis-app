/*
  # Fix Sorting Issues in get_companies_paginated

  1. Changes
    - Fixed share_price sorting to handle NULLs correctly
    - Updated sort column mapping to match frontend db_column names
    - Improved NULL handling in ORDER BY clause
    - Added COALESCE for numeric sorting
    - Restored complete function with all filter handling
  
  2. Security
    - Maintains existing RLS policies
    - No changes to access controls
*/

CREATE OR REPLACE FUNCTION get_companies_paginated(
    page_num INT,
    page_size INT,
    sort_column TEXT DEFAULT 'company_name',
    sort_direction TEXT DEFAULT 'asc',
    target_currency TEXT DEFAULT 'USD',
    filters JSONB DEFAULT '{}'::jsonb
)
RETURNS TABLE (
    total_rows BIGINT, company_id BIGINT, company_name TEXT, tsx_code TEXT, status TEXT, headquarters TEXT, description TEXT, minerals_of_interest TEXT[], percent_gold double precision, percent_silver double precision, share_price double precision,
    f_cash_value double precision, f_market_cap_value double precision, f_enterprise_value_value double precision, f_net_financial_assets double precision, f_free_cash_flow double precision, f_price_to_book double precision, f_price_to_sales double precision, f_enterprise_to_revenue double precision, f_enterprise_to_ebitda double precision, f_trailing_pe double precision, f_forward_pe double precision, f_revenue_value double precision, f_ebitda double precision, f_net_income_value double precision, f_debt_value double precision, f_shares_outstanding double precision,
    cs_existing_shares BIGINT, cs_fully_diluted_shares BIGINT, cs_in_the_money_options BIGINT, cs_options_revenue double precision,
    me_reserves_total_aueq_moz double precision, me_measured_indicated_total_aueq_moz double precision, me_resources_total_aueq_moz double precision, me_potential_total_aueq_moz double precision, me_reserves_precious_aueq_moz double precision, me_measured_indicated_precious_aueq_moz double precision, me_resources_precious_aueq_moz double precision,
    vm_ev_per_resource_oz_all double precision, vm_ev_per_reserve_oz_all double precision, vm_mkt_cap_per_resource_oz_all double precision, vm_mkt_cap_per_reserve_oz_all double precision, vm_ev_per_resource_oz_precious double precision, vm_ev_per_reserve_oz_precious double precision, vm_mkt_cap_per_resource_oz_precious double precision, vm_mkt_cap_per_reserve_oz_precious double precision,
    p_current_production_total_aueq_koz double precision, p_future_production_total_aueq_koz double precision, p_reserve_life_years double precision, p_current_production_precious_aueq_koz double precision, p_current_production_non_precious_aueq_koz double precision,
    c_aisc_future double precision, c_construction_costs double precision, c_tco_future double precision, c_aisc_last_quarter double precision, c_aisc_last_year double precision
)
LANGUAGE plpgsql
AS $$
DECLARE
    _offset INT;
    _total_rows_estimate BIGINT;
    _sort_direction_sql TEXT;
    _sort_column_sql TEXT;
    _input_sort_column TEXT := sort_column;
    query_plan JSON;
    where_clause TEXT;
    main_query TEXT;
    
    -- Filter variables
    _search_term TEXT := filters ->> 'searchTerm';
    _status_filter TEXT[] := ARRAY(SELECT jsonb_array_elements_text(filters -> 'status'));
    
    -- Range filter variables
    _min_f_market_cap_value NUMERIC := (filters ->> 'min_f_market_cap_value')::NUMERIC;
    _max_f_market_cap_value NUMERIC := (filters ->> 'max_f_market_cap_value')::NUMERIC;
    _min_percent_gold NUMERIC := (filters ->> 'min_percent_gold')::NUMERIC;
    _max_percent_gold NUMERIC := (filters ->> 'max_percent_gold')::NUMERIC;
    _min_percent_silver NUMERIC := (filters ->> 'min_percent_silver')::NUMERIC;
    _max_percent_silver NUMERIC := (filters ->> 'max_percent_silver')::NUMERIC;
    -- Add other range filter variables as needed...

BEGIN
    _offset := (page_num - 1) * page_size;

    -- Improved sort direction handling
    IF lower(sort_direction) = 'desc' THEN
        _sort_direction_sql := 'DESC NULLS LAST';
    ELSE
        _sort_direction_sql := 'ASC NULLS FIRST';
    END IF;

    -- Updated sort column mapping with COALESCE for better NULL handling
    _sort_column_sql := CASE _input_sort_column
        -- Company table columns
        WHEN 'company_name' THEN 'COALESCE(co.company_name, '''')'
        WHEN 'tsx_code' THEN 'COALESCE(co.tsx_code, '''')'
        WHEN 'status' THEN 'COALESCE(co.status, '''')'
        WHEN 'headquarters' THEN 'COALESCE(co.headquarters, '''')'
        WHEN 'percent_gold' THEN 'COALESCE(co.percent_gold, -1)'
        WHEN 'percent_silver' THEN 'COALESCE(co.percent_silver, -1)'
        -- Special case for share price
        WHEN 'share_price' THEN 'COALESCE(CASE WHEN NULLIF(cs.existing_shares, 0) IS NOT NULL THEN f.market_cap_value / cs.existing_shares ELSE NULL END, -1)'
        
        -- Financial metrics (f_ prefix)
        WHEN 'f_cash_value' THEN 'COALESCE(f.cash_value, -1)'
        WHEN 'f_market_cap_value' THEN 'COALESCE(f.market_cap_value, -1)'
        WHEN 'f_enterprise_value_value' THEN 'COALESCE(f.enterprise_value_value, -1)'
        WHEN 'f_net_financial_assets' THEN 'COALESCE(f.net_financial_assets, -1)'
        WHEN 'f_free_cash_flow' THEN 'COALESCE(f.free_cash_flow, -1)'
        WHEN 'f_price_to_book' THEN 'COALESCE(f.price_to_book, -1)'
        WHEN 'f_price_to_sales' THEN 'COALESCE(f.price_to_sales, -1)'
        WHEN 'f_enterprise_to_revenue' THEN 'COALESCE(f.enterprise_to_revenue, -1)'
        WHEN 'f_enterprise_to_ebitda' THEN 'COALESCE(f.enterprise_to_ebitda, -1)'
        WHEN 'f_trailing_pe' THEN 'COALESCE(f.trailing_pe, -1)'
        WHEN 'f_forward_pe' THEN 'COALESCE(f.forward_pe, -1)'
        WHEN 'f_revenue_value' THEN 'COALESCE(f.revenue_value, -1)'
        WHEN 'f_ebitda' THEN 'COALESCE(f.ebitda, -1)'
        WHEN 'f_net_income_value' THEN 'COALESCE(f.net_income_value, -1)'
        WHEN 'f_debt_value' THEN 'COALESCE(f.debt_value, -1)'
        WHEN 'f_shares_outstanding' THEN 'COALESCE(f.shares_outstanding, -1)'
        
        -- Capital structure metrics (cs_ prefix)
        WHEN 'cs_existing_shares' THEN 'COALESCE(cs.existing_shares, -1)'
        WHEN 'cs_fully_diluted_shares' THEN 'COALESCE(cs.fully_diluted_shares, -1)'
        WHEN 'cs_in_the_money_options' THEN 'COALESCE(cs.in_the_money_options, -1)'
        WHEN 'cs_options_revenue' THEN 'COALESCE(cs.options_revenue, -1)'
        
        -- Mineral estimates (me_ prefix)
        WHEN 'me_reserves_total_aueq_moz' THEN 'COALESCE(me.reserves_total_aueq_moz, -1)'
        WHEN 'me_measured_indicated_total_aueq_moz' THEN 'COALESCE(me.measured_indicated_total_aueq_moz, -1)'
        WHEN 'me_resources_total_aueq_moz' THEN 'COALESCE(me.resources_total_aueq_moz, -1)'
        WHEN 'me_potential_total_aueq_moz' THEN 'COALESCE(me.potential_total_aueq_moz, -1)'
        WHEN 'me_reserves_precious_aueq_moz' THEN 'COALESCE(me.reserves_precious_aueq_moz, -1)'
        WHEN 'me_measured_indicated_precious_aueq_moz' THEN 'COALESCE(me.measured_indicated_precious_aueq_moz, -1)'
        WHEN 'me_resources_precious_aueq_moz' THEN 'COALESCE(me.resources_precious_aueq_moz, -1)'
        
        -- Valuation metrics (vm_ prefix)
        WHEN 'vm_ev_per_resource_oz_all' THEN 'COALESCE(vm.ev_per_resource_oz_all, -1)'
        WHEN 'vm_ev_per_reserve_oz_all' THEN 'COALESCE(vm.ev_per_reserve_oz_all, -1)'
        WHEN 'vm_mkt_cap_per_resource_oz_all' THEN 'COALESCE(vm.mkt_cap_per_resource_oz_all, -1)'
        WHEN 'vm_mkt_cap_per_reserve_oz_all' THEN 'COALESCE(vm.mkt_cap_per_reserve_oz_all, -1)'
        WHEN 'vm_ev_per_resource_oz_precious' THEN 'COALESCE(vm.ev_per_resource_oz_precious, -1)'
        WHEN 'vm_ev_per_reserve_oz_precious' THEN 'COALESCE(vm.ev_per_reserve_oz_precious, -1)'
        WHEN 'vm_mkt_cap_per_resource_oz_precious' THEN 'COALESCE(vm.mkt_cap_per_resource_oz_precious, -1)'
        WHEN 'vm_mkt_cap_per_reserve_oz_precious' THEN 'COALESCE(vm.mkt_cap_per_reserve_oz_precious, -1)'
        
        -- Production metrics (p_ prefix)
        WHEN 'p_current_production_total_aueq_koz' THEN 'COALESCE(p.current_production_total_aueq_koz, -1)'
        WHEN 'p_future_production_total_aueq_koz' THEN 'COALESCE(p.future_production_total_aueq_koz, -1)'
        WHEN 'p_reserve_life_years' THEN 'COALESCE(p.reserve_life_years, -1)'
        WHEN 'p_current_production_precious_aueq_koz' THEN 'COALESCE(p.current_production_precious_aueq_koz, -1)'
        WHEN 'p_current_production_non_precious_aueq_koz' THEN 'COALESCE(p.current_production_non_precious_aueq_koz, -1)'
        
        -- Cost metrics (c_ prefix)
        WHEN 'c_aisc_future' THEN 'COALESCE(cst.aisc_future, -1)'
        WHEN 'c_construction_costs' THEN 'COALESCE(cst.construction_costs, -1)'
        WHEN 'c_tco_future' THEN 'COALESCE(cst.tco_future, -1)'
        WHEN 'c_aisc_last_quarter' THEN 'COALESCE(cst.aisc_last_quarter, -1)'
        WHEN 'c_aisc_last_year' THEN 'COALESCE(cst.aisc_last_year, -1)'
        
        ELSE 'COALESCE(co.company_name, '''')'
    END;

    -- Build WHERE clause dynamically
    where_clause := 'TRUE';

    -- Search Term
    IF _search_term IS NOT NULL AND _search_term != '' THEN
        where_clause := where_clause || format(' AND (co.company_name ILIKE %L OR co.tsx_code ILIKE %L)', '%' || _search_term || '%', '%' || _search_term || '%');
    END IF;

    -- Status Filter
    IF _status_filter IS NOT NULL AND array_length(_status_filter, 1) > 0 THEN
        where_clause := where_clause || format(' AND co.status = ANY(%L)', _status_filter);
    END IF;

    -- Range Filters
    IF _min_f_market_cap_value IS NOT NULL THEN
        where_clause := where_clause || format(' AND f.market_cap_value >= %s', _min_f_market_cap_value);
    END IF;
    IF _max_f_market_cap_value IS NOT NULL THEN
        where_clause := where_clause || format(' AND f.market_cap_value <= %s', _max_f_market_cap_value);
    END IF;
    IF _min_percent_gold IS NOT NULL THEN
        where_clause := where_clause || format(' AND co.percent_gold >= %s', _min_percent_gold);
    END IF;
    IF _max_percent_gold IS NOT NULL THEN
        where_clause := where_clause || format(' AND co.percent_gold <= %s', _max_percent_gold);
    END IF;
    IF _min_percent_silver IS NOT NULL THEN
        where_clause := where_clause || format(' AND co.percent_silver >= %s', _min_percent_silver);
    END IF;
    IF _max_percent_silver IS NOT NULL THEN
        where_clause := where_clause || format(' AND co.percent_silver <= %s', _max_percent_silver);
    END IF;

    -- Estimate total rows
    BEGIN
        EXECUTE format(
            'EXPLAIN (FORMAT JSON) SELECT 1 FROM companies co ' ||
            'LEFT JOIN financials f ON co.company_id = f.company_id ' ||
            'LEFT JOIN capital_structure cs ON co.company_id = cs.company_id ' ||
            'LEFT JOIN mineral_estimates me ON co.company_id = me.company_id ' ||
            'LEFT JOIN valuation_metrics vm ON co.company_id = vm.company_id ' ||
            'LEFT JOIN production p ON co.company_id = p.company_id ' ||
            'LEFT JOIN costs cst ON co.company_id = cst.company_id ' ||
            'WHERE %s',
            where_clause
        ) INTO query_plan;
        _total_rows_estimate := (query_plan->0->'Plan'->>'Plan Rows')::BIGINT;
    EXCEPTION WHEN OTHERS THEN
        RAISE NOTICE 'Could not estimate rows using EXPLAIN, falling back to 0. Error: %', SQLERRM;
        _total_rows_estimate := 0;
    END;

    IF _total_rows_estimate IS NULL THEN
        _total_rows_estimate := 0;
    END IF;

    -- Build and execute the main query
    main_query := format(
        'SELECT CAST(%L AS BIGINT) AS total_rows, ' ||
        'co.company_id, co.company_name, co.tsx_code, co.status, co.headquarters, co.description, co.minerals_of_interest, co.percent_gold, co.percent_silver, ' ||
        'CASE WHEN cs.existing_shares > 0 THEN f.market_cap_value / cs.existing_shares ELSE NULL END AS share_price, ' ||
        'f.cash_value AS f_cash_value, f.market_cap_value AS f_market_cap_value, f.enterprise_value_value AS f_enterprise_value_value, ' ||
        'f.net_financial_assets AS f_net_financial_assets, f.free_cash_flow AS f_free_cash_flow, f.price_to_book AS f_price_to_book, ' ||
        'f.price_to_sales AS f_price_to_sales, f.enterprise_to_revenue AS f_enterprise_to_revenue, f.enterprise_to_ebitda AS f_enterprise_to_ebitda, ' ||
        'f.trailing_pe AS f_trailing_pe, f.forward_pe AS f_forward_pe, f.revenue_value AS f_revenue_value, f.ebitda AS f_ebitda, ' ||
        'f.net_income_value AS f_net_income_value, f.debt_value AS f_debt_value, f.shares_outstanding AS f_shares_outstanding, ' ||
        'cs.existing_shares AS cs_existing_shares, cs.fully_diluted_shares AS cs_fully_diluted_shares, ' ||
        'cs.in_the_money_options AS cs_in_the_money_options, cs.options_revenue AS cs_options_revenue, ' ||
        'me.reserves_total_aueq_moz AS me_reserves_total_aueq_moz, me.measured_indicated_total_aueq_moz AS me_measured_indicated_total_aueq_moz, ' ||
        'me.resources_total_aueq_moz AS me_resources_total_aueq_moz, me.potential_total_aueq_moz AS me_potential_total_aueq_moz, ' ||
        'me.reserves_precious_aueq_moz AS me_reserves_precious_aueq_moz, me.measured_indicated_precious_aueq_moz AS me_measured_indicated_precious_aueq_moz, ' ||
        'me.resources_precious_aueq_moz AS me_resources_precious_aueq_moz, ' ||
        'vm.ev_per_resource_oz_all AS vm_ev_per_resource_oz_all, vm.ev_per_reserve_oz_all AS vm_ev_per_reserve_oz_all, ' ||
        'vm.mkt_cap_per_resource_oz_all AS vm_mkt_cap_per_resource_oz_all, vm.mkt_cap_per_reserve_oz_all AS vm_mkt_cap_per_reserve_oz_all, ' ||
        'vm.ev_per_resource_oz_precious AS vm_ev_per_resource_oz_precious, vm.ev_per_reserve_oz_precious AS vm_ev_per_reserve_oz_precious, ' ||
        'vm.mkt_cap_per_resource_oz_precious AS vm_mkt_cap_per_resource_oz_precious, vm.mkt_cap_per_reserve_oz_precious AS vm_mkt_cap_per_reserve_oz_precious, ' ||
        'p.current_production_total_aueq_koz AS p_current_production_total_aueq_koz, p.future_production_total_aueq_koz AS p_future_production_total_aueq_koz, ' ||
        'p.reserve_life_years AS p_reserve_life_years, p.current_production_precious_aueq_koz AS p_current_production_precious_aueq_koz, ' ||
        'p.current_production_non_precious_aueq_koz AS p_current_production_non_precious_aueq_koz, ' ||
        'cst.aisc_future AS c_aisc_future, cst.construction_costs AS c_construction_costs, cst.tco_future AS c_tco_future, ' ||
        'cst.aisc_last_quarter AS c_aisc_last_quarter, cst.aisc_last_year AS c_aisc_last_year ' ||
        'FROM companies co ' ||
        'LEFT JOIN financials f ON co.company_id = f.company_id ' ||
        'LEFT JOIN capital_structure cs ON co.company_id = cs.company_id ' ||
        'LEFT JOIN mineral_estimates me ON co.company_id = me.company_id ' ||
        'LEFT JOIN valuation_metrics vm ON co.company_id = vm.company_id ' ||
        'LEFT JOIN production p ON co.company_id = p.company_id ' ||
        'LEFT JOIN costs cst ON co.company_id = cst.company_id ' ||
        'WHERE %s ' ||
        'ORDER BY %s %s ' ||
        'LIMIT %s OFFSET %s',
        _total_rows_estimate,
        where_clause,
        _sort_column_sql,
        _sort_direction_sql,
        page_size,
        _offset
    );

    -- Execute the query
    RETURN QUERY EXECUTE main_query;
END;
$$;

-- Maintain existing permissions
GRANT EXECUTE ON FUNCTION get_companies_paginated(INT, INT, TEXT, TEXT, TEXT, JSONB) TO authenticated;