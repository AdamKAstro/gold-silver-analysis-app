/*
  # Fix Company Sorting

  1. Changes
    - Update get_companies_paginated function to properly handle sorting
    - Add support for all sortable columns
    - Fix column name mapping for sorting
    - Ensure proper SQL injection protection
    - Add validation for sort parameters

  2. Security
    - Maintain existing RLS policies
    - Use parameterized queries for safety
*/

CREATE OR REPLACE FUNCTION get_companies_paginated(
    page_num integer,
    page_size integer,
    sort_column text,
    sort_direction text,
    target_currency text,
    filters jsonb
) RETURNS SETOF json AS $$
DECLARE
    query_text text;
    where_clause text := ' WHERE 1=1';
    sort_sql text;
    valid_sort_columns text[] := ARRAY[
        'company_name', 'tsx_code', 'status', 'percent_gold', 'percent_silver', 'share_price',
        'f_market_cap_value', 'f_enterprise_value_value', 'f_cash_value', 'f_debt_value',
        'f_net_financial_assets', 'f_free_cash_flow', 'f_revenue_value', 'f_ebitda',
        'f_net_income_value', 'me_reserves_total_aueq_moz', 'me_measured_indicated_total_aueq_moz',
        'me_resources_total_aueq_moz', 'p_current_production_total_aueq_koz',
        'p_future_production_total_aueq_koz', 'c_aisc_future'
    ];
BEGIN
    -- Input validation
    IF page_num < 1 THEN
        RAISE EXCEPTION 'page_num must be greater than 0';
    END IF;
    IF page_size < 1 THEN
        RAISE EXCEPTION 'page_size must be greater than 0';
    END IF;
    IF sort_direction NOT IN ('asc', 'desc') THEN
        sort_direction := 'asc';
    END IF;

    -- Validate and sanitize sort column
    IF sort_column IS NULL OR NOT sort_column = ANY(valid_sort_columns) THEN
        sort_column := 'company_name';
    END IF;

    -- Handle filters
    IF filters ? 'status' AND jsonb_array_length(filters->'status') > 0 THEN
        where_clause := where_clause || format(
            ' AND LOWER(status) = ANY($1::text[])',
            (SELECT array_agg(LOWER(x::text)) FROM jsonb_array_elements_text(filters->'status') x)
        );
    END IF;

    IF filters ? 'searchTerm' AND (filters->>'searchTerm') IS NOT NULL AND (filters->>'searchTerm') != '' THEN
        where_clause := where_clause || format(
            ' AND (LOWER(company_name) LIKE LOWER($2) OR LOWER(tsx_code) LIKE LOWER($2))',
            '%' || (filters->>'searchTerm') || '%'
        );
    END IF;

    -- Build sort clause with NULLS LAST
    sort_sql := format(
        ' ORDER BY %I %s NULLS LAST',
        sort_column,
        sort_direction
    );

    -- Construct final query
    query_text := format(
        'WITH filtered_companies AS (
            SELECT 
                c.*,
                f.*,
                me.*,
                vm.*,
                p.*,
                cs.*,
                COUNT(*) OVER() as total_rows
            FROM companies c
            LEFT JOIN financials f ON c.company_id = f.company_id
            LEFT JOIN mineral_estimates me ON c.company_id = me.company_id
            LEFT JOIN valuation_metrics vm ON c.company_id = vm.company_id
            LEFT JOIN production p ON c.company_id = p.company_id
            LEFT JOIN costs cs ON c.company_id = cs.company_id
            %s
        )
        SELECT json_build_object(
            ''company_id'', company_id,
            ''company_name'', company_name,
            ''tsx_code'', tsx_code,
            ''status'', status,
            ''headquarters'', headquarters,
            ''minerals_of_interest'', minerals_of_interest,
            ''percent_gold'', percent_gold,
            ''percent_silver'', percent_silver,
            ''share_price'', share_price,
            ''total_rows'', total_rows,
            -- Include all joined fields with appropriate prefixes
            ''f_market_cap_value'', market_cap_value,
            ''f_enterprise_value_value'', enterprise_value_value,
            ''f_cash_value'', cash_value,
            ''f_debt_value'', debt_value,
            ''f_net_financial_assets'', net_financial_assets,
            ''f_free_cash_flow'', free_cash_flow,
            ''f_revenue_value'', revenue_value,
            ''f_ebitda'', ebitda,
            ''f_net_income_value'', net_income_value,
            ''me_reserves_total_aueq_moz'', reserves_total_aueq_moz,
            ''me_measured_indicated_total_aueq_moz'', measured_indicated_total_aueq_moz,
            ''me_resources_total_aueq_moz'', resources_total_aueq_moz,
            ''p_current_production_total_aueq_koz'', current_production_total_aueq_koz,
            ''p_future_production_total_aueq_koz'', future_production_total_aueq_koz,
            ''c_aisc_future'', aisc_future
        )
        FROM filtered_companies
        %s
        LIMIT $3 OFFSET $4',
        where_clause,
        sort_sql
    );

    -- Execute query with parameters
    RETURN QUERY EXECUTE query_text
    USING 
        CASE WHEN filters ? 'status' THEN (
            SELECT array_agg(LOWER(x::text))
            FROM jsonb_array_elements_text(filters->'status') x
        ) ELSE NULL END,
        CASE WHEN filters ? 'searchTerm' THEN
            '%' || (filters->>'searchTerm') || '%'
        ELSE NULL END,
        page_size,
        (page_num - 1) * page_size;
END;
$$ LANGUAGE plpgsql;