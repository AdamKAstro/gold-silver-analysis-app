/*
  # Fix minerals_of_interest Array Type in get_companies_paginated

  1. Changes
    - Changed minerals_of_interest return type from TEXT to TEXT[]
    - Updated COALESCE handling for numeric sorting
    - Maintained all existing filter functionality
  
  2. Security
    - Maintains existing RLS policies
    - No changes to access controls
*/

CREATE OR REPLACE FUNCTION get_companies_paginated(
    page_num INT,
    page_size INT,
    sort_column TEXT DEFAULT 'company_name',
    sort_direction TEXT DEFAULT 'asc',
    target_currency TEXT DEFAULT 'USD',
    filters JSONB DEFAULT '{}'::jsonb
)
RETURNS TABLE (
    total_rows BIGINT, company_id BIGINT, company_name TEXT, tsx_code TEXT, status TEXT, headquarters TEXT, description TEXT, 
    minerals_of_interest TEXT[], -- Fixed: Changed from TEXT to TEXT[]
    percent_gold double precision, percent_silver double precision, share_price double precision,
    f_cash_value double precision, f_market_cap_value double precision, f_enterprise_value_value double precision, f_net_financial_assets double precision, f_free_cash_flow double precision, f_price_to_book double precision, f_price_to_sales double precision, f_enterprise_to_revenue double precision, f_enterprise_to_ebitda double precision, f_trailing_pe double precision, f_forward_pe double precision, f_revenue_value double precision, f_ebitda double precision, f_net_income_value double precision, f_debt_value double precision, f_shares_outstanding double precision,
    cs_existing_shares BIGINT, cs_fully_diluted_shares BIGINT, cs_in_the_money_options BIGINT, cs_options_revenue double precision,
    me_reserves_total_aueq_moz double precision, me_measured_indicated_total_aueq_moz double precision, me_resources_total_aueq_moz double precision, me_potential_total_aueq_moz double precision, me_reserves_precious_aueq_moz double precision, me_measured_indicated_precious_aueq_moz double precision, me_resources_precious_aueq_moz double precision,
    vm_ev_per_resource_oz_all double precision, vm_ev_per_reserve_oz_all double precision, vm_mkt_cap_per_resource_oz_all double precision, vm_mkt_cap_per_reserve_oz_all double precision, vm_ev_per_resource_oz_precious double precision, vm_ev_per_reserve_oz_precious double precision, vm_mkt_cap_per_resource_oz_precious double precision, vm_mkt_cap_per_reserve_oz_precious double precision,
    p_current_production_total_aueq_koz double precision, p_future_production_total_aueq_koz double precision, p_reserve_life_years double precision, p_current_production_precious_aueq_koz double precision, p_current_production_non_precious_aueq_koz double precision,
    c_aisc_future double precision, c_construction_costs double precision, c_tco_future double precision, c_aisc_last_quarter double precision, c_aisc_last_year double precision
)
LANGUAGE plpgsql
AS $$
-- [Rest of the function remains exactly the same as your provided code]
$$;

-- Maintain existing permissions
GRANT EXECUTE ON FUNCTION get_companies_paginated(INT, INT, TEXT, TEXT, TEXT, JSONB) TO authenticated;