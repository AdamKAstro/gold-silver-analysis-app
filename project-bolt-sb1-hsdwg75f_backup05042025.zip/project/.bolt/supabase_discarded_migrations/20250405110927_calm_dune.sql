/*
  # Add companies paginated function

  1. New Functions
    - `get_companies_paginated`: Retrieves paginated company data with filtering and sorting
      - Parameters:
        - page_num: Page number to retrieve
        - page_size: Number of records per page
        - sort_configs: Array of sort configurations
        - target_currency: Currency for financial values
        - filters: JSON object containing filter criteria

  2. Security
    - Function is accessible to all authenticated users
*/

CREATE OR REPLACE FUNCTION public.get_companies_paginated(
  page_num integer,
  page_size integer,
  sort_configs jsonb,
  target_currency text,
  filters jsonb
) RETURNS TABLE (
  company_id bigint,
  tsx_code text,
  company_name text,
  name_alt text,
  status text,
  headquarters text,
  minerals_of_interest text,
  percent_gold double precision,
  percent_silver double precision,
  description text,
  last_updated timestamptz,
  total_rows bigint,
  -- Include all the joined fields here
  f_market_cap_value double precision,
  f_enterprise_value_value double precision,
  f_cash_value double precision,
  f_debt_value double precision,
  f_net_financial_assets double precision,
  f_free_cash_flow double precision,
  f_price_to_book double precision,
  f_price_to_sales double precision,
  f_enterprise_to_revenue double precision,
  f_enterprise_to_ebitda double precision,
  f_trailing_pe double precision,
  f_forward_pe double precision,
  f_revenue_value double precision,
  f_ebitda double precision,
  f_net_income_value double precision,
  f_shares_outstanding double precision,
  cs_existing_shares bigint,
  cs_fully_diluted_shares bigint,
  cs_in_the_money_options bigint,
  cs_options_revenue double precision,
  me_reserves_total_aueq_moz double precision,
  me_measured_indicated_total_aueq_moz double precision,
  me_resources_total_aueq_moz double precision,
  me_potential_total_aueq_moz double precision,
  me_reserves_precious_aueq_moz double precision,
  me_measured_indicated_precious_aueq_moz double precision,
  me_resources_precious_aueq_moz double precision,
  vm_ev_per_resource_oz_all double precision,
  vm_ev_per_reserve_oz_all double precision,
  vm_mkt_cap_per_resource_oz_all double precision,
  vm_mkt_cap_per_reserve_oz_all double precision,
  vm_ev_per_resource_oz_precious double precision,
  vm_ev_per_reserve_oz_precious double precision,
  vm_mkt_cap_per_resource_oz_precious double precision,
  vm_mkt_cap_per_reserve_oz_precious double precision,
  p_current_production_total_aueq_koz double precision,
  p_future_production_total_aueq_koz double precision,
  p_reserve_life_years double precision,
  p_current_production_precious_aueq_koz double precision,
  p_current_production_non_precious_aueq_koz double precision,
  c_aisc_future double precision,
  c_construction_costs double precision,
  c_tco_future double precision,
  c_aisc_last_quarter double precision,
  c_aisc_last_year double precision
) LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  query_text text;
  where_clauses text[];
  sort_clause text;
  sort_item jsonb;
BEGIN
  -- Start building the base query
  query_text := '
    WITH base_query AS (
      SELECT 
        c.*,
        f.market_cap_value as f_market_cap_value,
        f.enterprise_value_value as f_enterprise_value_value,
        f.cash_value as f_cash_value,
        f.debt_value as f_debt_value,
        f.net_financial_assets as f_net_financial_assets,
        f.free_cash_flow as f_free_cash_flow,
        f.price_to_book as f_price_to_book,
        f.price_to_sales as f_price_to_sales,
        f.enterprise_to_revenue as f_enterprise_to_revenue,
        f.enterprise_to_ebitda as f_enterprise_to_ebitda,
        f.trailing_pe as f_trailing_pe,
        f.forward_pe as f_forward_pe,
        f.revenue_value as f_revenue_value,
        f.ebitda as f_ebitda,
        f.net_income_value as f_net_income_value,
        f.shares_outstanding as f_shares_outstanding,
        cs.existing_shares as cs_existing_shares,
        cs.fully_diluted_shares as cs_fully_diluted_shares,
        cs.in_the_money_options as cs_in_the_money_options,
        cs.options_revenue as cs_options_revenue,
        me.reserves_total_aueq_moz as me_reserves_total_aueq_moz,
        me.measured_indicated_total_aueq_moz as me_measured_indicated_total_aueq_moz,
        me.resources_total_aueq_moz as me_resources_total_aueq_moz,
        me.potential_total_aueq_moz as me_potential_total_aueq_moz,
        me.reserves_precious_aueq_moz as me_reserves_precious_aueq_moz,
        me.measured_indicated_precious_aueq_moz as me_measured_indicated_precious_aueq_moz,
        me.resources_precious_aueq_moz as me_resources_precious_aueq_moz,
        vm.ev_per_resource_oz_all as vm_ev_per_resource_oz_all,
        vm.ev_per_reserve_oz_all as vm_ev_per_reserve_oz_all,
        vm.mkt_cap_per_resource_oz_all as vm_mkt_cap_per_resource_oz_all,
        vm.mkt_cap_per_reserve_oz_all as vm_mkt_cap_per_reserve_oz_all,
        vm.ev_per_resource_oz_precious as vm_ev_per_resource_oz_precious,
        vm.ev_per_reserve_oz_precious as vm_ev_per_reserve_oz_precious,
        vm.mkt_cap_per_resource_oz_precious as vm_mkt_cap_per_resource_oz_precious,
        vm.mkt_cap_per_reserve_oz_precious as vm_mkt_cap_per_reserve_oz_precious,
        p.current_production_total_aueq_koz as p_current_production_total_aueq_koz,
        p.future_production_total_aueq_koz as p_future_production_total_aueq_koz,
        p.reserve_life_years as p_reserve_life_years,
        p.current_production_precious_aueq_koz as p_current_production_precious_aueq_koz,
        p.current_production_non_precious_aueq_koz as p_current_production_non_precious_aueq_koz,
        co.aisc_future as c_aisc_future,
        co.construction_costs as c_construction_costs,
        co.tco_future as c_tco_future,
        co.aisc_last_quarter as c_aisc_last_quarter,
        co.aisc_last_year as c_aisc_last_year,
        COUNT(*) OVER() as total_rows
      FROM companies c
      LEFT JOIN financials f ON c.company_id = f.company_id
      LEFT JOIN capital_structure cs ON c.company_id = cs.company_id
      LEFT JOIN mineral_estimates me ON c.company_id = me.company_id
      LEFT JOIN valuation_metrics vm ON c.company_id = vm.company_id
      LEFT JOIN production p ON c.company_id = p.company_id
      LEFT JOIN costs co ON c.company_id = co.company_id
    ';

  -- Initialize where clauses array
  where_clauses := ARRAY[]::text[];

  -- Add status filter if provided
  IF filters ? 'status' AND jsonb_array_length(filters->'status') > 0 THEN
    where_clauses := where_clauses || format(
      'c.status = ANY($1::text[])',
      filters->'status'
    );
  END IF;

  -- Add search term filter if provided
  IF filters ? 'searchTerm' AND (filters->>'searchTerm')::text <> '' THEN
    where_clauses := where_clauses || format(
      '(c.company_name ILIKE ''%%'' || $2 || ''%%'' OR c.tsx_code ILIKE ''%%'' || $2 || ''%%'')',
      filters->>'searchTerm'
    );
  END IF;

  -- Add metric range filters
  FOR metric IN 
    SELECT key, value 
    FROM jsonb_each(filters)
    WHERE key LIKE 'min_%' OR key LIKE 'max_%'
  LOOP
    IF metric.key LIKE 'min_%' THEN
      where_clauses := where_clauses || format(
        '%I >= %s',
        substring(metric.key from 5),
        metric.value
      );
    ELSIF metric.key LIKE 'max_%' THEN
      where_clauses := where_clauses || format(
        '%I <= %s',
        substring(metric.key from 5),
        metric.value
      );
    END IF;
  END LOOP;

  -- Combine where clauses if any exist
  IF array_length(where_clauses, 1) > 0 THEN
    query_text := query_text || ' WHERE ' || array_to_string(where_clauses, ' AND ');
  END IF;

  -- Add sorting
  sort_clause := '';
  FOR sort_item IN SELECT * FROM jsonb_array_elements(sort_configs)
  LOOP
    IF sort_clause <> '' THEN
      sort_clause := sort_clause || ', ';
    END IF;
    sort_clause := sort_clause || format(
      '%I %s',
      sort_item->>'column',
      sort_item->>'direction'
    );
  END LOOP;

  IF sort_clause = '' THEN
    sort_clause := 'company_name ASC';
  END IF;

  query_text := query_text || ' ORDER BY ' || sort_clause;

  -- Add pagination
  query_text := query_text || format(
    ' LIMIT %s OFFSET %s',
    page_size,
    (page_num - 1) * page_size
  );

  -- Execute the query
  RETURN QUERY EXECUTE query_text
  USING 
    CASE WHEN filters ? 'status' THEN ARRAY(SELECT jsonb_array_elements_text(filters->'status')) ELSE NULL END,
    CASE WHEN filters ? 'searchTerm' THEN filters->>'searchTerm' ELSE NULL END;
END;
$$;