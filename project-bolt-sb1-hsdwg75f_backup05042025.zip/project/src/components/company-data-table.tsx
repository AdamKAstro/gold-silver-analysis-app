import React, { useMemo, useCallback, useRef, useLayoutEffect, memo } from 'react';
import * as Tooltip from '@radix-ui/react-tooltip';
import { ArrowUpDown, ArrowUp, ArrowDown, HelpCircle, Lock, ChevronLeft, ChevronRight } from 'lucide-react';
import type { Company, SortState, ColumnTier, ColumnAccess, ColumnDef, ColumnGroup, CompanyStatus, SortDirection, SortConfig } from '../lib/types';
import { TierBadge } from './ui/tier-badge';
import { cn, getNestedValue, formatNumber, formatCurrency, formatPercent } from '../lib/utils';
import { StatusBadge } from './status-badge';
import { CompanyNameBadge } from './company-name-badge';
import { MineralsList } from './mineral-badge';
import { getAccessibleMetrics, getMetricByKey } from '../lib/metric-types';
import { Button } from './ui/button';

interface CompanyDataTableProps {
  companies: Company[];
  onSort: (key: string, direction: SortDirection, event: React.MouseEvent) => void;
  currentSort: { sortConfigs: SortConfig[] };
  currentTier: ColumnTier;
  page: number;
  pageSize: number;
  totalCount: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
}

const pageSizeOptions = [10, 25, 50, 100];

// Column definitions with improved typing and organization
const columnGroups: ColumnGroup[] = [
  {
    title: 'Company Info',
    description: 'Basic company information and status',
    columns: [
      { key: 'company_name', label: 'Company', sortable: true, sortKey: 'company_name', width: '210px' },
      { key: 'status', label: 'Status', sortable: true, sortKey: 'status', width: '120px' },
      { key: 'minerals', label: 'Minerals', width: '120px' },
      { key: 'percent_gold', label: 'Gold %', sortable: true, sortKey: 'percent_gold', format: 'percent', width: '90px', description: 'Percentage of production/resources as gold' },
      { key: 'percent_silver', label: 'Silver %', sortable: true, sortKey: 'percent_silver', format: 'percent', width: '90px', description: 'Percentage of production/resources as silver' }
    ],
    className: 'sticky left-0 z-20 bg-navy-500'
  },
  {
    title: 'Market Data',
    description: 'Current market and trading information',
    columns: [
      { key: 'share_price', label: 'Share Price', sortable: true, sortKey: 'share_price', format: 'currency', width: '110px' },
      { key: 'market_cap', label: 'Market Cap', sortable: true, sortKey: 'f_market_cap_value', format: 'currency', width: '110px' },
      { key: 'enterprise_value', label: 'Enterprise Value', sortable: true, sortKey: 'f_enterprise_value_value', format: 'currency', width: '120px' }
    ],
    className: ''
  },
  {
    title: 'Financial Position',
    description: 'Key financial metrics and ratios',
    columns: [
      { key: 'cash', label: 'Cash', sortable: true, sortKey: 'f_cash_value', format: 'currency', width: '100px' },
      { key: 'debt', label: 'Debt', sortable: true, sortKey: 'f_debt_value', format: 'currency', width: '100px', access: { tier: 'medium', description: 'Total debt position' } },
      { key: 'net_assets', label: 'Net Fin. Assets', sortable: true, sortKey: 'f_net_financial_assets', format: 'currency', width: '110px' }
    ],
    className: ''
  }
];

// Memoized pagination component
const Pagination = memo(function Pagination({ 
  page, 
  pageSize, 
  totalCount, 
  onPageChange, 
  onPageSizeChange 
}: { 
  page: number; 
  pageSize: number; 
  totalCount: number; 
  onPageChange: (page: number) => void; 
  onPageSizeChange: (pageSize: number) => void; 
}) {
  const totalPages = Math.ceil(totalCount / pageSize);
  const startItem = (page - 1) * pageSize + 1;
  const endItem = Math.min(startItem + pageSize - 1, totalCount);

  return (
    <div className="flex items-center justify-between px-4 py-3 bg-navy-400/20 border-t border-navy-300/20">
      <div className="flex items-center gap-2">
        <select
          value={pageSize}
          onChange={(e) => onPageSizeChange(Number(e.target.value))}
          className="text-sm bg-navy-400/20 border border-navy-300/20 rounded-md text-surface-white px-2 py-1"
        >
          {pageSizeOptions.map((size) => (
            <option key={size} value={size}>
              {size} per page
            </option>
          ))}
        </select>
        <span className="text-sm text-surface-white/70">
          Showing {startItem}-{endItem} of {totalCount}
        </span>
      </div>

      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onPageChange(page - 1)}
          disabled={page === 1}
          className="text-surface-white/70 hover:text-surface-white disabled:opacity-50"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <span className="text-sm text-surface-white/70">
          Page {page} of {totalPages}
        </span>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onPageChange(page + 1)}
          disabled={page === totalPages}
          className="text-surface-white/70 hover:text-surface-white disabled:opacity-50"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
});

// Memoized table cell component
const TableCell = memo(function TableCell({ 
  column, 
  company, 
  isAccessible 
}: { 
  column: ColumnDef; 
  company: Company; 
  isAccessible: boolean; 
}) {
  const value = getNestedValue(company, column.key);

  const renderContent = () => {
    if (!isAccessible) {
      return (
        <div className="flex items-center gap-1 opacity-50">
          <Lock className="h-3 w-3" />
          <TierBadge tier={column.access!.tier} showIcon={false} />
        </div>
      );
    }

    switch (column.key) {
      case 'company_name':
        return (
          <CompanyNameBadge
            name={company.company_name}
            code={company.tsx_code || ''}
            headquarters={company.headquarters}
            description={company.description}
          />
        );
      case 'status':
        return <StatusBadge status={company.status} />;
      case 'minerals':
        return <MineralsList minerals={company.minerals_of_interest} />;
      case 'percent_gold':
        return formatPercent(company.percent_gold);
      case 'percent_silver':
        return formatPercent(company.percent_silver);
      case 'share_price':
        return formatCurrency(company.share_price);
      case 'market_cap':
        return formatCurrency(company.financials.market_cap_value);
      case 'enterprise_value':
        return formatCurrency(company.financials.enterprise_value_value);
      case 'cash':
        return formatCurrency(company.financials.cash_value);
      case 'debt':
        return formatCurrency(company.financials.debt_value);
      case 'net_assets':
        return formatCurrency(company.financials.net_financial_assets);
      default:
        return value ?? '-';
    }
  };

  return (
    <td
      className={cn(
        "table-cell",
        column.format && "text-right",
        !isAccessible && "text-surface-white/40",
        column.width && `w-[${column.width}]`
      )}
    >
      {renderContent()}
    </td>
  );
});

export function CompanyDataTable({
  companies,
  onSort,
  currentSort,
  currentTier,
  page,
  pageSize,
  totalCount,
  onPageChange,
  onPageSizeChange
}: CompanyDataTableProps) {
  const tableRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLTableSectionElement>(null);

  // Improved scroll sync with transform
  useLayoutEffect(() => {
    const table = tableRef.current;
    const header = headerRef.current;
    if (!table || !header) return;

    const handleScroll = () => {
      requestAnimationFrame(() => {
        if (header && table) {
          header.style.transform = `translateX(-${table.scrollLeft}px)`;
        }
      });
    };

    table.addEventListener('scroll', handleScroll);
    return () => table.removeEventListener('scroll', handleScroll);
  }, []);

  const isColumnAccessible = useCallback((column: ColumnDef): boolean => {
    if (!column.access) return true;
    const tierLevels = { 'free': 0, 'medium': 1, 'premium': 2 };
    return tierLevels[currentTier] >= tierLevels[column.access.tier];
  }, [currentTier]);

  const handleSort = useCallback((key: string, event: React.MouseEvent) => {
    const currentConfig = currentSort.sortConfigs.find(c => c.key === key);
    const direction = !currentConfig ? 'desc' : currentConfig.direction === 'desc' ? 'asc' : 'desc';
    onSort(key, direction, event);
  }, [currentSort.sortConfigs, onSort]);

  const getSortIcon = useCallback((key: string, sortConfigs: SortConfig[]) => {
    const config = sortConfigs.find(c => c.key === key);
    if (!config) {
      return <ArrowUpDown className="h-3 w-3 text-surface-white/40" />;
    }
    
    const priority = config.priority > 0 ? config.priority + 1 : '';
    return (
      <div className="flex items-center gap-0.5">
        {config.direction === 'asc' ? (
          <ArrowUp className="h-3 w-3 text-surface-white" />
        ) : (
          <ArrowDown className="h-3 w-3 text-surface-white" />
        )}
        {priority && (
          <span className="text-[10px] font-mono text-surface-white/70">
            {priority}
          </span>
        )}
      </div>
    );
  }, []);

  const tableHeader = useMemo(() => (
    <thead className="table-header sticky top-0 z-10" ref={headerRef}>
      <tr>
        {columnGroups.map((group, groupIndex) => (
          <th
            key={`${group.title}-${groupIndex}`}
            colSpan={group.columns.length}
            className={cn(
              "table-cell text-center font-bold group-header text-xs whitespace-nowrap p-2 border-b border-navy-300/20",
              group.className
            )}
          >
            <Tooltip.Root>
              <Tooltip.Trigger asChild>
                <div className="flex items-center justify-center gap-1 cursor-help">
                  {group.title} <HelpCircle className="h-3 w-3 text-surface-white/60" />
                </div>
              </Tooltip.Trigger>
              <Tooltip.Portal>
                <Tooltip.Content className="tooltip-content">
                  {group.description}
                  <Tooltip.Arrow className="fill-navy-400" />
                </Tooltip.Content>
              </Tooltip.Portal>
            </Tooltip.Root>
          </th>
        ))}
      </tr>
      <tr>
        {columnGroups.flatMap((group, groupIndex) =>
          group.columns.map((column, columnIndex) => {
            const isAccessible = isColumnAccessible(column);
            return (
              <th
                key={`${column.key}-${groupIndex}-${columnIndex}`}
                className={cn(
                  "table-cell font-semibold relative group text-xs whitespace-nowrap p-2 border-b border-x border-navy-300/20",
                  column.sortable && isAccessible && "cursor-pointer hover:bg-navy-400/20",
                  group.className,
                  column.width && `w-[${column.width}]`
                )}
                onClick={(event) => isAccessible && column.sortable && column.sortKey && handleSort(column.sortKey, event)}
                title={isAccessible && column.sortable ? `Sort by ${column.label}` : (isAccessible ? column.label : `Requires ${column.access?.tier} tier`)}
              >
                <Tooltip.Root>
                  <Tooltip.Trigger asChild>
                    <div className={cn("flex items-center gap-1", column.format ? "justify-end" : "justify-start")}>
                      {!isAccessible && (<Lock className="h-3 w-3 text-surface-white/40 mr-1" />)}
                      <span className={cn(!isAccessible && "opacity-50")}>{column.label}</span>
                      {column.description && (<HelpCircle className="h-3 w-3 text-surface-white/40" />)}
                      {column.sortable && isAccessible && (
                        <span className="ml-1">
                          {getSortIcon(column.sortKey || column.key, currentSort.sortConfigs)}
                        </span>
                      )}
                    </div>
                  </Tooltip.Trigger>
                  <Tooltip.Portal>
                    <Tooltip.Content className="tooltip-content">
                      {column.description}
                      {column.preferredValues && (
                        <div className="mt-1 text-xs text-surface-white/70">
                          {column.preferredValues}
                        </div>
                      )}
                      <Tooltip.Arrow className="fill-navy-400" />
                    </Tooltip.Content>
                  </Tooltip.Portal>
                </Tooltip.Root>
              </th>
            );
          })
        )}
      </tr>
    </thead>
  ), [columnGroups, isColumnAccessible, handleSort, getSortIcon, currentSort.sortConfigs]);

  return (
    <Tooltip.Provider>
      <div className="flex flex-col">
        <div className="table-container" ref={tableRef}>
          <table className="table-bg w-full">
            {tableHeader}
            <tbody>
              {companies.map((company) => (
                <tr key={company.company_id} className="hover-highlight">
                  {columnGroups.flatMap((group, groupIndex) =>
                    group.columns.map((column, columnIndex) => (
                      <TableCell
                        key={`${column.key}-${groupIndex}-${columnIndex}`}
                        column={column}
                        company={company}
                        isAccessible={isColumnAccessible(column)}
                      />
                    ))
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <Pagination
          page={page}
          pageSize={pageSize}
          totalCount={totalCount}
          onPageChange={onPageChange}
          onPageSizeChange={onPageSizeChange}
        />
      </div>
    </Tooltip.Provider>
  );
}