import React from 'react';
import { Link } from 'react-router-dom';
import { Home, RotateCcw } from 'lucide-react';
import { Button } from './button';
import { cn } from '../../lib/utils';
import { useFilters } from '../../contexts/filter-context';

interface PageContainerProps {
  title: string;
  description?: string;
  children: React.ReactNode;
  actions?: React.ReactNode;
  className?: string;
  showFilterInfo?: boolean;
}

export function PageContainer({
  title,
  description,
  children,
  actions,
  className,
  showFilterInfo = true
}: PageContainerProps) {
  const { totalCount, filterSettings, resetFilters } = useFilters();
  const hasActiveFilters = filterSettings.searchTerm || 
                          filterSettings.developmentStatus.length > 0 || 
                          Object.keys(filterSettings.metricRanges).length > 0;

  return (
    <div className="min-h-screen bg-navy-500">
      <div className="sticky top-14 z-30 bg-navy-500/95 backdrop-blur-sm border-b border-navy-300/20 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="ghost" size="icon" className="text-surface-white/70 hover:text-surface-white">
                  <Home className="h-5 w-5" />
                </Button>
              </Link>
              <div>
                <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-surface-white">{title}</h1>
                {description && (
                  <p className="text-xs sm:text-sm text-surface-white/70">{description}</p>
                )}
              </div>
            </div>
            {actions && (
              <div className="flex items-center gap-2">
                {actions}
              </div>
            )}
          </div>

          {showFilterInfo && hasActiveFilters && (
            <div className="mt-4 flex items-center justify-between gap-4 bg-navy-400/20 rounded-lg px-4 py-2">
              <div className="text-sm text-surface-white/70">
                <span className="font-medium text-surface-white">{totalCount}</span> companies match your filters
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={resetFilters}
                className="text-xs"
              >
                <RotateCcw className="mr-1.5 h-3.5 w-3.5" />
                Reset All Filters
              </Button>
            </div>
          )}
        </div>
      </div>

      <div className="container mx-auto px-4 py-4 space-y-4">
        <div className={cn("bg-navy-500 rounded-lg", className)}>
          {children}
        </div>
      </div>
    </div>
  );
}