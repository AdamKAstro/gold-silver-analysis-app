// src/App.tsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { SubscribePage } from './pages/subscribe';

function TestPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-navy-300 via-navy-200 to-navy-300">
      <div
        className="absolute inset-0 bg-cover bg-center opacity-70"
        style={{ backgroundImage: `url('/Background2.jpg')` }}
        aria-hidden="true"
      />
      <div className="absolute inset-0 bg-noise opacity-30" aria-hidden="true" />
      <div className="relative p-8 text-surface-white">
        <h1 className="text-3xl font-bold">Test Background</h1>
        <p>Gradient, Background2.jpg, and noise texture should be visible.</p>
      </div>
    </div>
  );
}

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-navy-500">
        <Routes>
          <Route path="/test" element={<TestPage />} />
          <Route path="/subscribe" element={<SubscribePage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;