import { supabase } from './supabaseClient';
import type { Company, Currency, FilterState, SortState, RpcResponseRow, PaginatedRowData } from './types';

interface GetPaginatedCompaniesResult {
  companies: Company[];
  totalCount: number;
}

const sanitizeValue = (value: any): string | number | boolean | null | any[] => {
    if (value === null || value === undefined) {
        return null;
    }
    if (typeof value === 'number') {
        return Number.isFinite(value) ? value : null;
    }
    if (Array.isArray(value)) {
        return value
            .map(item => typeof item === 'string' ? item : null)
            .filter(item => item !== null) as string[];
    }
    if (typeof value === 'string' || typeof value === 'boolean') {
        return value;
    }
    console.warn(`Attempted to serialize unsupported type (${typeof value}) for filter value:`, value);
    return null;
};

export async function getCompaniesForScatterChart(
  currency: Currency
): Promise<Company[]> {
  try {
    const { data, error } = await supabase.rpc<RpcResponseRow>(
      'get_companies_paginated',
      {
        page_num: 1,
        page_size: 1000, // Get all companies
        sort_column: 'company_name',
        sort_direction: 'asc',
        target_currency: currency,
        filters: {}
      }
    );

    if (error) {
      console.error('Supabase RPC Error:', error);
      throw new Error(`Database error fetching companies: ${error.message}`);
    }

    if (!data || data.length === 0) {
      return [];
    }

    const companies: Company[] = data.map((row): Company => ({
      company_id: row.company_id,
      company_name: row.company_name,
      tsx_code: row.tsx_code,
      status: row.status as Company['status'],
      headquarters: row.headquarters,
      description: row.description,
      minerals_of_interest: row.minerals_of_interest,
      percent_gold: row.percent_gold,
      percent_silver: row.percent_silver,
      share_price: row.share_price,

      financials: {
        cash_value: row.f_cash_value,
        market_cap_value: row.f_market_cap_value,
        enterprise_value_value: row.f_enterprise_value_value,
        net_financial_assets: row.f_net_financial_assets,
        free_cash_flow: row.f_free_cash_flow,
        price_to_book: row.f_price_to_book,
        price_to_sales: row.f_price_to_sales,
        enterprise_to_revenue: row.f_enterprise_to_revenue,
        enterprise_to_ebitda: row.f_enterprise_to_ebitda,
        trailing_pe: row.f_trailing_pe,
        forward_pe: row.f_forward_pe,
        revenue_value: row.f_revenue_value,
        ebitda: row.f_ebitda,
        net_income_value: row.f_net_income_value,
        debt_value: row.f_debt_value,
        shares_outstanding: row.f_shares_outstanding,
      },
      capital_structure: {
        existing_shares: row.cs_existing_shares,
        fully_diluted_shares: row.cs_fully_diluted_shares,
        in_the_money_options: row.cs_in_the_money_options,
        options_revenue: row.cs_options_revenue,
      },
      mineral_estimates: {
        reserves_total_aueq_moz: row.me_reserves_total_aueq_moz,
        measured_indicated_total_aueq_moz: row.me_measured_indicated_total_aueq_moz,
        resources_total_aueq_moz: row.me_resources_total_aueq_moz,
        potential_total_aueq_moz: row.me_potential_total_aueq_moz,
        reserves_precious_aueq_moz: row.me_reserves_precious_aueq_moz,
        measured_indicated_precious_aueq_moz: row.me_measured_indicated_precious_aueq_moz,
        resources_precious_aueq_moz: row.me_resources_precious_aueq_moz,
      },
      valuation_metrics: {
         ev_per_resource_oz_all: row.vm_ev_per_resource_oz_all,
         ev_per_reserve_oz_all: row.vm_ev_per_reserve_oz_all,
         mkt_cap_per_resource_oz_all: row.vm_mkt_cap_per_resource_oz_all,
         mkt_cap_per_reserve_oz_all: row.vm_mkt_cap_per_reserve_oz_all,
         ev_per_resource_oz_precious: row.vm_ev_per_resource_oz_precious,
         ev_per_reserve_oz_precious: row.vm_ev_per_reserve_oz_precious,
         mkt_cap_per_resource_oz_precious: row.vm_mkt_cap_per_resource_oz_precious,
         mkt_cap_per_reserve_oz_precious: row.vm_mkt_cap_per_reserve_oz_precious,
      },
      production: {
         current_production_total_aueq_koz: row.p_current_production_total_aueq_koz,
         future_production_total_aueq_koz: row.p_future_production_total_aueq_koz,
         reserve_life_years: row.p_reserve_life_years,
         current_production_precious_aueq_koz: row.p_current_production_precious_aueq_koz,
         current_production_non_precious_aueq_koz: row.p_current_production_non_precious_aueq_koz,
      },
      costs: {
         aisc_future: row.c_aisc_future,
         construction_costs: row.c_construction_costs,
         tco_future: row.c_tco_future,
         aisc_last_quarter: row.c_aisc_last_quarter,
         aisc_last_year: row.c_aisc_last_year,
      }
    }));

    return companies;

  } catch (err: any) {
    console.error('Error processing companies for scatter chart:', err);
    throw new Error(err.message || 'An unknown error occurred processing company data.');
  }
}

export async function getPaginatedCompanies(
  page: number,
  pageSize: number,
  sort: SortState,
  filtersState: FilterState,
  currency: Currency
): Promise<GetPaginatedCompaniesResult> {
  const filtersJson: Record<string, any> = {};

  // Handle search term
  const searchTermValue = filtersState.searchTerm;
  const sanitizedSearchTerm = (searchTermValue === null || searchTermValue === undefined) ? null : String(searchTermValue);
  if (sanitizedSearchTerm !== null && sanitizedSearchTerm !== '') {
      filtersJson.searchTerm = sanitizedSearchTerm;
  }

  // Handle status filter
  const statusFilterValue = filtersState.status;
  if (Array.isArray(statusFilterValue) && statusFilterValue.length > 0) {
      const sanitizedStatus = statusFilterValue.filter(s => typeof s === 'string');
      if (sanitizedStatus.length > 0) {
        filtersJson.status = sanitizedStatus;
      }
  }

  // Range filter helper function
  const addSanitizedRange = (keyPrefix: string, range: [any, any] | null | undefined) => {
    if (range && Array.isArray(range)) {
        const minVal = sanitizeValue(range[0]);
        const maxVal = sanitizeValue(range[1]);
        if (minVal !== null && typeof minVal === 'number') filtersJson[`min_${keyPrefix}`] = minVal;
        if (maxVal !== null && typeof maxVal === 'number') filtersJson[`max_${keyPrefix}`] = maxVal;
    } else if (range !== null && range !== undefined) {
        console.warn(`Filter range for ${keyPrefix} is not an array:`, range);
    }
  };

  // Add all range filters
  Object.entries(filtersState).forEach(([key, value]) => {
    if (key.endsWith('Range')) {
      const prefix = key.replace('Range', '');
      addSanitizedRange(prefix, value as [any, any]);
    }
  });

  const rpcParams = {
      page_num: page,
      page_size: pageSize,
      sort_column: sort.key,
      sort_direction: sort.direction,
      target_currency: currency,
      filters: filtersJson
  };

  try {
    const { data, error } = await supabase.rpc<RpcResponseRow>(
      'get_companies_paginated',
      rpcParams
    );

    if (error) {
      console.error('Supabase RPC Error:', error);
      throw new Error(`Database error fetching companies: ${error.message}`);
    }

    if (!data || data.length === 0) {
      return { companies: [], totalCount: 0 };
    }

    const totalCount = data[0]?.total_rows ?? 0;

    const companies: Company[] = data.map((row): Company => ({
      company_id: row.company_id,
      company_name: row.company_name,
      tsx_code: row.tsx_code,
      status: row.status as Company['status'],
      headquarters: row.headquarters,
      description: row.description,
      minerals_of_interest: row.minerals_of_interest,
      percent_gold: row.percent_gold,
      percent_silver: row.percent_silver,
      share_price: row.share_price,

      financials: {
        cash_value: row.f_cash_value,
        market_cap_value: row.f_market_cap_value,
        enterprise_value_value: row.f_enterprise_value_value,
        net_financial_assets: row.f_net_financial_assets,
        free_cash_flow: row.f_free_cash_flow,
        price_to_book: row.f_price_to_book,
        price_to_sales: row.f_price_to_sales,
        enterprise_to_revenue: row.f_enterprise_to_revenue,
        enterprise_to_ebitda: row.f_enterprise_to_ebitda,
        trailing_pe: row.f_trailing_pe,
        forward_pe: row.f_forward_pe,
        revenue_value: row.f_revenue_value,
        ebitda: row.f_ebitda,
        net_income_value: row.f_net_income_value,
        debt_value: row.f_debt_value,
        shares_outstanding: row.f_shares_outstanding,
      },
      capital_structure: {
        existing_shares: row.cs_existing_shares,
        fully_diluted_shares: row.cs_fully_diluted_shares,
        in_the_money_options: row.cs_in_the_money_options,
        options_revenue: row.cs_options_revenue,
      },
      mineral_estimates: {
        reserves_total_aueq_moz: row.me_reserves_total_aueq_moz,
        measured_indicated_total_aueq_moz: row.me_measured_indicated_total_aueq_moz,
        resources_total_aueq_moz: row.me_resources_total_aueq_moz,
        potential_total_aueq_moz: row.me_potential_total_aueq_moz,
        reserves_precious_aueq_moz: row.me_reserves_precious_aueq_moz,
        measured_indicated_precious_aueq_moz: row.me_measured_indicated_precious_aueq_moz,
        resources_precious_aueq_moz: row.me_resources_precious_aueq_moz,
      },
      valuation_metrics: {
         ev_per_resource_oz_all: row.vm_ev_per_resource_oz_all,
         ev_per_reserve_oz_all: row.vm_ev_per_reserve_oz_all,
         mkt_cap_per_resource_oz_all: row.vm_mkt_cap_per_resource_oz_all,
         mkt_cap_per_reserve_oz_all: row.vm_mkt_cap_per_reserve_oz_all,
         ev_per_resource_oz_precious: row.vm_ev_per_resource_oz_precious,
         ev_per_reserve_oz_precious: row.vm_ev_per_reserve_oz_precious,
         mkt_cap_per_resource_oz_precious: row.vm_mkt_cap_per_resource_oz_precious,
         mkt_cap_per_reserve_oz_precious: row.vm_mkt_cap_per_reserve_oz_precious,
      },
      production: {
         current_production_total_aueq_koz: row.p_current_production_total_aueq_koz,
         future_production_total_aueq_koz: row.p_future_production_total_aueq_koz,
         reserve_life_years: row.p_reserve_life_years,
         current_production_precious_aueq_koz: row.p_current_production_precious_aueq_koz,
         current_production_non_precious_aueq_koz: row.p_current_production_non_precious_aueq_koz,
      },
      costs: {
         aisc_future: row.c_aisc_future,
         construction_costs: row.c_construction_costs,
         tco_future: row.c_tco_future,
         aisc_last_quarter: row.c_aisc_last_quarter,
         aisc_last_year: row.c_aisc_last_year,
      }
    }));

    return { companies, totalCount };

  } catch (err: any) {
    console.error('Error processing paginated companies:', err);
    throw new Error(err.message || 'An unknown error occurred processing company data.');
  }
}