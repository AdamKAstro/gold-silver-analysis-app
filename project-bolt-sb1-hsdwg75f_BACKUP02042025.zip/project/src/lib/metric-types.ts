// src/lib/metric-types.ts
import type { ColumnTier } from './types';

export interface MetricConfig {
  key: string;
  label: string;
  description: string;
  unit: string;
  higherIsBetter: boolean;
  category: MetricCategory;
  tier: ColumnTier;
  path: string;
  format: 'number' | 'currency' | 'percent' | 'moz' | 'koz';
}

export type MetricCategory = 
  | 'company-overview'
  | 'financials'
  | 'capital-structure'
  | 'mineral-estimates'
  | 'valuation-metrics'
  | 'production'
  | 'costs';

export const metricCategories: Record<MetricCategory, string> = {
  'company-overview': 'Company Overview',
  'financials': 'Financial Metrics',
  'capital-structure': 'Capital Structure',
  'mineral-estimates': 'Mineral Estimates',
  'valuation-metrics': 'Valuation Metrics',
  'production': 'Production',
  'costs': 'Cost Metrics'
};

export const metrics: MetricConfig[] = [
  // Company Overview
  {
    key: 'percent_gold',
    label: 'Gold %',
    description: 'Percentage of production/resources as gold. Higher is better (↑) for gold-focused investors.',
    unit: '%',
    higherIsBetter: true,
    category: 'company-overview',
    tier: 'free',
    path: 'percent_gold',
    format: 'percent'
  },
  {
    key: 'percent_silver',
    label: 'Silver %',
    description: 'Percentage of production/resources as silver. Higher is better (↑) for silver-focused investors.',
    unit: '%',
    higherIsBetter: true,
    category: 'company-overview',
    tier: 'free',
    path: 'percent_silver',
    format: 'percent'
  },
  {
    key: 'share_price',
    label: 'Share Price',
    description: 'Current stock price in selected currency. Higher is better (↑) as a sign of market strength.',
    unit: '$',
    higherIsBetter: true,
    category: 'company-overview',
    tier: 'free',
    path: 'share_price',
    format: 'currency'
  },

  // Financial Metrics
  {
    key: 'cash_value',
    label: 'Cash',
    description: 'Cash reserves ($M). Higher is better (↑) for financial flexibility.',
    unit: '$M',
    higherIsBetter: true,
    category: 'financials',
    tier: 'free',
    path: 'financials.cash_value',
    format: 'currency'
  },
  {
    key: 'market_cap_value',
    label: 'Market Cap',
    description: 'Market capitalization ($M). Higher is better (↑) for company scale.',
    unit: '$M',
    higherIsBetter: true,
    category: 'financials',
    tier: 'free',
    path: 'financials.market_cap_value',
    format: 'currency'
  },
  {
    key: 'enterprise_value_value',
    label: 'Enterprise Value',
    description: 'Market cap + debt - cash ($M). Higher is better (↑) for total valuation.',
    unit: '$M',
    higherIsBetter: true,
    category: 'financials',
    tier: 'free',
    path: 'financials.enterprise_value_value',
    format: 'currency'
  },
  {
    key: 'net_financial_assets',
    label: 'Net Financial Assets',
    description: 'Assets minus liabilities ($M). Higher is better (↑) for net worth.',
    unit: '$M',
    higherIsBetter: true,
    category: 'financials',
    tier: 'free',
    path: 'financials.net_financial_assets',
    format: 'currency'
  },
  {
    key: 'free_cash_flow',
    label: 'Free Cash Flow',
    description: 'Cash after operating expenses ($M). Higher is better (↑) for profitability.',
    unit: '$M',
    higherIsBetter: true,
    category: 'financials',
    tier: 'premium',
    path: 'financials.free_cash_flow',
    format: 'currency'
  },
  {
    key: 'price_to_book',
    label: 'Price to Book',
    description: 'Share price vs. book value. Lower is better (↓) for undervaluation.',
    unit: 'ratio',
    higherIsBetter: false,
    category: 'financials',
    tier: 'medium',
    path: 'financials.price_to_book',
    format: 'number'
  },
  {
    key: 'price_to_sales',
    label: 'Price to Sales',
    description: 'Share price vs. revenue. Lower is better (↓) for value.',
    unit: 'ratio',
    higherIsBetter: false,
    category: 'financials',
    tier: 'medium',
    path: 'financials.price_to_sales',
    format: 'number'
  },
  {
    key: 'enterprise_to_revenue',
    label: 'EV/Revenue',
    description: 'EV vs. revenue. Lower is better (↓) for efficiency.',
    unit: 'ratio',
    higherIsBetter: false,
    category: 'financials',
    tier: 'medium',
    path: 'financials.enterprise_to_revenue',
    format: 'number'
  },
  {
    key: 'enterprise_to_ebitda',
    label: 'EV/EBITDA',
    description: 'EV vs. EBITDA. Lower is better (↓) for valuation.',
    unit: 'ratio',
    higherIsBetter: false,
    category: 'financials',
    tier: 'medium',
    path: 'financials.enterprise_to_ebitda',
    format: 'number'
  },
  {
    key: 'trailing_pe',
    label: 'Trailing P/E',
    description: 'Trailing price-to-earnings ratio. Lower is better (↓) for past value.',
    unit: 'ratio',
    higherIsBetter: false,
    category: 'financials',
    tier: 'medium',
    path: 'financials.trailing_pe',
    format: 'number'
  },
  {
    key: 'forward_pe',
    label: 'Forward P/E',
    description: 'Forward price-to-earnings ratio. Lower is better (↓) for future value.',
    unit: 'ratio',
    higherIsBetter: false,
    category: 'financials',
    tier: 'medium',
    path: 'financials.forward_pe',
    format: 'number'
  },
  {
    key: 'revenue_value',
    label: 'Revenue',
    description: 'Annual revenue ($M). Higher is better (↑) for income strength.',
    unit: '$M',
    higherIsBetter: true,
    category: 'financials',
    tier: 'medium',
    path: 'financials.revenue_value',
    format: 'currency'
  },
  {
    key: 'ebitda',
    label: 'EBITDA',
    description: 'Earnings before interest, taxes, etc. ($M). Higher is better (↑) for operating profit.',
    unit: '$M',
    higherIsBetter: true,
    category: 'financials',
    tier: 'premium',
    path: 'financials.ebitda',
    format: 'currency'
  },
  {
    key: 'net_income_value',
    label: 'Net Income',
    description: 'Net profit ($M). Higher is better (↑) for bottom-line success.',
    unit: '$M',
    higherIsBetter: true,
    category: 'financials',
    tier: 'medium',
    path: 'financials.net_income_value',
    format: 'currency'
  },
  {
    key: 'debt_value',
    label: 'Total Debt',
    description: 'Total debt ($M). Lower is better (↓) for reduced risk.',
    unit: '$M',
    higherIsBetter: false,
    category: 'financials',
    tier: 'medium',
    path: 'financials.debt_value',
    format: 'currency'
  },
  {
    key: 'shares_outstanding',
    label: 'Shares Outstanding',
    description: 'Issued shares (millions). Lower is better (↓) to minimize dilution.',
    unit: 'M',
    higherIsBetter: false,
    category: 'financials',
    tier: 'free',
    path: 'financials.shares_outstanding',
    format: 'number'
  },

  // Capital Structure
  {
    key: 'existing_shares',
    label: 'Existing Shares',
    description: 'Current shares outstanding (millions). Lower is better (↓) for ownership concentration.',
    unit: 'M',
    higherIsBetter: false,
    category: 'capital-structure',
    tier: 'medium',
    path: 'capital_structure.existing_shares',
    format: 'number'
  },
  {
    key: 'fully_diluted_shares',
    label: 'Fully Diluted Shares',
    description: 'Shares including options/warrants (millions). Lower is better (↓) for future dilution.',
    unit: 'M',
    higherIsBetter: false,
    category: 'capital-structure',
    tier: 'medium',
    path: 'capital_structure.fully_diluted_shares',
    format: 'number'
  },
  {
    key: 'in_the_money_options',
    label: 'In-the-money Options',
    description: 'Profitable exercisable options (millions). Lower is better (↓) for dilution risk.',
    unit: 'M',
    higherIsBetter: false,
    category: 'capital-structure',
    tier: 'premium',
    path: 'capital_structure.in_the_money_options',
    format: 'number'
  },
  {
    key: 'options_revenue',
    label: 'Options Revenue',
    description: 'Revenue from options ($M). Higher is better (↑) for extra income.',
    unit: '$M',
    higherIsBetter: true,
    category: 'capital-structure',
    tier: 'premium',
    path: 'capital_structure.options_revenue',
    format: 'currency'
  },

  // Mineral Estimates
  {
    key: 'reserves_total_aueq_moz',
    label: 'Total Reserves',
    description: 'Gold-equivalent reserves (million ounces). Higher is better (↑) for asset base.',
    unit: 'Moz',
    higherIsBetter: true,
    category: 'mineral-estimates',
    tier: 'medium',
    path: 'mineral_estimates.reserves_total_aueq_moz',
    format: 'moz'
  },
  {
    key: 'measured_indicated_total_aueq_moz',
    label: 'Total M&I',
    description: 'Measured/indicated resources (moz). Higher is better (↑) for potential.',
    unit: 'Moz',
    higherIsBetter: true,
    category: 'mineral-estimates',
    tier: 'medium',
    path: 'mineral_estimates.measured_indicated_total_aueq_moz',
    format: 'moz'
  },
  {
    key: 'resources_total_aueq_moz',
    label: 'Total Resources',
    description: 'Total resources (moz). Higher is better (↑) for scale.',
    unit: 'Moz',
    higherIsBetter: true,
    category: 'mineral-estimates',
    tier: 'medium',
    path: 'mineral_estimates.resources_total_aueq_moz',
    format: 'moz'
  },
  {
    key: 'potential_total_aueq_moz',
    label: 'Total Potential',
    description: 'Potential resources (moz). Higher is better (↑) for upside.',
    unit: 'Moz',
    higherIsBetter: true,
    category: 'mineral-estimates',
    tier: 'premium',
    path: 'mineral_estimates.potential_total_aueq_moz',
    format: 'moz'
  },
  {
    key: 'reserves_precious_aueq_moz',
    label: 'Precious Reserves',
    description: 'Precious metal reserves (moz). Higher is better (↑) for value.',
    unit: 'Moz',
    higherIsBetter: true,
    category: 'mineral-estimates',
    tier: 'medium',
    path: 'mineral_estimates.reserves_precious_aueq_moz',
    format: 'moz'
  },
  {
    key: 'measured_indicated_precious_aueq_moz',
    label: 'Precious M&I',
    description: 'Precious measured/indicated (moz). Higher is better (↑).',
    unit: 'Moz',
    higherIsBetter: true,
    category: 'mineral-estimates',
    tier: 'medium',
    path: 'mineral_estimates.measured_indicated_precious_aueq_moz',
    format: 'moz'
  },
  {
    key: 'resources_precious_aueq_moz',
    label: 'Precious Resources',
    description: 'Precious total resources (moz). Higher is better (↑).',
    unit: 'Moz',
    higherIsBetter: true,
    category: 'mineral-estimates',
    tier: 'medium',
    path: 'mineral_estimates.resources_precious_aueq_moz',
    format: 'moz'
  },

  // Valuation Metrics
  {
    key: 'ev_per_resource_oz_all',
    label: 'EV/Resource oz',
    description: 'EV per resource ounce ($/oz). Lower is better (↓) for undervaluation.',
    unit: '$/oz',
    higherIsBetter: false,
    category: 'valuation-metrics',
    tier: 'premium',
    path: 'valuation_metrics.ev_per_resource_oz_all',
    format: 'currency'
  },
  {
    key: 'ev_per_reserve_oz_all',
    label: 'EV/Reserve oz',
    description: 'EV per reserve ounce ($/oz). Lower is better (↓).',
    unit: '$/oz',
    higherIsBetter: false,
    category: 'valuation-metrics',
    tier: 'premium',
    path: 'valuation_metrics.ev_per_reserve_oz_all',
    format: 'currency'
  },
  {
    key: 'mkt_cap_per_resource_oz_all',
    label: 'MC/Resource oz',
    description: 'Market cap per resource ounce ($/oz). Lower is better (↓).',
    unit: '$/oz',
    higherIsBetter: false,
    category: 'valuation-metrics',
    tier: 'medium',
    path: 'valuation_metrics.mkt_cap_per_resource_oz_all',
    format: 'currency'
  },
  {
    key: 'mkt_cap_per_reserve_oz_all',
    label: 'MC/Reserve oz',
    description: 'Market cap per reserve ounce ($/oz). Lower is better (↓).',
    unit: '$/oz',
    higherIsBetter: false,
    category: 'valuation-metrics',
    tier: 'medium',
    path: 'valuation_metrics.mkt_cap_per_reserve_oz_all',
    format: 'currency'
  },
  {
    key: 'ev_per_resource_oz_precious',
    label: 'EV/Precious Resource oz',
    description: 'EV per precious resource ounce ($/oz). Lower is better (↓).',
    unit: '$/oz',
    higherIsBetter: false,
    category: 'valuation-metrics',
    tier: 'premium',
    path: 'valuation_metrics.ev_per_resource_oz_precious',
    format: 'currency'
  },
  {
    key: 'ev_per_reserve_oz_precious',
    label: 'EV/Precious Reserve oz',
    description: 'EV per precious reserve ounce ($/oz). Lower is better (↓).',
    unit: '$/oz',
    higherIsBetter: false,
    category: 'valuation-metrics',
    tier: 'premium',
    path: 'valuation_metrics.ev_per_reserve_oz_precious',
    format: 'currency'
  },
  {
    key: 'mkt_cap_per_resource_oz_precious',
    label: 'MC/Precious Resource oz',
    description: 'Market cap per precious resource ounce ($/oz). Lower is better (↓).',
    unit: '$/oz',
    higherIsBetter: false,
    category: 'valuation-metrics',
    tier: 'medium',
    path: 'valuation_metrics.mkt_cap_per_resource_oz_precious',
    format: 'currency'
  },
  {
    key: 'mkt_cap_per_reserve_oz_precious',
    label: 'MC/Precious Reserve oz',
    description: 'Market cap per precious reserve ounce ($/oz). Lower is better (↓).',
    unit: '$/oz',
    higherIsBetter: false,
    category: 'valuation-metrics',
    tier: 'medium',
    path: 'valuation_metrics.mkt_cap_per_reserve_oz_precious',
    format: 'currency'
  },

  // Production
  {
    key: 'current_production_total_aueq_koz',
    label: 'Current Production',
    description: 'Current production (thousand ounces). Higher is better (↑) for output.',
    unit: 'koz',
    higherIsBetter: true,
    category: 'production',
    tier: 'premium',
    path: 'production.current_production_total_aueq_koz',
    format: 'koz'
  },
  {
    key: 'future_production_total_aueq_koz',
    label: 'Future Production',
    description: 'Projected production (koz). Higher is better (↑) for growth.',
    unit: 'koz',
    higherIsBetter: true,
    category: 'production',
    tier: 'premium',
    path: 'production.future_production_total_aueq_koz',
    format: 'koz'
  },
  {
    key: 'reserve_life_years',
    label: 'Reserve Life',
    description: 'Years of reserves at current production. Higher is better (↑) for longevity.',
    unit: 'years',
    higherIsBetter: true,
    category: 'production',
    tier: 'premium',
    path: 'production.reserve_life_years',
    format: 'number'
  },
  {
    key: 'current_production_precious_aueq_koz',
    label: 'Precious Production',
    description: 'Precious metal production (koz). Higher is better (↑).',
    unit: 'koz',
    higherIsBetter: true,
    category: 'production',
    tier: 'premium',
    path: 'production.current_production_precious_aueq_koz',
    format: 'koz'
  },
  {
    key: 'current_production_non_precious_aueq_koz',
    label: 'Non-Precious Production',
    description: 'Non-precious production (koz). Higher is better (↑).',
    unit: 'koz',
    higherIsBetter: true,
    category: 'production',
    tier: 'premium',
    path: 'production.current_production_non_precious_aueq_koz',
    format: 'koz'
  },

  // Costs
  {
    key: 'aisc_future',
    label: 'Future AISC',
    description: 'Future all-in sustaining costs ($/oz). Lower is better (↓) for efficiency.',
    unit: '$/oz',
    higherIsBetter: false,
    category: 'costs',
    tier: 'premium',
    path: 'costs.aisc_future',
    format: 'currency'
  },
  {
    key: 'construction_costs',
    label: 'Construction Costs',
    description: 'Project construction costs ($M). Lower is better (↓) for capital efficiency.',
    unit: '$M',
    higherIsBetter: false,
    category: 'costs',
    tier: 'premium',
    path: 'costs.construction_costs',
    format: 'currency'
  },
  {
    key: 'tco_future',
    label: 'Future TCO',
    description: 'Future total cash costs ($/oz). Lower is better (↓) for profitability.',
    unit: '$/oz',
    higherIsBetter: false,
    category: 'costs',
    tier: 'premium',
    path: 'costs.tco_future',
    format: 'currency'
  },
  {
    key: 'aisc_last_quarter',
    label: 'Last Quarter AISC',
    description: 'AISC last quarter ($/oz). Lower is better (↓) for recent performance.',
    unit: '$/oz',
    higherIsBetter: false,
    category: 'costs',
    tier: 'premium',
    path: 'costs.aisc_last_quarter',
    format: 'currency'
  },
  {
    key: 'aisc_last_year',
    label: 'Last Year AISC',
    description: 'AISC last year ($/oz). Lower is better (↓) for historical efficiency.',
    unit: '$/oz',
    higherIsBetter: false,
    category: 'costs',
    tier: 'premium',
    path: 'costs.aisc_last_year',
    format: 'currency'
  }
];

export function getMetricsByCategory(category: MetricCategory): MetricConfig[] {
  return metrics.filter(metric => metric.category === category);
}

export function getMetricByKey(key: string): MetricConfig | undefined {
  return metrics.find(metric => metric.key === key);
}

export function getAccessibleMetrics(tier: ColumnTier): MetricConfig[] {
  const tierLevels = {
    free: 0,
    medium: 1,
    premium: 2
  };

  const userTierLevel = tierLevels[tier];
  return metrics.filter(metric => tierLevels[metric.tier] <= userTierLevel);
}