import React from 'react';
import { Crown, Star } from 'lucide-react';
import type { ColumnTier } from '../../lib/types';
import { cn } from '../../lib/utils';

interface TierBadgeProps {
  tier: ColumnTier;
  className?: string;
}

export function TierBadge({ tier, className }: TierBadgeProps) {
  return (
    <div
      className={cn(
        "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium",
        tier === 'premium' && "bg-gradient-to-r from-amber-200 to-yellow-400 text-amber-900",
        tier === 'medium' && "bg-gradient-to-r from-blue-200 to-blue-300 text-blue-900",
        tier === 'free' && "bg-gradient-to-r from-gray-200 to-gray-300 text-gray-900",
        className
      )}
    >
      {tier === 'premium' ? (
        <>
          <Crown className="h-3 w-3" />
          Premium
        </>
      ) : tier === 'medium' ? (
        <>
          <Star className="h-3 w-3" />
          Pro
        </>
      ) : (
        'Free'
      )}
    </div>
  );
}