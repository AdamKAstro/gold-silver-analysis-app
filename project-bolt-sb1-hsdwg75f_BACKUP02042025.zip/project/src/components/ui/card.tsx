import React from 'react';
import { cn } from '../../lib/utils';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'raised' | 'flat' | 'pressed';
  interactive?: boolean;
  hoverable?: boolean;
}

export function Card({
  className,
  variant = 'raised',
  interactive = false,
  hoverable = false,
  children,
  ...props
}: CardProps) {
  return (
    <div
      className={cn(
        'rounded-2xl p-6 transition-all duration-300',
        {
          // Raised variant (default neumorphic style)
          'bg-gradient-to-br from-white to-gray-50': variant === 'raised',
          'shadow-[20px_20px_60px_#bebebe,-20px_-20px_60px_#ffffff]': variant === 'raised',
          
          // Flat variant (subtle elevation)
          'bg-white shadow-sm': variant === 'flat',
          
          // Pressed variant (inset neumorphic style)
          'bg-gray-50': variant === 'pressed',
          'shadow-[inset_20px_20px_60px_#bebebe,inset_-20px_-20px_60px_#ffffff]': variant === 'pressed',
          
          // Interactive states
          'cursor-pointer transform transition-transform duration-200': interactive,
          'hover:scale-[1.02] hover:shadow-2xl': interactive && hoverable,
          'active:scale-[0.98]': interactive,
        },
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}

export function CardHeader({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn('mb-4 space-y-1.5', className)}
      {...props}
    >
      {children}
    </div>
  );
}

export function CardTitle({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLHeadingElement>) {
  return (
    <h3
      className={cn(
        'text-2xl font-semibold leading-none tracking-tight text-gray-900',
        className
      )}
      {...props}
    >
      {children}
    </h3>
  );
}

export function CardDescription({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLParagraphElement>) {
  return (
    <p
      className={cn('text-sm text-gray-500', className)}
      {...props}
    >
      {children}
    </p>
  );
}

export function CardContent({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn('', className)} {...props}>
      {children}
    </div>
  );
}

export function CardFooter({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn('mt-4 flex items-center', className)}
      {...props}
    >
      {children}
    </div>
  );
}