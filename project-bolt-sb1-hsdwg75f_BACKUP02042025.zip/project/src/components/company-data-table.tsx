import React from 'react';
import * as Tooltip from '@radix-ui/react-tooltip';
import { ArrowUpDown, ArrowUp, ArrowDown, HelpCircle, Lock, ChevronLeft, ChevronRight } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import type { Company, SortState, ColumnTier, ColumnAccess, ColumnDef, ColumnGroup } from '../lib/types';
import { TierBadge } from './ui/tier-badge';
import { cn, getNestedValue, formatNumber, formatCurrency, formatPercent } from '../lib/utils';
import { StatusBadge } from './status-badge';
import { CompanyNameBadge } from './company-name-badge';
import { MineralsList } from './mineral-badge';

interface CompanyDataTableProps {
  companies: Company[];
  onSort: (key: string, direction: 'asc' | 'desc') => void;
  currentSort: SortState;
  selectedStatuses: string[];
  onStatusChange: (statuses: string[]) => void;
  currentTier: ColumnTier;
  page: number;
  pageSize: number;
  totalCount: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
}

const columnGroups: ColumnGroup[] = [
  {
    title: 'Company Profile',
    description: 'Core company information and classification',
    className: 'bg-navy-400/10',
    columns: [
      { 
        key: 'company_name', 
        label: 'Company', 
        sortable: true,
        sortKey: 'company_name',
        description: 'Company name and trading symbol',
        access: { tier: 'free', description: 'Basic company identification' }
      },
      { 
        key: 'status', 
        label: 'Status', 
        sortable: true,
        sortKey: 'status',
        description: 'Company operational status',
        preferredValues: 'Producer, Developer, or Explorer',
        access: { tier: 'free', description: 'Company classification' }
      },
      { 
        key: 'minerals_of_interest', 
        label: 'Minerals', 
        sortable: true,
        sortKey: 'minerals_of_interest',
        description: 'Primary minerals being mined or explored',
        access: { tier: 'free', description: 'Resource focus' }
      },
      { 
        key: 'percent_gold', 
        label: 'Gold %', 
        sortable: true,
        sortKey: 'percent_gold',
        format: 'percent',
        description: 'Percentage of revenue/resources from gold',
        preferredValues: 'Higher percentages indicate greater focus on gold',
        access: { tier: 'free', description: 'Resource focus metrics' }
      },
      { 
        key: 'percent_silver', 
        label: 'Silver %', 
        sortable: true,
        sortKey: 'percent_silver',
        format: 'percent',
        description: 'Percentage of revenue/resources from silver',
        preferredValues: 'Higher percentages indicate greater focus on silver',
        access: { tier: 'free', description: 'Resource focus metrics' }
      }
    ]
  },
  {
    title: 'Financial Health',
    description: 'Key financial indicators and metrics',
    className: 'bg-navy-400/10',
    columns: [
      { 
        key: 'financials.market_cap_value', 
        label: 'Market Cap', 
        sortable: true,
        sortKey: 'f_market_cap_value',
        format: 'compact',
        description: 'Total market value of outstanding shares',
        access: { tier: 'free', description: 'Market valuation' }
      },
      { 
        key: 'financials.enterprise_value_value', 
        label: 'Enterprise Value', 
        sortable: true,
        sortKey: 'f_enterprise_value_value',
        format: 'compact',
        description: 'Total company value (Market Cap + Debt - Cash)',
        access: { tier: 'free', description: 'Advanced valuation metrics' }
      },
      { 
        key: 'financials.cash_value', 
        label: 'Cash', 
        sortable: true,
        sortKey: 'f_cash_value',
        format: 'compact',
        description: 'Available cash and highly liquid assets',
        access: { tier: 'free', description: 'Basic financial metrics' }
      },
      { 
        key: 'financials.debt_value', 
        label: 'Total Debt', 
        sortable: true,
        sortKey: 'f_debt_value',
        format: 'compact',
        description: 'Total debt obligations',
        access: { tier: 'medium', description: 'Debt metrics' }
      },
      { 
        key: 'financials.net_financial_assets', 
        label: 'Net Financial Assets', 
        sortable: true,
        sortKey: 'f_net_financial_assets',
        format: 'compact',
        description: 'Financial assets minus liabilities',
        access: { tier: 'free', description: 'Balance sheet strength' }
      },
      { 
        key: 'financials.free_cash_flow', 
        label: 'Free Cash Flow', 
        sortable: true,
        sortKey: 'f_free_cash_flow',
        format: 'compact',
        description: 'Operating cash flow minus capital expenditures',
        access: { tier: 'premium', description: 'Cash flow analysis' }
      }
    ]
  },
  {
    title: 'Operating Metrics',
    description: 'Revenue and profitability metrics',
    className: 'bg-navy-400/10',
    columns: [
      { 
        key: 'financials.revenue_value', 
        label: 'Revenue', 
        sortable: true,
        sortKey: 'f_revenue_value',
        format: 'compact',
        description: 'Total income from metal sales',
        access: { tier: 'medium', description: 'Revenue metrics' }
      },
      { 
        key: 'financials.ebitda', 
        label: 'EBITDA', 
        sortable: true,
        sortKey: 'f_ebitda',
        format: 'compact',
        description: 'Earnings Before Interest, Taxes, Depreciation, and Amortization',
        access: { tier: 'premium', description: 'Profitability metrics' }
      },
      { 
        key: 'financials.net_income_value', 
        label: 'Net Income', 
        sortable: true,
        sortKey: 'f_net_income_value',
        format: 'compact',
        description: 'Bottom-line profit after all expenses',
        access: { tier: 'medium', description: 'Profitability metrics' }
      }
    ]
  },
  {
    title: 'Valuation Ratios',
    description: 'Key valuation metrics and multiples',
    className: 'bg-navy-400/10',
    columns: [
      { 
        key: 'valuation_metrics.ev_per_resource_oz_all', 
        label: 'EV/Resource oz', 
        sortable: true,
        sortKey: 'vm_ev_per_resource_oz_all',
        format: 'decimal',
        description: 'Enterprise Value per total resource ounce',
        access: { tier: 'premium', description: 'Advanced valuation metrics' }
      },
      { 
        key: 'valuation_metrics.ev_per_reserve_oz_all', 
        label: 'EV/Reserve oz', 
        sortable: true,
        sortKey: 'vm_ev_per_reserve_oz_all',
        format: 'decimal',
        description: 'Enterprise Value per reserve ounce',
        access: { tier: 'premium', description: 'Advanced valuation metrics' }
      },
      { 
        key: 'valuation_metrics.mkt_cap_per_resource_oz_all', 
        label: 'MC/Resource oz', 
        sortable: true,
        sortKey: 'vm_mkt_cap_per_resource_oz_all',
        format: 'decimal',
        description: 'Market Cap per total resource ounce',
        access: { tier: 'medium', description: 'Resource valuation metrics' }
      },
      { 
        key: 'valuation_metrics.mkt_cap_per_reserve_oz_all', 
        label: 'MC/Reserve oz', 
        sortable: true,
        sortKey: 'vm_mkt_cap_per_reserve_oz_all',
        format: 'decimal',
        description: 'Market Cap per reserve ounce',
        access: { tier: 'medium', description: 'Resource valuation metrics' }
      }
    ]
  },
  {
    title: 'Resources & Grade',
    description: 'Mineral resource estimates and grades',
    className: 'bg-navy-400/10',
    columns: [
      { 
        key: 'mineral_estimates.reserves_total_aueq_moz', 
        label: 'Total Reserves', 
        sortable: true,
        sortKey: 'me_reserves_total_aueq_moz',
        format: 'moz',
        description: 'Total Proven & Probable gold equivalent ounces',
        access: { tier: 'medium', description: 'Resource estimates' }
      },
      { 
        key: 'mineral_estimates.measured_indicated_total_aueq_moz', 
        label: 'Total M&I', 
        sortable: true,
        sortKey: 'me_measured_indicated_total_aueq_moz',
        format: 'moz',
        description: 'Total Measured & Indicated gold equivalent ounces',
        access: { tier: 'medium', description: 'Resource estimates' }
      },
      { 
        key: 'mineral_estimates.resources_total_aueq_moz', 
        label: 'Total Resources', 
        sortable: true,
        sortKey: 'me_resources_total_aueq_moz',
        format: 'moz',
        description: 'Total Measured, Indicated, and Inferred gold equivalent ounces',
        access: { tier: 'medium', description: 'Resource estimates' }
      }
    ]
  },
  {
    title: 'Production & Costs',
    description: 'Production metrics and cost structure',
    className: 'bg-navy-400/10',
    columns: [
      { 
        key: 'production.current_production_total_aueq_koz', 
        label: 'Current Production', 
        sortable: true,
        sortKey: 'p_current_production_total_aueq_koz',
        format: 'koz',
        description: 'Current annual gold equivalent production',
        access: { tier: 'premium', description: 'Production metrics' }
      },
      { 
        key: 'production.future_production_total_aueq_koz', 
        label: 'Future Production', 
        sortable: true,
        sortKey: 'p_future_production_total_aueq_koz',
        format: 'koz',
        description: 'Estimated future annual gold equivalent production',
        access: { tier: 'premium', description: 'Production forecasts' }
      },
      { 
        key: 'costs.aisc_future', 
        label: 'AISC (Future)', 
        sortable: true,
        sortKey: 'c_aisc_future',
        format: 'currency',
        description: 'Projected All-In Sustaining Cost per ounce',
        access: { tier: 'premium', description: 'Cost metrics' }
      }
    ]
  }
];

const pageSizeOptions = [10, 25, 50, 100];

function Pagination({
  page,
  pageSize,
  totalCount,
  onPageChange,
  onPageSizeChange,
}: {
  page: number;
  pageSize: number;
  totalCount: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
}) {
  const totalPages = Math.ceil(totalCount / pageSize);
  const startItem = (page - 1) * pageSize + 1;
  const endItem = Math.min(page * pageSize, totalCount);

  return (
    <div className="pagination-container">
      <div className="flex items-center gap-4">
        <div className="pagination-info text-xs">
          Showing <span className="font-medium text-surface-white">{startItem}</span> to{' '}
          <span className="font-medium text-surface-white">{endItem}</span> of{' '}
          <span className="font-medium text-surface-white">{totalCount}</span> companies
        </div>
        <select
          value={pageSize}
          onChange={(e) => onPageSizeChange(Number(e.target.value))}
          className="page-size-select text-xs"
        >
          {pageSizeOptions.map((size) => (
            <option key={size} value={size}>
              {size} per page
            </option>
          ))}
        </select>
      </div>
      <div className="pagination-controls">
        <button
          onClick={() => onPageChange(page - 1)}
          disabled={page === 1}
          className="page-button"
        >
          <ChevronLeft className="h-4 w-4" />
        </button>
        <span className="text-xs text-surface-white/70">
          Page {page} of {totalPages}
        </span>
        <button
          onClick={() => onPageChange(page + 1)}
          disabled={page === totalPages}
          className="page-button"
        >
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

function renderCell(column: ColumnDef, value: any, company: Company): React.ReactNode {
  if (column.key === 'company_name') {
    return (
      <CompanyNameBadge
        name={company.company_name}
        code={company.tsx_code}
        headquarters={company.headquarters}
        description={company.description}
      />
    );
  }
  
  if (column.key === 'status') {
    return <StatusBadge status={value} />;
  }
  
  if (column.key === 'minerals_of_interest') {
    return <MineralsList minerals={value} />;
  }

  if (column.format) {
    return formatValue(value, column.format);
  }

  return value || '-';
}

function formatValue(value: any, format?: string): string {
  if (value === null || value === undefined) return '-';

  switch (format) {
    case 'currency':
      return formatCurrency(value);
    case 'percent':
      return formatPercent(value);
    case 'number':
      return formatNumber(value, { decimals: 0 });
    case 'decimal':
      return formatNumber(value, { decimals: 2 });
    case 'compact':
      return formatNumber(value, { compact: true });
    case 'moz':
      return formatNumber(value, { decimals: 2, suffix: ' Moz' });
    case 'koz':
      return formatNumber(value, { decimals: 0, suffix: ' koz' });
    default:
      return String(value);
  }
}

export function CompanyDataTable({ 
  companies, 
  onSort, 
  currentSort,
  selectedStatuses,
  onStatusChange,
  currentTier,
  page,
  pageSize,
  totalCount,
  onPageChange,
  onPageSizeChange
}: CompanyDataTableProps) {
  const handleSort = (key: string) => {
    if (!key) return;
    const direction = currentSort.key === key && currentSort.direction === 'asc' ? 'desc' : 'asc';
    onSort(key, direction);
  };

  const getSortIcon = (key: string) => {
    if (currentSort.key !== key) return <ArrowUpDown className="h-3 w-3" />;
    return currentSort.direction === 'asc' ? 
      <ArrowUp className="h-3 w-3" /> : 
      <ArrowDown className="h-3 w-3" />;
  };

  const getRowBackground = (status: string) => {
    switch (status.toLowerCase()) {
      case 'producer':
        return 'hover:bg-emerald-500/5 bg-emerald-500/[0.02]';
      case 'developer':
        return 'hover:bg-blue-500/5 bg-blue-500/[0.02]';
      case 'explorer':
        return 'hover:bg-purple-500/5 bg-purple-500/[0.02]';
      default:
        return 'hover:bg-navy-400/20';
    }
  };

  const isColumnAccessible = (column: ColumnDef): boolean => {
    if (!column.access) return true;
    
    const tierLevels = {
      free: 0,
      medium: 1,
      premium: 2
    };
    
    return tierLevels[currentTier] >= tierLevels[column.access.tier];
  };

  return (
    <Tooltip.Provider>
      <div className="space-y-6">
        <div className="table-container">
          <table className="table-bg w-full">
            <colgroup>
              {columnGroups.map(group => 
                group.columns.map(() => <col key={Math.random()} />)
              )}
            </colgroup>
            <thead className="table-header">
              <tr>
                {columnGroups.map((group, groupIndex) => (
                  <th
                    key={`${group.title}-${groupIndex}`}
                    colSpan={group.columns.length}
                    className={cn(
                      "table-cell text-center font-bold group-header text-xs",
                      group.className,
                      groupIndex === 0 && "sticky left-0 z-20"
                    )}
                  >
                    <Tooltip.Root>
                      <Tooltip.Trigger asChild>
                        <div className="flex items-center justify-center gap-1 cursor-help">
                          {group.title}
                          <HelpCircle className="h-3 w-3 text-surface-white/60" />
                        </div>
                      </Tooltip.Trigger>
                      <Tooltip.Portal>
                        <Tooltip.Content
                          className="bg-navy-400 p-3 rounded-lg shadow-lg border border-navy-300/20 text-surface-white text-xs"
                          sideOffset={5}
                        >
                          {group.description}
                          <Tooltip.Arrow className="fill-navy-400" />
                        </Tooltip.Content>
                      </Tooltip.Portal>
                    </Tooltip.Root>
                  </th>
                ))}
              </tr>
              <tr>
                {columnGroups.flatMap((group, groupIndex) => 
                  group.columns.map((column, columnIndex) => {
                    const isFirstColumn = groupIndex === 0 && columnIndex === 0;
                    const isAccessible = isColumnAccessible(column);
                    
                    return (
                      <th
                        key={`${column.key}-${groupIndex}-${columnIndex}`}
                        className={cn(
                          "table-cell font-semibold relative group text-xs",
                          column.sortable && isAccessible && "cursor-pointer hover:bg-navy-400/20",
                          isFirstColumn && "sticky-col-1",
                          !isFirstColumn && (column.format ? "col-numeric" : "col-standard"),
                          group.className
                        )}
                        onClick={() => isAccessible && column.sortable && column.sortKey && handleSort(column.sortKey)}
                      >
                        <Tooltip.Root>
                          <Tooltip.Trigger asChild>
                            <div className="flex items-center gap-1">
                              <span className="whitespace-nowrap">{column.label}</span>
                              {column.sortable && isAccessible && (
                                <span className="ml-1">{getSortIcon(column.sortKey || column.key)}</span>
                              )}
                              {!isAccessible && (
                                <Lock className="h-3 w-3 text-surface-white/40" />
                              )}
                              {(column.description || column.preferredValues) && (
                                <HelpCircle className="h-3 w-3 text-surface-white/40" />
                              )}
                            </div>
                          </Tooltip.Trigger>
                          <Tooltip.Portal>
                            <Tooltip.Content
                              className="bg-navy-400 p-3 rounded-lg shadow-lg border border-navy-300/20 text-surface-white text-xs max-w-xs"
                              sideOffset={5}
                            >
                              <div className="space-y-2">
                                {!isAccessible && column.access && (
                                  <div className="mb-2 flex items-center gap-2">
                                    <TierBadge tier={column.access.tier} />
                                    <span className="text-xs text-surface-white/70">feature</span>
                                  </div>
                                )}
                                {column.description && (
                                  <p className="text-xs">{column.description}</p>
                                )}
                                {column.preferredValues && (
                                  <p className="text-xs text-surface-white/70">
                                    <strong>Preferred Values:</strong> {column.preferredValues}
                                  </p>
                                )}
                              </div>
                              <Tooltip.Arrow className="fill-navy-400" />
                            </Tooltip.Content>
                          </Tooltip.Portal>
                        </Tooltip.Root>
                      </th>
                    );
                  })
                )}
              </tr>
            </thead>
            <tbody>
              <AnimatePresence>
                {companies.map((company) => (
                  <motion.tr
                    key={company.company_id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.2 }}
                    className={cn(
                      "transition-colors duration-150",
                      getRowBackground(company.status)
                    )}
                  >
                    {columnGroups.flatMap((group, groupIndex) =>
                      group.columns.map((column, columnIndex) => {
                        const isFirstColumn = groupIndex === 0 && columnIndex === 0;
                        const isAccessible = isColumnAccessible(column);
                        const value = getNestedValue(company, column.key);

                        return (
                          <motion.td
                            key={`${column.key}-${groupIndex}-${columnIndex}`}
                            className={cn(
                              "table-cell relative text-xs",
                              !isAccessible && "opacity-50",
                              isFirstColumn && "sticky-col-1",
                              !isFirstColumn && (column.format ? "col-numeric" : "col-standard"),
                              group.className
                            )}
                            layout
                          >
                            {!isAccessible && (
                              <motion.div
                                className="locked-overlay"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                              >
                                <Lock className="h-3 w-3 text-surface-white/40" />
                              </motion.div>
                            )}
                            <div className={!isAccessible ? "select-none" : ""}>
                              {renderCell(column, value, company)}
                            </div>
                          </motion.td>
                        );
                      })
                    )}
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
        </div>

        <Pagination
          page={page}
          pageSize={pageSize}
          totalCount={totalCount}
          onPageChange={onPageChange}
          onPageSizeChange={onPageSizeChange}
        />
      </div>
    </Tooltip.Provider>
  );
}