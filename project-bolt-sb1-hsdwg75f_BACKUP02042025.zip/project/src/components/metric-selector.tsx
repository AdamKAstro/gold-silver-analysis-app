import React, { useState } from 'react';
import * as Select from '@radix-ui/react-select';
import * as Dialog from '@radix-ui/react-dialog';
import { ArrowDown, ArrowUp, Check, ChevronDown, ChevronUp, Lock, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '../lib/utils';
import type { MetricConfig, MetricCategory } from '../lib/types';
import { metricCategories, getMetricsByCategory, metrics } from '../lib/metric-types';
import { TierBadge } from './ui/tier-badge';

interface MetricSelectorProps {
  label: string;
  selectedMetric: string;
  onMetricChange: (metric: string) => void;
  metrics: MetricConfig[];
  currentTier: 'free' | 'medium' | 'premium';
  className?: string;
}

export function MetricSelector({
  label,
  selectedMetric,
  onMetricChange,
  metrics: availableMetrics,
  currentTier,
  className
}: MetricSelectorProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  // Get all metrics, not just accessible ones
  const allMetrics = metrics;
  const selectedMetricConfig = allMetrics.find(m => m.key === selectedMetric);

  const filteredMetrics = allMetrics.filter(metric => {
    const searchLower = searchTerm.toLowerCase();
    return (
      metric.label.toLowerCase().includes(searchLower) ||
      metric.description.toLowerCase().includes(searchLower) ||
      metric.category.toLowerCase().includes(searchLower)
    );
  });

  const groupedMetrics = Object.entries(metricCategories).map(([category, label]) => ({
    category: category as MetricCategory,
    label,
    metrics: filteredMetrics.filter(m => m.category === category)
  })).filter(group => group.metrics.length > 0);

  const isMetricAccessible = (metric: MetricConfig): boolean => {
    const tierLevels = {
      free: 0,
      medium: 1,
      premium: 2
    };
    return tierLevels[currentTier] >= tierLevels[metric.tier];
  };

  const renderMetricOption = (metric: MetricConfig) => {
    const isAccessible = isMetricAccessible(metric);
    const isSelected = metric.key === selectedMetric;

    return (
      <Select.Item
        key={metric.key}
        value={metric.key}
        disabled={!isAccessible}
        className={cn(
          'relative flex items-center px-8 py-2 text-sm outline-none',
          'data-[highlighted]:bg-navy-400/20',
          'data-[disabled]:opacity-50 data-[disabled]:cursor-not-allowed',
          isSelected ? 'bg-navy-400/40' : 'hover:bg-navy-400/20',
          'cursor-pointer transition-colors duration-150',
          !isAccessible && 'line-through'
        )}
      >
        <div className="flex items-center justify-between w-full gap-2">
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="font-medium">{metric.label}</span>
              {metric.higherIsBetter ? (
                <ArrowUp className="h-3 w-3 text-emerald-400" />
              ) : (
                <ArrowDown className="h-3 w-3 text-red-400" />
              )}
              {!isAccessible && <Lock className="h-3 w-3 text-surface-white/40" />}
            </div>
            <span className="text-xs text-surface-white/70">{metric.description}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-surface-white/50">{metric.unit}</span>
            {!isAccessible && <TierBadge tier={metric.tier} className="scale-75" />}
          </div>
        </div>
        <Select.ItemIndicator className="absolute left-2 flex items-center justify-center">
          <Check className="h-4 w-4" />
        </Select.ItemIndicator>
      </Select.Item>
    );
  };

  return (
    <Select.Root
      value={selectedMetric}
      onValueChange={onMetricChange}
      open={isOpen}
      onOpenChange={setIsOpen}
    >
      <div className={cn('flex flex-col gap-1.5', className)}>
        <Select.Trigger
          className={cn(
            'flex items-center justify-between',
            'px-3 py-2 text-sm',
            'bg-navy-400/20 border border-navy-300/20 rounded-md',
            'hover:bg-navy-400/30 focus:outline-none focus:ring-2 focus:ring-accent-teal',
            'transition-colors duration-150'
          )}
        >
          <div className="flex flex-col items-start">
            <span className="text-xs text-surface-white/70">{label}</span>
            <div className="flex items-center gap-2">
              <span className="font-medium">
                {selectedMetricConfig?.label || 'Select metric'}
              </span>
              {selectedMetricConfig && (
                selectedMetricConfig.higherIsBetter ? (
                  <ArrowUp className="h-3 w-3 text-emerald-400" />
                ) : (
                  <ArrowDown className="h-3 w-3 text-red-400" />
                )
              )}
            </div>
          </div>
          <Select.Icon>
            <ChevronDown className="h-4 w-4 text-surface-white/70" />
          </Select.Icon>
        </Select.Trigger>

        <AnimatePresence>
          {isOpen && (
            <Select.Portal forceMount>
              <Select.Content
                position="popper"
                className="z-50"
                asChild
              >
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className={cn(
                    'relative w-[400px] max-h-[400px]',
                    'bg-navy-500 border border-navy-300/20 rounded-lg shadow-xl'
                  )}
                >
                  <div className="p-2 border-b border-navy-300/20">
                    <div className="relative">
                      <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-surface-white/40" />
                      <input
                        type="text"
                        placeholder="Search metrics..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className={cn(
                          'w-full pl-8 pr-3 py-1.5',
                          'bg-navy-400/20 border border-navy-300/20 rounded-md',
                          'text-sm text-surface-white placeholder-surface-white/50',
                          'focus:outline-none focus:ring-2 focus:ring-accent-teal'
                        )}
                      />
                    </div>
                  </div>

                  <Select.Viewport className="p-1">
                    {groupedMetrics.map(group => (
                      <div key={group.category} className="py-1">
                        <div className="px-2 py-1.5 text-xs font-semibold text-surface-white/70">
                          {group.label}
                        </div>
                        {group.metrics.map(renderMetricOption)}
                      </div>
                    ))}

                    {groupedMetrics.length === 0 && (
                      <div className="px-2 py-4 text-center text-sm text-surface-white/50">
                        No metrics found
                      </div>
                    )}
                  </Select.Viewport>

                  <Select.ScrollUpButton className="flex items-center justify-center h-6 bg-navy-500 cursor-default">
                    <ChevronUp className="h-4 w-4" />
                  </Select.ScrollUpButton>
                  <Select.ScrollDownButton className="flex items-center justify-center h-6 bg-navy-500 cursor-default">
                    <ChevronDown className="h-4 w-4" />
                  </Select.ScrollDownButton>
                </motion.div>
              </Select.Content>
            </Select.Portal>
          )}
        </AnimatePresence>
      </div>
    </Select.Root>
  );
}