import React from 'react';
import { Crown, Star } from 'lucide-react';
import type { ColumnTier } from '../lib/types';

interface TierSelectorProps {
  currentTier: ColumnTier;
  onTierChange: (tier: ColumnTier) => void;
}

export function TierSelector({ currentTier, onTierChange }: TierSelectorProps) {
  return (
    <div className="tier-switch neumorph-inset">
      <button
        className={`tier-option hover-lift flex items-center gap-1 ${currentTier === 'free' ? 'active' : ''}`}
        onClick={() => onTierChange('free')}
      >
        Free
      </button>
      <button
        className={`tier-option hover-lift flex items-center gap-1 ${currentTier === 'medium' ? 'active' : ''}`}
        onClick={() => onTierChange('medium')}
      >
        <Star className="h-4 w-4" />
        Pro
      </button>
      <button
        className={`tier-option hover-lift flex items-center gap-1 ${currentTier === 'premium' ? 'active' : ''}`}
        onClick={() => onTierChange('premium')}
      >
        <Crown className="h-4 w-4" />
        Premium
      </button>
    </div>
  );
}