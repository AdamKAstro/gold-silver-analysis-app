import React from 'react';
import { CircleDot, Hammer, Pickaxe } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '../lib/utils';

interface StatusBadgeProps {
  status: string;
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const getStatusConfig = (status: string) => {
    switch (status.toLowerCase()) {
      case 'producer':
        return {
          icon: CircleDot,
          baseColor: 'from-emerald-500/90 to-emerald-600/90',
          ringColor: 'ring-emerald-500/40',
          textColor: 'text-emerald-100',
          iconColor: 'text-emerald-200',
          shadowColor: 'shadow-emerald-500/30',
          bgColor: 'bg-emerald-500/20',
        };
      case 'developer':
        return {
          icon: Hammer,
          baseColor: 'from-blue-500/90 to-blue-600/90',
          ringColor: 'ring-blue-500/40',
          textColor: 'text-blue-100',
          iconColor: 'text-blue-200',
          shadowColor: 'shadow-blue-500/30',
          bgColor: 'bg-blue-500/20',
        };
      case 'explorer':
        return {
          icon: Pickaxe,
          baseColor: 'from-purple-500/90 to-purple-600/90',
          ringColor: 'ring-purple-500/40',
          textColor: 'text-purple-100',
          iconColor: 'text-purple-200',
          shadowColor: 'shadow-purple-500/30',
          bgColor: 'bg-purple-500/20',
        };
      default:
        return {
          icon: CircleDot,
          baseColor: 'from-navy-300 to-navy-400',
          ringColor: 'ring-navy-400/30',
          textColor: 'text-surface-white',
          iconColor: 'text-surface-light',
          shadowColor: '',
          bgColor: 'bg-navy-400/10',
        };
    }
  };

  const config = getStatusConfig(status);
  const Icon = config.icon;

  return (
    <motion.div
      initial={{ scale: 0.95, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className={cn(
        'relative inline-flex items-center gap-2 px-3 py-1.5 rounded-full',
        'bg-gradient-to-r shadow-md transition-all duration-300',
        'ring-2 ring-offset-1 ring-offset-navy-500',
        config.baseColor,
        config.ringColor,
        config.shadowColor,
        'transform hover:-translate-y-0.5',
        className
      )}
    >
      {/* Glow effect */}
      <div className={cn(
        'absolute inset-0 rounded-full blur opacity-50 transition-opacity duration-300',
        'bg-gradient-to-r',
        config.baseColor,
        'group-hover:opacity-75'
      )} />
      
      {/* Content */}
      <div className="relative z-10 flex items-center gap-2">
        <Icon className={cn('h-4 w-4', config.iconColor)} />
        <span className={cn('text-sm font-semibold capitalize', config.textColor)}>
          {status.toLowerCase()}
        </span>
      </div>
    </motion.div>
  );
}