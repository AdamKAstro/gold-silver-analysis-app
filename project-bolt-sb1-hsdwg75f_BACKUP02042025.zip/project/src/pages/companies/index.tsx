import React, { useState, useEffect, useCallback, useMemo } from "react";
import { Filter, Home, LineChart } from "lucide-react";
import { useSearchParams, Link } from 'react-router-dom';
import { TierSelector } from '../../components/tier-selector';
import { CompanyDataTable } from "../../components/company-data-table";
import { CurrencySelector } from "../../components/currency-selector";
import { LoadingIndicator } from "../../components/ui/loading-indicator";
import { Button } from "../../components/ui/button";
import { getPaginatedCompanies } from "../../lib/supabase";
import { useSubscription } from "../../contexts/subscription-context";
import { useCurrency } from "../../contexts/currency-context";
import { cn } from "../../lib/utils";
import type { Company, FilterState, SortState, ColumnTier } from "../../lib/types";

const initialFilterState: FilterState = {
  searchTerm: '',
  status: null,
  marketCapRange: [null, null],
};

const initialSortState: SortState = { key: 'company_name', direction: 'asc' };

function debounce<F extends (...args: any[]) => any>(func: F, waitFor: number) {
  let timeout: NodeJS.Timeout | null = null;

  const debounced = (...args: Parameters<F>) => {
    if (timeout !== null) {
      clearTimeout(timeout);
      timeout = null;
    }
    timeout = setTimeout(() => func(...args), waitFor);
  };

  return debounced;
}

export function CompaniesPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { getEffectiveTier, setTier } = useSubscription();
  const { currency } = useCurrency();

  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isTableVisible, setIsTableVisible] = useState(false);
  const [totalCount, setTotalCount] = useState(0);
  const [page, setPage] = useState(() => Number(searchParams.get('page')) || 1);
  const [pageSize, setPageSize] = useState(() => Number(searchParams.get('pageSize')) || 25);
  const [showFilters, setShowFilters] = useState(false);

  const [sortState, setSortState] = useState<SortState>(() => ({
    key: searchParams.get('sortKey') || initialSortState.key,
    direction: (searchParams.get('sortDir') as 'asc' | 'desc') || initialSortState.direction,
  }));

  const [filters, setFilters] = useState<FilterState>(() => {
    const initialFilters = { ...initialFilterState };
    initialFilters.searchTerm = searchParams.get('search') || '';
    const statusParam = searchParams.get('status');
    initialFilters.status = statusParam ? statusParam.split(',') : ['producer', 'developer', 'explorer'];
    return initialFilters;
  });

  const [localSearchTerm, setLocalSearchTerm] = useState<string>(filters.searchTerm);
  const [selectedStatuses, setSelectedStatuses] = useState<string[]>(
    filters.status || ['producer', 'developer', 'explorer']
  );

  const effectiveTier = getEffectiveTier() as ColumnTier;

  const updateUrlParams = useCallback((newParams: Record<string, string | number | null>) => {
    const current = new URLSearchParams(searchParams);
    Object.entries(newParams).forEach(([key, value]) => {
      if (value === null || value === undefined || value === '') {
        current.delete(key);
      } else {
        current.set(key, String(value));
      }
    });
    setSearchParams(current);
  }, [searchParams, setSearchParams]);

  useEffect(() => {
    setLoading(true);
    setError(null);

    const timer = setTimeout(() => {
      getPaginatedCompanies(page, pageSize, sortState, {
        ...filters,
        status: selectedStatuses
      }, currency)
        .then(result => {
          setCompanies(result.companies);
          setTotalCount(result.totalCount);
          setIsTableVisible(true);
        })
        .catch(err => {
          console.error("Failed to fetch companies:", err);
          setError(err.message || "An error occurred fetching data.");
          setCompanies([]);
          setIsTableVisible(false);
        })
        .finally(() => {
          setLoading(false);
        });
    }, 150);

    return () => clearTimeout(timer);
  }, [page, pageSize, sortState, filters, selectedStatuses, currency]);

  useEffect(() => {
    updateUrlParams({
      page,
      pageSize,
      sortKey: sortState.key,
      sortDir: sortState.direction,
      search: filters.searchTerm || null,
      status: selectedStatuses.join(','),
    });
  }, [page, pageSize, sortState, filters, selectedStatuses, updateUrlParams]);

  const handlePageChange = (newPage: number) => {
    setPage(newPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePageSizeChange = (newPageSize: number) => {
    setPageSize(newPageSize);
    setPage(1);
  };

  const handleSort = useCallback((key: string, direction: 'asc' | 'desc') => {
    setSortState({ key, direction });
    setPage(1);
  }, []);

  const handleFiltersChange = useCallback((newFilters: FilterState) => {
    setFilters(newFilters);
    setPage(1);
  }, []);

  const handleStatusChange = (newStatuses: string[]) => {
    setSelectedStatuses(newStatuses);
    setPage(1);
  };

  const debouncedFilterUpdate = useMemo(
    () => debounce((value: string) => {
      handleFiltersChange({ ...filters, searchTerm: value });
    }, 300),
    [filters, handleFiltersChange]
  );

  const handleSearchInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = event.target.value;
    setLocalSearchTerm(newValue);
    debouncedFilterUpdate(newValue);
  };

  return (
    <div className="min-h-screen bg-navy-500">
      <div className="px-2 sm:px-3 py-3 space-y-3">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-surface-white">Mining Companies Database</h1>
            <p className="text-xs sm:text-sm text-surface-white/70">Explore and filter company data</p>
          </div>
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            <CurrencySelector />
            <TierSelector
              currentTier={effectiveTier}
              onTierChange={setTier}
            />
            <Link to="/scatter-chart">
              <Button
                variant="ghost"
                size="sm"
                className="text-surface-white/70 hover:text-surface-white"
                title="View Scatter Chart"
              >
                <LineChart className="h-5 w-5" />
              </Button>
            </Link>
            <Link to="/">
              <Button
                variant="ghost"
                size="sm"
                className="text-surface-white/70 hover:text-surface-white"
              >
                <Home className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>

        <div className="flex items-center gap-3 bg-navy-400/20 p-3 rounded-lg">
          <div className="relative flex-1 max-w-md">
            <input
              type="text"
              placeholder="Search name, ticker..."
              className="w-full pl-3 pr-8 py-2 bg-navy-500 border border-navy-300/20 rounded-md text-xs text-surface-white placeholder-surface-white/50 focus:outline-none focus:ring-2 focus:ring-accent-teal"
              value={localSearchTerm}
              onChange={handleSearchInputChange}
            />
          </div>

          <button
            className="flex items-center px-3 py-2 text-xs font-medium text-surface-white bg-navy-400/20 border border-navy-300/20 rounded-md hover:bg-navy-400/30 transition-colors"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="mr-2 h-4 w-4" />
            Filters
          </button>

          <div className="flex items-center gap-2">
            {['producer', 'developer', 'explorer'].map(status => (
              <label key={status} className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={selectedStatuses.includes(status)}
                  onChange={() => {
                    const newStatuses = selectedStatuses.includes(status)
                      ? selectedStatuses.filter(s => s !== status)
                      : [...selectedStatuses, status];
                    handleStatusChange(newStatuses);
                  }}
                  className="sr-only"
                />
                <div className={cn(
                  "px-3 py-1.5 rounded-full text-xs font-medium transition-all",
                  "border border-navy-300/20",
                  selectedStatuses.includes(status)
                    ? status === 'producer'
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : status === 'developer'
                      ? 'bg-blue-500/20 text-blue-300'
                      : 'bg-purple-500/20 text-purple-300'
                    : 'bg-navy-400/20 text-surface-white/70 hover:bg-navy-400/30'
                )}>
                  {status.charAt(0).toUpperCase() + status.slice(1)}
                </div>
              </label>
            ))}
          </div>
        </div>

        <div className="bg-navy-500 rounded-lg shadow-lg border border-navy-400/20 min-h-[400px] flex flex-col">
          {loading && !isTableVisible && (
            <div className="flex-grow flex items-center justify-center p-6">
              <LoadingIndicator message="Loading companies..." />
            </div>
          )}

          {error && !loading && (
            <div className="flex-grow flex flex-col items-center justify-center text-center p-6 text-red-400">
              <p className="font-semibold mb-2">Error Loading Data</p>
              <p className="text-xs">{error}</p>
              <button
                onClick={() => window.location.reload()}
                className="mt-4 px-4 py-2 bg-red-500/10 text-red-400 rounded border border-red-500/20 text-xs hover:bg-red-500/20"
              >
                Retry
              </button>
            </div>
          )}

          <div className={cn(
            "transition-opacity duration-300 ease-in-out",
            isTableVisible ? "opacity-100" : "opacity-0"
          )}>
            {!error && (
              <CompanyDataTable
                companies={companies}
                onSort={handleSort}
                currentSort={sortState}
                selectedStatuses={selectedStatuses}
                onStatusChange={handleStatusChange}
                currentTier={effectiveTier}
                page={page}
                pageSize={pageSize}
                totalCount={totalCount}
                onPageChange={handlePageChange}
                onPageSizeChange={handlePageSizeChange}
              />
            )}
          </div>

          {isTableVisible && companies.length === 0 && !error && (
            <div className="flex-grow flex flex-col items-center justify-center text-center text-surface-white/70 py-16 px-6">
              <p className="font-semibold">No companies found</p>
              <p className="text-xs mt-1">Try adjusting your search or filters.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}