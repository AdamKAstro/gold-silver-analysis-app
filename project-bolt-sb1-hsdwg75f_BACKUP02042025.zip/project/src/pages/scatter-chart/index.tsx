import React, { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Home, ZoomIn, ZoomOut, RotateCcw, Download, Lock, ArrowUpDown } from 'lucide-react';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LogarithmicScale, Tooltip as ChartTooltip, Legend } from 'chart.js';
import { Scatter } from 'react-chartjs-2';
import zoomPlugin from 'chartjs-plugin-zoom';

// Components
import { Button } from '../../components/ui/button';
import { MetricSelector } from '../../components/metric-selector';
import { TierSelector } from '../../components/tier-selector';
import { LoadingIndicator } from '../../components/ui/loading-indicator';

// Contexts
import { useSubscription } from '../../contexts/subscription-context';
import { useCurrency } from '../../contexts/currency-context';

// Utils & Types
import { cn, getNestedValue } from '../../lib/utils';
import { getMetricByKey, getAccessibleMetrics, metrics } from '../../lib/metric-types';
import { getCompaniesForScatterChart } from '../../lib/supabase';
import { normalizeValues, formatValueWrapper, getDomain, exportChartCode, downloadJson } from './chartUtils';
import type { Company, ColumnTier, MetricConfig, Currency } from '../../lib/types';

// Register Chart.js components and custom plugin for quadrant shading
ChartJS.register(
  CategoryScale,
  LinearScale,
  LogarithmicScale,
  PointElement,
  ChartTooltip,
  Legend,
  zoomPlugin,
  {
    id: 'quadrantPlugin',
    beforeDraw: (chart: any) => {
      const { ctx, chartArea, scales } = chart;
      if (!chartArea) return;

      // Get metric configurations from chart options
      const { xMetricConfig, yMetricConfig } = chart.options.metrics || {};
      if (!xMetricConfig || !yMetricConfig) return;

      // Define colors for different quadrants with lower opacity
      const goodColor = 'rgba(16, 185, 129, 0.09)'; // emerald-500 with 9% opacity
      const badColor = 'rgba(75, 85, 99, 0.09)'; // gray-600 with 9% opacity

      // Calculate center points (use the middle of the chart area for linear scales)
      const xCenter = chartArea.left + (chartArea.width / 2);
      const yCenter = chartArea.top + (chartArea.height / 2);

      // Draw quadrants based on metric preferences
      ctx.save();
      ctx.globalCompositeOperation = 'destination-over';

      // Top-right quadrant
      ctx.fillStyle = (xMetricConfig.higherIsBetter && yMetricConfig.higherIsBetter) ? goodColor : badColor;
      ctx.fillRect(
        xCenter,
        chartArea.top,
        chartArea.right - xCenter,
        yCenter - chartArea.top
      );

      // Top-left quadrant
      ctx.fillStyle = (!xMetricConfig.higherIsBetter && yMetricConfig.higherIsBetter) ? goodColor : badColor;
      ctx.fillRect(
        chartArea.left,
        chartArea.top,
        xCenter - chartArea.left,
        yCenter - chartArea.top
      );

      // Bottom-right quadrant
      ctx.fillStyle = (xMetricConfig.higherIsBetter && !yMetricConfig.higherIsBetter) ? goodColor : badColor;
      ctx.fillRect(
        xCenter,
        yCenter,
        chartArea.right - xCenter,
        chartArea.bottom - yCenter
      );

      // Bottom-left quadrant
      ctx.fillStyle = (!xMetricConfig.higherIsBetter && !yMetricConfig.higherIsBetter) ? goodColor : badColor;
      ctx.fillRect(
        chartArea.left,
        yCenter,
        xCenter - chartArea.left,
        chartArea.bottom - yCenter
      );

      ctx.restore();
    }
  }
);

// Status-based colors matching the companies page
const statusColors = {
  producer: {
    background: 'rgba(16, 185, 129, 0.9)', // emerald-500
    border: 'rgba(6, 95, 70, 0.9)', // emerald-800
    hover: 'rgba(16, 185, 129, 1)' // emerald-500 full opacity
  },
  developer: {
    background: 'rgba(59, 130, 246, 0.9)', // blue-500
    border: 'rgba(30, 64, 175, 0.9)', // blue-800
    hover: 'rgba(59, 130, 246, 1)' // blue-500 full opacity
  },
  explorer: {
    background: 'rgba(168, 85, 247, 0.9)', // purple-500
    border: 'rgba(107, 33, 168, 0.9)', // purple-800
    hover: 'rgba(168, 85, 247, 1)' // purple-500 full opacity
  }
};

// Hardcoded chart settings
const chartSettings = {
  pointRadius: 14,
  pointHoverRadius: 7,
  pointBorderWidth: 1,
  pointHoverBorderWidth: 7,
  pointOpacity: 0.9,
  pointHoverOpacity: 0.55,
  labelFontSize: 19,
  labelOpacity: 0.6,
  gridLineOpacity: 0.35,
  axisFontSize: 13,
  titleFontSize: 15,
  tooltipFontSize: 13,
  zoomSpeed: 0.55,
  panSpeed: 0.55,
  wheelZoomSpeed: 0.15
};

// Custom tooltip component
const customTooltip = (context: any) => {
  const point = context.raw;
  if (!point) return null;

  return {
    title: `${point.company.company_name} (${point.company.status})`,
    body: [
      `${point.xLabel}: ${formatValueWrapper(point.x, point.xFormat)}`,
      `${point.yLabel}: ${formatValueWrapper(point.y, point.yFormat)}`,
      `${point.zLabel}: ${formatValueWrapper(point.z, point.zFormat)}`
    ]
  };
};

// Scale toggle component
function ScaleToggle({ scale, onChange, label }: { scale: 'linear' | 'logarithmic', onChange: (scale: 'linear' | 'logarithmic') => void, label: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs text-gray-400">{label}:</span>
      <button
        onClick={() => onChange(scale === 'linear' ? 'logarithmic' : 'linear')}
        className={cn(
          "flex items-center gap-1 px-2 py-1 rounded text-xs font-medium transition-colors",
          "border border-gray-700",
          scale === 'logarithmic' 
            ? "bg-accent-teal/20 text-accent-teal border-accent-teal/30"
            : "bg-gray-800 text-gray-400 hover:bg-gray-700"
        )}
      >
        <ArrowUpDown className="h-3 w-3" />
        {scale === 'logarithmic' ? 'Log' : 'Linear'}
      </button>
    </div>
  );
}

export function ScatterChartPage() {
  const { getEffectiveTier } = useSubscription();
  const { currency } = useCurrency();
  const effectiveTier = getEffectiveTier() as ColumnTier;
  const chartRef = useRef<ChartJS>(null);

  // State
  const [data, setData] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [xMetric, setXMetric] = useState('market_cap_value');
  const [yMetric, setYMetric] = useState('ev_per_resource_oz_all');
  const [zMetric, setZMetric] = useState('current_production_total_aueq_koz');
  const [xScale, setXScale] = useState<'linear' | 'logarithmic'>('logarithmic');
  const [yScale, setYScale] = useState<'linear' | 'logarithmic'>('logarithmic');
  const [zScale, setZScale] = useState<'linear' | 'logarithmic'>('linear');

  // Memos
  const accessibleMetrics = useMemo(() => metrics, []);
  const xMetricConfig = useMemo(() => getMetricByKey(xMetric), [xMetric]);
  const yMetricConfig = useMemo(() => getMetricByKey(yMetric), [yMetric]);
  const zMetricConfig = useMemo(() => getMetricByKey(zMetric), [zMetric]);

  // Check if a metric is accessible based on tier
  const isMetricAccessible = useCallback((metric: MetricConfig) => {
    const tierLevels = { free: 0, medium: 1, premium: 2 };
    return tierLevels[effectiveTier] >= tierLevels[metric.tier];
  }, [effectiveTier]);

  // Transform data for Chart.js
  const chartData = useMemo(() => {
    if (!data.length || !xMetricConfig || !yMetricConfig || !zMetricConfig) return { datasets: [] };

    // Check if metrics are accessible
    const canAccessX = isMetricAccessible(xMetricConfig);
    const canAccessY = isMetricAccessible(yMetricConfig);
    const canAccessZ = isMetricAccessible(zMetricConfig);

    // If any metric is not accessible, show locked state
    if (!canAccessX || !canAccessY || !canAccessZ) {
      return {
        datasets: [{
          label: 'Locked Content',
          data: [],
          backgroundColor: 'rgba(75, 85, 99, 0.3)',
          borderColor: 'rgba(75, 85, 99, 0.5)',
        }]
      };
    }

    const points = data.map(company => {
      const x = getNestedValue(company, xMetricConfig.path);
      const y = getNestedValue(company, yMetricConfig.path);
      const z = getNestedValue(company, zMetricConfig.path);

      if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) return null;
      if (xScale === 'logarithmic' && x <= 0) return null;
      if (yScale === 'logarithmic' && y <= 0) return null;

      return {
        x,
        y,
        z,
        company,
        xLabel: xMetricConfig.label,
        yLabel: yMetricConfig.label,
        zLabel: zMetricConfig.label,
        xFormat: xMetricConfig.format,
        yFormat: yMetricConfig.format,
        zFormat: zMetricConfig.format
      };
    }).filter(Boolean);

    const zValues = points.map(p => p?.z);
    const normalizedZ = normalizeValues(zValues, zScale === 'logarithmic' ? 'log' : 'linear');

    // Group points by status
    const groupedPoints = points.reduce((acc, point, index) => {
      const status = point.company.status?.toLowerCase() || 'other';
      if (!acc[status]) {
        acc[status] = {
          label: status.charAt(0).toUpperCase() + status.slice(1),
          data: [],
          backgroundColor: [],
          borderColor: [],
          pointRadius: [],
          pointHoverRadius: [],
          pointHoverBackgroundColor: [],
          borderWidth: chartSettings.pointBorderWidth,
          pointHoverBorderWidth: chartSettings.pointHoverBorderWidth
        };
      }
      const colors = statusColors[status as keyof typeof statusColors] || {
        background: 'rgba(75, 85, 99, 0.9)',
        border: 'rgba(31, 41, 55, 0.9)',
        hover: 'rgba(75, 85, 99, 1)'
      };
      
      acc[status].data.push(point);
      acc[status].backgroundColor.push(colors.background);
      acc[status].borderColor.push(colors.border);
      acc[status].pointRadius.push(chartSettings.pointRadius * (normalizedZ[index] + 0.5));
      acc[status].pointHoverRadius.push(chartSettings.pointHoverRadius * (normalizedZ[index] + 0.5));
      acc[status].pointHoverBackgroundColor.push(colors.hover);
      
      return acc;
    }, {} as Record<string, any>);

    return {
      datasets: Object.values(groupedPoints)
    };
  }, [data, xMetricConfig, yMetricConfig, zMetricConfig, xScale, yScale, zScale, isMetricAccessible]);

  // Chart options
  const chartOptions = useMemo(() => ({
    responsive: true,
    maintainAspectRatio: false,
    metrics: {
      xMetricConfig,
      yMetricConfig
    },
    scales: {
      x: {
        type: xScale,
        position: 'bottom',
        title: {
          display: true,
          text: xMetricConfig?.label,
          font: {
            size: chartSettings.titleFontSize,
            weight: 'bold'
          },
          color: 'rgb(229, 231, 235)' // text-gray-200
        },
        ticks: {
          font: {
            size: chartSettings.axisFontSize
          },
          callback: (value: number) => formatValueWrapper(value, xMetricConfig?.format)
        },
        grid: {
          color: `rgba(55, 65, 81, ${chartSettings.gridLineOpacity})`
        }
      },
      y: {
        type: yScale,
        position: 'left',
        title: {
          display: true,
          text: yMetricConfig?.label,
          font: {
            size: chartSettings.titleFontSize,
            weight: 'bold'
          },
          color: 'rgb(229, 231, 235)' // text-gray-200
        },
        ticks: {
          font: {
            size: chartSettings.axisFontSize
          },
          callback: (value: number) => formatValueWrapper(value, yMetricConfig?.format)
        },
        grid: {
          color: `rgba(55, 65, 81, ${chartSettings.gridLineOpacity})`
        }
      }
    },
    plugins: {
      legend: {
        display: true,
        position: 'top' as const,
        labels: {
          font: {
            size: chartSettings.labelFontSize
          },
          color: 'rgb(229, 231, 235)' // text-gray-200
        }
      },
      tooltip: {
        enabled: isMetricAccessible(xMetricConfig) && isMetricAccessible(yMetricConfig) && isMetricAccessible(zMetricConfig),
        callbacks: {
          label: (context: any) => {
            const tooltip = customTooltip(context);
            return tooltip?.body || [];
          },
          title: (context: any) => {
            const tooltip = customTooltip(context[0]);
            return tooltip?.title || '';
          }
        },
        titleFont: {
          size: chartSettings.tooltipFontSize,
          weight: 'bold'
        },
        bodyFont: {
          size: chartSettings.tooltipFontSize
        },
        backgroundColor: 'rgba(17, 24, 39, 0.9)',
        borderColor: 'rgba(75, 85, 99, 0.3)',
        borderWidth: 1,
        padding: 8,
        cornerRadius: 4
      },
      zoom: {
        zoom: {
          wheel: {
            enabled: true,
            speed: chartSettings.wheelZoomSpeed
          },
          pinch: {
            enabled: true
          },
          mode: 'xy'
        },
        pan: {
          enabled: true,
          speed: chartSettings.panSpeed,
          mode: 'xy'
        }
      }
    }
  }), [xMetricConfig, yMetricConfig, xScale, yScale, isMetricAccessible]);

  // Fetch data
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const companies = await getCompaniesForScatterChart(currency as Currency);
        setData(companies);
      } catch (err: any) {
        setError(err.message || 'Failed to fetch data');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [currency]);

  // Handlers
  const handleZoomIn = () => {
    if (!chartRef.current) return;
    chartRef.current.zoom(1.1);
  };

  const handleZoomOut = () => {
    if (!chartRef.current) return;
    chartRef.current.zoom(0.9);
  };

  const handleResetZoom = () => {
    if (!chartRef.current) return;
    chartRef.current.resetZoom();
  };

  const handleExportCode = () => {
    const code = exportChartCode();
    downloadJson(code, 'scatter-chart-code.json');
  };

  return (
    <div className="min-h-screen bg-gray-900 p-4">
      <div className="max-w-7xl mx-auto space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/">
              <Button variant="ghost" size="icon"><Home className="h-5 w-5" /></Button>
            </Link>
            <h1 className="text-xl font-semibold text-gray-100">Scatter Analysis</h1>
          </div>
          <div className="flex items-center gap-2">
            <TierSelector currentTier={effectiveTier} onTierChange={() => {}} />
            <Button variant="ghost" size="icon" onClick={handleExportCode}><Download className="h-5 w-5" /></Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <MetricSelector
              label="X Axis"
              selectedMetric={xMetric}
              onMetricChange={setXMetric}
              metrics={accessibleMetrics}
              currentTier={effectiveTier}
            />
            <ScaleToggle scale={xScale} onChange={setXScale} label="X Scale" />
          </div>
          <div className="space-y-2">
            <MetricSelector
              label="Y Axis"
              selectedMetric={yMetric}
              onMetricChange={setYMetric}
              metrics={accessibleMetrics}
              currentTier={effectiveTier}
            />
            <ScaleToggle scale={yScale} onChange={setYScale} label="Y Scale" />
          </div>
          <div className="space-y-2">
            <MetricSelector
              label="Bubble Size"
              selectedMetric={zMetric}
              onMetricChange={setZMetric}
              metrics={accessibleMetrics}
              currentTier={effectiveTier}
            />
            <ScaleToggle scale={zScale} onChange={setZScale} label="Size Scale" />
          </div>
        </div>

        <div className="relative bg-gray-800 rounded-lg p-4">
          <div className="absolute top-4 right-4 flex items-center gap-2 z-10">
            <Button variant="secondary" size="icon" onClick={handleZoomIn}><ZoomIn className="h-4 w-4" /></Button>
            <Button variant="secondary" size="icon" onClick={handleZoomOut}><ZoomOut className="h-4 w-4" /></Button>
            <Button variant="secondary" size="icon" onClick={handleResetZoom}><RotateCcw className="h-4 w-4" /></Button>
          </div>

          <div className="h-[600px]">
            {loading ? (
              <div className="h-full flex items-center justify-center">
                <LoadingIndicator />
              </div>
            ) : error ? (
              <div className="h-full flex items-center justify-center text-red-500">
                {error}
              </div>
            ) : (
              <>
                <Scatter
                  ref={chartRef}
                  data={chartData}
                  options={chartOptions}
                />
                {(!isMetricAccessible(xMetricConfig) || !isMetricAccessible(yMetricConfig) || !isMetricAccessible(zMetricConfig)) && (
                  <div className="absolute inset-0 flex items-center justify-center bg-gray-900/80 backdrop-blur-sm">
                    <div className="text-center space-y-2">
                      <Lock className="h-8 w-8 mx-auto text-gray-400" />
                      <p className="text-gray-300 font-medium">Upgrade your plan to access this data</p>
                      <p className="text-sm text-gray-400">
                        Some selected metrics require a higher tier subscription
                      </p>
                      <Link to="/subscribe">
                        <Button variant="secondary" size="sm" className="mt-4">
                          View Plans
                        </Button>
                      </Link>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}