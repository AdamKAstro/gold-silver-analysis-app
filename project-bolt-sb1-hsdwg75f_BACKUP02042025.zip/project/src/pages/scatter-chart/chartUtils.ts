import type { Currency, MetricFormat } from '../../lib/types';
import { formatNumber, formatCurrency, formatPercent, formatMoz, formatKoz } from '../../lib/utils';

// Re-import raw content needed for export function directly here
import packageJsonContent from '/package.json?raw';
import tailwindConfigContent from '/tailwind.config.js?raw';
import scatterChartIndexContent from './index.tsx?raw';
import forceSimulationContent from '../../lib/force-simulation.ts?raw';
import metricTypesContent from '../../lib/metric-types.ts?raw';
import utilsContent from '../../lib/utils.ts?raw';
import typesContent from '../../lib/types.ts?raw';
import supabaseLibContent from '../../lib/supabase.ts?raw';

const DEBUG_MODE = import.meta.env.DEV;

// --- Helper Functions Moved Here ---

export function exportChartCode(): { [key: string]: string } {
    const files = {
        'package.json': packageJsonContent || '// Error loading package.json',
        'tailwind.config.js': tailwindConfigContent || '// Error loading tailwind.config.js',
        // Warning: This will capture the state of index.tsx at build time, not runtime.
        'src/pages/scatter-chart/index.tsx': scatterChartIndexContent || '// Error loading index.tsx',
        'src/lib/force-simulation.ts': forceSimulationContent || '// Error loading force-simulation.ts',
        'src/lib/metric-types.ts': metricTypesContent || '// Error loading metric-types.ts',
        'src/lib/utils.ts': utilsContent || '// Error loading utils.ts',
        'src/lib/types.ts': typesContent || '// Error loading types.ts',
        'src/lib/supabase.ts': supabaseLibContent || '// Error loading supabase.ts',
    };
    Object.keys(files).forEach(key => {
        if (files[key]?.includes('Error loading')) console.warn(`Warning: Could not load raw content for ${key}`);
    });
    return files;
}

export function downloadJson(data: object, filename: string) {
    try {
        const jsonString = JSON.stringify(data, null, 2);
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a'); a.href = url; a.download = filename;
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        URL.revokeObjectURL(url);
    } catch (error) {
        console.error("Failed to download JSON:", error);
        alert("Failed to prepare download.");
    }
}

export function normalizeValues(values: number[] | undefined | null, scale: 'linear' | 'log'): number[] {
    if (!values || values.length === 0) return [];
    const finiteValues = values.filter(v => Number.isFinite(v));
    if (finiteValues.length === 0) return Array(values.length).fill(0.5);
    let minVal: number, maxVal: number, range: number;
    if (scale === 'log') {
        const positiveValues = finiteValues.filter(v => v > 0);
        if (positiveValues.length === 0) return values.map(v => (Number.isFinite(v) && v > 0) ? 0.5 : 0);
        minVal = Math.log10(Math.min(...positiveValues)); maxVal = Math.log10(Math.max(...positiveValues)); range = maxVal - minVal;
        return values.map(v => {
            if (!Number.isFinite(v) || v <= 0) return 0; if (range === 0) return 0.5;
            // Clamp values in case of floating point issues outside the min/max range
            return Math.max(0, Math.min(1, (Math.log10(v) - minVal) / range));
        });
    } else { // Linear
        minVal = Math.min(...finiteValues); maxVal = Math.max(...finiteValues); range = maxVal - minVal;
        return values.map(v => {
            if (!Number.isFinite(v)) return 0; if (range === 0) return 0.5;
             // Clamp values
            return Math.max(0, Math.min(1, (v - minVal) / range));
        });
    }
}

export function formatValueWrapper(value: number | string | undefined | null, format: MetricFormat | undefined, currencyCode: Currency = 'USD'): string {
    if (value === null || typeof value === 'undefined') return '-';
    // Allow strings to pass through (e.g., for labels if needed)
    if (typeof value === 'string') return value;
    if (!Number.isFinite(value)) return '-';
    try {
        switch (format) {
            case 'currency': return formatCurrency(value, currencyCode);
            case 'percent': return formatPercent(value);
            case 'number': return formatNumber(value, { decimals: 0 }); // Simple number format
            case 'moz': return formatMoz(value);
            case 'koz': return formatKoz(value);
            default: return formatNumber(value, { decimals: 0 }); // Default to simple number
        }
    } catch (e) {
        console.error("Formatting error for value:", value, "format:", format, "Error:", e);
        return "Err"; // Indicate formatting error
    }
}

export function getDomain(values: number[], scale: 'linear' | 'log'): [number | string, number | string] {
    const startTime = performance.now();
    if (DEBUG_MODE) console.groupCollapsed(`[DOMAIN] Calculating domain. Scale: ${scale}. Values: ${values?.length}`);

    if (!values || values.length === 0) {
        if (DEBUG_MODE) console.warn('[DOMAIN] No values provided.');
        if (DEBUG_MODE) console.groupEnd();
        return ['auto', 'auto'];
    }
    const finiteValues = values.filter(Number.isFinite);
    if (DEBUG_MODE) console.debug(`[DOMAIN] Finite values: ${finiteValues.length} out of ${values.length}.`);
    if (finiteValues.length === 0) {
        if (DEBUG_MODE) console.warn('[DOMAIN] No finite values found.');
        if (DEBUG_MODE) console.groupEnd();
        return ['auto', 'auto'];
    }

    let minVal = Math.min(...finiteValues);
    let maxVal = Math.max(...finiteValues);
    let domainResult: [number | string, number | string];

    if (scale === 'log') {
        const positiveValues = finiteValues.filter(v => v > 0);
        if (DEBUG_MODE) console.debug(`[DOMAIN] Log scale positive values: ${positiveValues.length}.`);
        if (positiveValues.length === 0) {
            if (DEBUG_MODE) console.warn('[DOMAIN] No positive values for log scale domain.');
            if (DEBUG_MODE) console.groupEnd();
            return ['auto', 'auto']; // Let recharts handle maybe? Or return a small positive range?
        }
        minVal = Math.min(...positiveValues);
        maxVal = Math.max(...positiveValues);

        if (minVal === maxVal) {
             const paddingFactor = 0.1; // 10% padding
             domainResult = [minVal * (1 - paddingFactor), minVal * (1 + paddingFactor)];
        }
        else {
            const paddingFactor = 1.1; // e.g., 10% padding factor
            domainResult = [Math.max(minVal / paddingFactor, Number.MIN_VALUE), maxVal * paddingFactor];
        }
    } else { // Linear scale
        if (minVal === maxVal) {
           const padding = Math.abs(minVal * 0.1) || 1; // Add 10% or 1 if value is 0
           domainResult = [minVal - padding, maxVal + padding];
        }
        else {
            const range = maxVal - minVal;
            const padding = range * 0.05; // 5% padding on each side
            domainResult = [minVal - padding, maxVal + padding];
        }
    }
    const endTime = performance.now();
    if (DEBUG_MODE) {
        console.log(`[DOMAIN] Calculated domain: [${domainResult[0]}, ${domainResult[1]}]. Duration: ${(endTime - startTime).toFixed(2)} ms`);
        console.groupEnd();
    }
    if (typeof domainResult[0] !== 'number' || typeof domainResult[1] !== 'number') {
       if(DEBUG_MODE) console.warn("[DOMAIN] Domain calculation resulted in non-numeric values, returning 'auto'");
       return ['auto', 'auto'];
    }
    return domainResult;
}