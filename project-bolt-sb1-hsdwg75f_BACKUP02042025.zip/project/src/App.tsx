import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { SubscriptionProvider } from './contexts/subscription-context';
import { CurrencyProvider } from './contexts/currency-context';
import { ThemeProvider } from './contexts/theme-context';
import { CompaniesPage } from './pages/companies';
import { SubscribePage } from './pages/subscribe';
import { ScatterChartPage } from './pages/scatter-chart';
import { Hero } from './components/ui/hero';

function App() {
  return (
    <Router>
      <ThemeProvider>
        <SubscriptionProvider>
          <CurrencyProvider>
            <Routes>
              <Route path="/" element={<Hero />} />
              <Route path="/companies" element={<CompaniesPage />} />
              <Route path="/scatter-chart" element={<ScatterChartPage />} />
              <Route path="/subscribe" element={<SubscribePage />} />
            </Routes>
          </CurrencyProvider>
        </SubscriptionProvider>
      </ThemeProvider>
    </Router>
  );
}

export default App;